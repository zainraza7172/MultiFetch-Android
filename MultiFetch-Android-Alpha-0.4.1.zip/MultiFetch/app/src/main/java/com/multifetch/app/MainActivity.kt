package com.multifetch.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.multifetch.app.download.DownloadEngine
import com.multifetch.app.download.DownloadStatus
import com.multifetch.app.download.DownloadStore
import com.multifetch.app.download.DownloadTask
import java.util.Locale

private val AppBlue = Color(0xFF1677FF)
private val DeepNavy = Color(0xFF101A3A)
private val SoftBlue = Color(0xFFEAF4FF)
private val AppBackground = Color(0xFFF5F7FB)
private val Muted = Color(0xFF6E7890)
private val Border = Color(0xFFE5EAF2)
private val Success = Color(0xFF31C453)

class MainActivity : ComponentActivity() {

    private lateinit var store: DownloadStore
    private lateinit var settings: SettingsStore

    private var tasks by mutableStateOf<List<DownloadTask>>(emptyList())
    private var initialUrl by mutableStateOf("")
    private var inputMessage by mutableStateOf("")
    private var turboMode by mutableStateOf(true)
    private var combineNetworks by mutableStateOf(false)

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    private val torrentPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            inputMessage = "Torrent file selected. Magnet/.torrent engine arrives in Phase 5."
        }
    }

    private val queueReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == DownloadService.ACTION_QUEUE_CHANGED) refreshTasks()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = DownloadStore(applicationContext)
        settings = SettingsStore(applicationContext)
        turboMode = settings.turboMode
        combineNetworks = settings.combineWifiAndCellular
        handleIncomingIntent(intent)
        requestNotificationPermissionIfNeeded()
        refreshTasks()
        recoverQueue()

        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = AppBlue,
                    onPrimary = Color.White,
                    background = AppBackground,
                    surface = Color.White,
                    onSurface = DeepNavy,
                    secondary = AppBlue,
                    outline = Border
                )
            ) {
                MultiFetchApp(
                    tasks = tasks,
                    initialUrl = initialUrl,
                    inputMessage = inputMessage,
                    turboMode = turboMode,
                    combineNetworks = combineNetworks,
                    onTurboModeChange = { enabled ->
                        turboMode = enabled
                        settings.turboMode = enabled
                    },
                    onCombineNetworksChange = { enabled ->
                        combineNetworks = enabled
                        settings.combineWifiAndCellular = enabled
                    },
                    onQueue = ::queueDownload,
                    onPause = { control(DownloadService.ACTION_PAUSE, it) },
                    onResume = { control(DownloadService.ACTION_RESUME, it) },
                    onCancel = { control(DownloadService.ACTION_CANCEL, it) },
                    onRetry = { control(DownloadService.ACTION_RETRY, it) },
                    onOpen = ::openCompletedFile,
                    onShare = ::shareCompletedFile,
                    onDelete = ::deleteTask,
                    onClearCompleted = ::clearCompleted,
                    onPickTorrent = { torrentPicker.launch(arrayOf("application/x-bittorrent", "application/octet-stream")) },
                    onMagnet = { inputMessage = "Magnet link ready UI is included; torrent engine arrives in Phase 5." },
                    onPauseAll = ::pauseAll,
                    onResumeAll = ::resumeAll
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(
            this,
            queueReceiver,
            IntentFilter(DownloadService.ACTION_QUEUE_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        refreshTasks()
    }

    override fun onStop() {
        runCatching { unregisterReceiver(queueReceiver) }
        super.onStop()
    }

    override fun onDestroy() {
        store.close()
        super.onDestroy()
    }

    private fun handleIncomingIntent(intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_SEND -> {
                val text = intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
                val url = Regex("https?://\\S+").find(text)?.value.orEmpty().trimEnd('.', ',', ')', ']')
                if (url.isNotBlank()) {
                    initialUrl = url
                    inputMessage = "Link received from another app."
                }
            }

            Intent.ACTION_VIEW -> {
                val data = intent.dataString.orEmpty()
                when {
                    data.startsWith("http://") || data.startsWith("https://") -> {
                        initialUrl = data
                        inputMessage = "Browser link captured."
                    }
                    data.startsWith("magnet:") -> {
                        inputMessage = "Magnet link captured. Torrent engine arrives in Phase 5."
                    }
                    intent.type == "application/x-bittorrent" -> {
                        inputMessage = "Torrent file received. Torrent engine arrives in Phase 5."
                    }
                }
            }
        }
    }

    private fun queueDownload(url: String) {
        val clean = url.trim()
        if (!(clean.startsWith("http://") || clean.startsWith("https://"))) {
            inputMessage = "Enter a valid http/https direct download link."
            return
        }

        val duplicate = store.findLatestByUrl(clean)
        if (duplicate != null && duplicate.status !in setOf(DownloadStatus.CANCELLED, DownloadStatus.FAILED)) {
            inputMessage = "This link is already in your download history/queue."
            return
        }

        val task = store.enqueue(clean)
        inputMessage = "Added to queue • Turbo ${if (turboMode) "ON" else "OFF"}"
        initialUrl = ""
        refreshTasks()
        val serviceIntent = Intent(this, DownloadService::class.java).apply {
            action = DownloadService.ACTION_ENQUEUE
            putExtra(DownloadService.EXTRA_TASK_ID, task.id)
        }
        ContextCompat.startForegroundService(this, serviceIntent)
    }

    private fun recoverQueue() {
        if (tasks.none { it.status == DownloadStatus.QUEUED || it.status == DownloadStatus.DOWNLOADING }) return
        val serviceIntent = Intent(this, DownloadService::class.java).apply {
            action = DownloadService.ACTION_RECOVER
        }
        ContextCompat.startForegroundService(this, serviceIntent)
    }

    private fun control(action: String, taskId: String) {
        val serviceIntent = Intent(this, DownloadService::class.java).apply {
            this.action = action
            putExtra(DownloadService.EXTRA_TASK_ID, taskId)
        }
        if (action == DownloadService.ACTION_RESUME || action == DownloadService.ACTION_RETRY) {
            ContextCompat.startForegroundService(this, serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    private fun pauseAll() {
        tasks.filter { it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.QUEUED }
            .forEach { control(DownloadService.ACTION_PAUSE, it.id) }
    }

    private fun resumeAll() {
        tasks.filter { it.status == DownloadStatus.PAUSED }.forEach {
            control(DownloadService.ACTION_RESUME, it.id)
        }
        tasks.filter { it.status == DownloadStatus.FAILED }.forEach {
            control(DownloadService.ACTION_RETRY, it.id)
        }
    }

    private fun refreshTasks() {
        tasks = runCatching { store.getAll() }.getOrDefault(emptyList())
    }

    private fun openCompletedFile(task: DownloadTask) {
        val uri = task.outputUri?.let(Uri::parse) ?: return
        val viewIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, task.mimeType ?: "application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { startActivity(Intent.createChooser(viewIntent, "Open with")) }
    }

    private fun shareCompletedFile(task: DownloadTask) {
        val uri = task.outputUri?.let(Uri::parse) ?: return
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = task.mimeType ?: "application/octet-stream"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { startActivity(Intent.createChooser(shareIntent, "Share download")) }
    }

    private fun deleteTask(task: DownloadTask) {
        when (task.status) {
            DownloadStatus.COMPLETED -> {
                task.outputUri?.let { raw ->
                    runCatching { contentResolver.delete(Uri.parse(raw), null, null) }
                }
            }
            DownloadStatus.DOWNLOADING, DownloadStatus.QUEUED, DownloadStatus.PAUSED -> {
                control(DownloadService.ACTION_CANCEL, task.id)
                DownloadEngine(applicationContext).deleteWorkspace(task.id)
            }
            DownloadStatus.FAILED, DownloadStatus.CANCELLED -> {
                DownloadEngine(applicationContext).deleteWorkspace(task.id)
            }
        }
        store.delete(task.id)
        refreshTasks()
    }

    private fun clearCompleted() {
        store.clearCompleted()
        inputMessage = "Completed items cleared from history. Files remain in Downloads/MultiFetch."
        refreshTasks()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}

private enum class AppTab(val label: String, val symbol: String) {
    HOME("Home", "⌂"),
    QUEUE("Queue", "☷"),
    CONNECTIONS("Connections", "⌘"),
    SETTINGS("Settings", "⚙")
}

@Composable
private fun MultiFetchApp(
    tasks: List<DownloadTask>,
    initialUrl: String,
    inputMessage: String,
    turboMode: Boolean,
    combineNetworks: Boolean,
    onTurboModeChange: (Boolean) -> Unit,
    onCombineNetworksChange: (Boolean) -> Unit,
    onQueue: (String) -> Unit,
    onPause: (String) -> Unit,
    onResume: (String) -> Unit,
    onCancel: (String) -> Unit,
    onRetry: (String) -> Unit,
    onOpen: (DownloadTask) -> Unit,
    onShare: (DownloadTask) -> Unit,
    onDelete: (DownloadTask) -> Unit,
    onClearCompleted: () -> Unit,
    onPickTorrent: () -> Unit,
    onMagnet: () -> Unit,
    onPauseAll: () -> Unit,
    onResumeAll: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(AppTab.HOME) }
    var showAddDialog by remember { mutableStateOf(false) }
    var showSearchDialog by remember { mutableStateOf(false) }
    var showQuickMenu by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var searchDraft by remember { mutableStateOf("") }
    var dialogUrl by remember { mutableStateOf(initialUrl) }

    LaunchedEffect(initialUrl) {
        if (initialUrl.isNotBlank()) {
            dialogUrl = initialUrl
            showAddDialog = true
            selectedTab = AppTab.HOME
        }
    }

    Scaffold(
        containerColor = AppBackground,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                AppTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = {
                            Text(
                                tab.symbol,
                                fontSize = 22.sp,
                                color = if (selectedTab == tab) AppBlue else Muted
                            )
                        },
                        label = { Text(tab.label, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { padding ->
        when (selectedTab) {
            AppTab.HOME -> DashboardHome(
                modifier = Modifier.padding(padding),
                tasks = tasks,
                inputMessage = inputMessage,
                turboMode = turboMode,
                combineNetworks = combineNetworks,
                onAddUrl = { showAddDialog = true },
                onMagnet = onMagnet,
                onPickTorrent = onPickTorrent,
                onOpenQueue = { selectedTab = AppTab.QUEUE },
                onOpenConnections = { selectedTab = AppTab.CONNECTIONS },
                onOpenSettings = { selectedTab = AppTab.SETTINGS },
                onClearCompleted = onClearCompleted,
                onSearch = {
                    searchDraft = searchQuery
                    showSearchDialog = true
                },
                onQuickMenu = { showQuickMenu = true }
            )

            AppTab.QUEUE -> QueueScreen(
                modifier = Modifier.padding(padding),
                tasks = tasks,
                onPause = onPause,
                onResume = onResume,
                onCancel = onCancel,
                onRetry = onRetry,
                onOpen = onOpen,
                onShare = onShare,
                onDelete = onDelete,
                onPauseAll = onPauseAll,
                onResumeAll = onResumeAll,
                onClearCompleted = onClearCompleted,
                searchQuery = searchQuery,
                onClearSearch = { searchQuery = "" }
            )

            AppTab.CONNECTIONS -> ConnectionsScreen(
                modifier = Modifier.padding(padding),
                tasks = tasks,
                combineNetworks = combineNetworks,
                onCombineNetworksChange = onCombineNetworksChange
            )

            AppTab.SETTINGS -> SettingsScreen(
                modifier = Modifier.padding(padding),
                turboMode = turboMode,
                combineNetworks = combineNetworks,
                onTurboModeChange = onTurboModeChange,
                onCombineNetworksChange = onCombineNetworksChange
            )
        }
    }

    if (showSearchDialog) {
        AlertDialog(
            onDismissRequest = { showSearchDialog = false },
            title = { Text("Search downloads", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = searchDraft,
                    onValueChange = { searchDraft = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("File name or URL") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    searchQuery = searchDraft.trim()
                    showSearchDialog = false
                    selectedTab = AppTab.QUEUE
                }) { Text("Search") }
            },
            dismissButton = {
                TextButton(onClick = {
                    searchDraft = ""
                    searchQuery = ""
                    showSearchDialog = false
                }) { Text("Clear") }
            }
        )
    }

    if (showQuickMenu) {
        AlertDialog(
            onDismissRequest = { showQuickMenu = false },
            title = { Text("Quick actions", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = {
                        showQuickMenu = false
                        showAddDialog = true
                    }) { Text("Add download") }
                    TextButton(onClick = {
                        showQuickMenu = false
                        selectedTab = AppTab.QUEUE
                    }) { Text("Open queue") }
                    TextButton(onClick = {
                        showQuickMenu = false
                        selectedTab = AppTab.CONNECTIONS
                    }) { Text("Connections") }
                    TextButton(onClick = {
                        showQuickMenu = false
                        selectedTab = AppTab.SETTINGS
                    }) { Text("Settings") }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQuickMenu = false }) { Text("Close") }
            }
        )
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add download", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Paste a direct HTTP/HTTPS file link. Browser-shared links appear here automatically.", color = Muted)
                    OutlinedTextField(
                        value = dialogUrl,
                        onValueChange = { dialogUrl = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Download URL") },
                        placeholder = { Text("https://example.com/file.zip") },
                        minLines = 2
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    onQueue(dialogUrl)
                    showAddDialog = false
                    dialogUrl = ""
                }) { Text("Start download") }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun DashboardHome(
    modifier: Modifier,
    tasks: List<DownloadTask>,
    inputMessage: String,
    turboMode: Boolean,
    combineNetworks: Boolean,
    onAddUrl: () -> Unit,
    onMagnet: () -> Unit,
    onPickTorrent: () -> Unit,
    onOpenQueue: () -> Unit,
    onOpenConnections: () -> Unit,
    onOpenSettings: () -> Unit,
    onClearCompleted: () -> Unit,
    onSearch: () -> Unit,
    onQuickMenu: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val network = remember(tasks, combineNetworks) { networkSnapshot(context) }
    val active = tasks.firstOrNull { it.status == DownloadStatus.DOWNLOADING }
        ?: tasks.firstOrNull { it.status == DownloadStatus.PAUSED }
    val totalSpeed = active?.let { parseSpeedBytesPerSecond(it.message) } ?: 0L
    val combinedActive = active?.message?.contains("Wi‑Fi + Mobile", ignoreCase = true) == true
    val turboActive = active?.message?.contains("Turbo", ignoreCase = true) == true && active.segmentCount > 1
    val (wifiSharePct, mobileSharePct) = measuredNetworkShares(
        active?.message.orEmpty(),
        network,
        totalSpeed,
        combinedActive
    )

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { BrandHeader(onSearch, onQuickMenu) }
        item {
            SpeedSummaryCard(
                totalSpeed,
                network,
                combineNetworks,
                combinedActive,
                turboActive,
                active?.segmentCount ?: 0,
                wifiSharePct,
                mobileSharePct
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1.7f)) {
                    ActiveDownloadCard(active, totalSpeed, Modifier.fillMaxWidth())
                }
                Box(Modifier.weight(1f)) {
                    NetworkShareCard(totalSpeed, wifiSharePct, mobileSharePct, Modifier.fillMaxWidth())
                }
            }
        }
        item { ActiveConnectionsCard(network, combinedActive, onOpenConnections) }
        item { AddDownloadCard(onAddUrl, onMagnet, onPickTorrent) }
        if (inputMessage.isNotBlank()) {
            item {
                Surface(
                    color = SoftBlue,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(inputMessage, modifier = Modifier.padding(14.dp), color = DeepNavy, fontSize = 13.sp)
                }
            }
        }
        item { QueuePreviewCard(tasks, onOpenQueue, onClearCompleted) }
        item { LimitsCard(turboMode, combineNetworks, onOpenSettings) }
    }
}

@Composable
private fun BrandHeader(onSearch: () -> Unit, onQuickMenu: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = painterResource(R.drawable.multifetch_logo),
            contentDescription = "MultiFetch logo",
            modifier = Modifier.size(54.dp).clip(RoundedCornerShape(16.dp)),
            contentScale = ContentScale.Crop
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("MultiFetch", fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, color = DeepNavy)
            Text("FASTER DOWNLOADS • MULTI-NETWORK", fontSize = 10.sp, color = Muted, letterSpacing = 1.1.sp)
        }
        Text(
            "⌕",
            fontSize = 28.sp,
            color = DeepNavy,
            modifier = Modifier.clickable(onClick = onSearch).padding(6.dp)
        )
        Spacer(Modifier.width(6.dp))
        Text(
            "⋮",
            fontSize = 28.sp,
            color = DeepNavy,
            modifier = Modifier.clickable(onClick = onQuickMenu).padding(6.dp)
        )
    }
}

@Composable
private fun SpeedSummaryCard(
    totalSpeed: Long,
    network: NetworkSnapshot,
    combineConfigured: Boolean,
    combinedActive: Boolean,
    turboActive: Boolean,
    segmentCount: Int,
    wifiSharePct: Int,
    mobileSharePct: Int
) {
    val wifiUsing = combinedActive || network.activeTransport == "Wi‑Fi"
    val mobileUsing = combinedActive || network.activeTransport == "Mobile"
    val wifiSpeed = speedShare(totalSpeed, wifiSharePct / 100.0)
    val mobileSpeed = speedShare(totalSpeed, mobileSharePct / 100.0)

    PremiumCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1.05f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MiniNetworkPill(
                    "≋",
                    "Wi‑Fi",
                    wifiSpeed,
                    when {
                        wifiUsing -> "In use"
                        network.wifi -> "Available"
                        else -> "Offline"
                    },
                    wifiUsing
                )
                MiniNetworkPill(
                    "▥",
                    "Mobile Data",
                    mobileSpeed,
                    when {
                        mobileUsing -> if (combinedActive) "Combined" else "In use"
                        network.cellular -> if (combineConfigured) "Ready" else "Available"
                        else -> "Offline"
                    },
                    mobileUsing
                )
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1.35f)) {
                Text("Total Download Speed", color = Muted, fontSize = 13.sp)
                Text(formatSpeed(totalSpeed), color = DeepNavy, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                val modeText = when {
                    combinedActive && turboActive -> "Turbo ACTIVE • Wi‑Fi + Mobile • $segmentCount parts"
                    combinedActive -> "Wi‑Fi + Mobile ACTIVE"
                    turboActive -> "Turbo ACTIVE • $segmentCount parts"
                    combineConfigured -> "Combine ready • waiting for both routes"
                    else -> "Single-network mode"
                }
                Text(modeText, color = if (totalSpeed > 0) Success else Muted, fontSize = 11.sp)
            }
            SpeedBars(active = totalSpeed > 0)
        }
    }
}

@Composable
private fun MiniNetworkPill(
    symbol: String,
    name: String,
    speed: Long,
    status: String,
    inUse: Boolean
) {
    Surface(color = SoftBlue, shape = RoundedCornerShape(14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(symbol, color = AppBlue, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp))
            Column {
                Text(name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    if (inUse) "${formatSpeed(speed)} • $status" else status,
                    fontSize = 11.sp,
                    color = if (inUse) DeepNavy else Muted
                )
            }
        }
    }
}

@Composable
private fun SpeedBars(active: Boolean) {
    Row(
        modifier = Modifier.width(52.dp).height(76.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        val heights = listOf(24, 38, 30, 52, 42, 62, 48)
        heights.forEach { h ->
            Box(
                Modifier.weight(1f).height(h.dp).clip(RoundedCornerShape(4.dp))
                    .background(if (active) AppBlue.copy(alpha = 0.75f) else AppBlue.copy(alpha = 0.18f))
            )
        }
    }
}

@Composable
private fun ActiveDownloadCard(task: DownloadTask?, speed: Long, modifier: Modifier = Modifier) {
    PremiumCard(modifier) {
        SectionTitle("Active Download", null)
        Spacer(Modifier.height(12.dp))
        if (task == null) {
            Text("No active download", fontWeight = FontWeight.SemiBold)
            Text("Add a URL to start downloading.", color = Muted, fontSize = 12.sp)
        } else {
            val progress = progressOf(task)
            Row(verticalAlignment = Alignment.CenterVertically) {
                FileBadge(categoryFor(task))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(task.fileName ?: shortUrl(task.url), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("${formatBytes(task.downloadedBytes)} / ${formatBytes(task.totalBytes)}", color = Muted, fontSize = 12.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("${(progress * 100).toInt()}%", color = AppBlue, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    Text(statusLabel(task.status), color = Muted, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(9.dp).clip(CircleShape),
                color = AppBlue,
                trackColor = Border
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("≋ ${formatSpeed(speed)}", color = Muted, fontSize = 12.sp)
                Text("⇶ ${task.segmentCount} parts", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun NetworkShareCard(
    speed: Long,
    wifiSharePct: Int,
    mobileSharePct: Int,
    modifier: Modifier = Modifier
) {
    PremiumCard(modifier) {
        Text("Network Share", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(8.dp))
        val wifiPct = wifiSharePct.toFloat().coerceIn(0f, 100f)
        val cellPct = mobileSharePct.toFloat().coerceIn(0f, 100f)
        Box(modifier = Modifier.fillMaxWidth().height(118.dp), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.size(92.dp)) {
                val stroke = Stroke(width = 14.dp.toPx(), cap = StrokeCap.Butt)
                drawArc(Border, -90f, 360f, false, style = stroke)
                if (wifiPct > 0f) drawArc(AppBlue, -90f, 360f * wifiPct / 100f, false, style = stroke)
                if (cellPct > 0f) drawArc(
                    Color(0xFF67B7FF),
                    -90f + 360f * wifiPct / 100f,
                    360f * cellPct / 100f,
                    false,
                    style = stroke
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(shortSpeed(speed), fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                Text("total", color = Muted, fontSize = 10.sp)
            }
        }
        LegendDot(AppBlue, "Wi‑Fi", wifiPct.toInt())
        LegendDot(Color(0xFF67B7FF), "Mobile", cellPct.toInt())
    }
}

@Composable
private fun LegendDot(color: Color, label: String, pct: Int) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(label, modifier = Modifier.weight(1f), color = Muted, fontSize = 11.sp)
        Text("$pct%", fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
    }
}

@Composable
private fun ActiveConnectionsCard(
    network: NetworkSnapshot,
    combinedActive: Boolean,
    onSeeAll: () -> Unit
) {
    PremiumCard {
        SectionTitle("Active Connections", "See All", onSeeAll)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ConnectionTile(
                "≋",
                "Wi‑Fi",
                connectionStatus(network.wifi, network.activeTransport == "Wi‑Fi", combinedActive && network.wifi),
                Modifier.weight(1f)
            )
            ConnectionTile(
                "▥",
                "Mobile",
                connectionStatus(network.cellular, network.activeTransport == "Mobile", combinedActive && network.cellular),
                Modifier.weight(1f)
            )
            ConnectionTile(
                "USB",
                "Ethernet",
                connectionStatus(network.ethernet, network.activeTransport == "Ethernet", false),
                Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun ConnectionTile(symbol: String, name: String, status: String, modifier: Modifier) {
    val active = status == "Connected" || status == "Combined"
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, Border)
    ) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(symbol, color = AppBlue, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(name, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(7.dp).clip(CircleShape)
                        .background(if (active) Success else Color(0xFFB7BECC))
                )
                Spacer(Modifier.width(5.dp))
                Text(status, color = Muted, fontSize = 10.sp)
            }
        }
    }
}

private fun connectionStatus(available: Boolean, defaultActive: Boolean, combinedActive: Boolean): String = when {
    combinedActive -> "Combined"
    defaultActive -> "Connected"
    available -> "Available"
    else -> "Offline"
}

@Composable
private fun AddDownloadCard(onUrl: () -> Unit, onMagnet: () -> Unit, onTorrent: () -> Unit) {
    PremiumCard {
        SectionTitle("Add Download", "⌃")
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AddDownloadTile("🔗", "URL", "Download from link", true, onUrl, Modifier.weight(1f))
            AddDownloadTile("∪", "Magnet", "Add magnet", false, onMagnet, Modifier.weight(1f))
            AddDownloadTile("▣", ".Torrent", "Select file", false, onTorrent, Modifier.weight(1f))
        }
    }
}

@Composable
private fun AddDownloadTile(symbol: String, title: String, subtitle: String, active: Boolean, onClick: () -> Unit, modifier: Modifier) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        color = if (active) SoftBlue else Color(0xFFFAFBFD),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (active) AppBlue.copy(alpha = 0.25f) else Border)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(symbol, fontSize = 22.sp, color = AppBlue)
            Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(subtitle, color = Muted, fontSize = 9.sp, maxLines = 1)
        }
    }
}

@Composable
private fun QueuePreviewCard(tasks: List<DownloadTask>, onOpenQueue: () -> Unit, onClearCompleted: () -> Unit) {
    PremiumCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("☷", color = DeepNavy, fontSize = 20.sp)
            Spacer(Modifier.width(8.dp))
            Text("Download Queue", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            val activeCount = tasks.count { it.status != DownloadStatus.COMPLETED && it.status != DownloadStatus.CANCELLED }
            Surface(color = SoftBlue, shape = CircleShape) {
                Text(activeCount.toString(), color = AppBlue, modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp), fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(8.dp))
            Text("Clear Completed", color = AppBlue, fontSize = 11.sp, modifier = Modifier.clickable(onClick = onClearCompleted))
        }
        Spacer(Modifier.height(10.dp))
        val preview = tasks.take(3)
        if (preview.isEmpty()) {
            Text("Queue is empty", color = Muted, fontSize = 13.sp)
        } else {
            preview.forEachIndexed { index, task ->
                CompactQueueRow(task)
                if (index != preview.lastIndex) HorizontalDivider(color = Border)
            }
        }
        TextButton(onClick = onOpenQueue, modifier = Modifier.align(Alignment.End)) { Text("Open full queue") }
    }
}

@Composable
private fun CompactQueueRow(task: DownloadTask) {
    val progress = progressOf(task)
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FileBadge(categoryFor(task), 38)
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)) {
            Text(task.fileName ?: shortUrl(task.url), fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${formatBytes(task.downloadedBytes)} / ${formatBytes(task.totalBytes)}", color = Muted, fontSize = 10.sp)
        }
        Column(Modifier.width(120.dp)) {
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                color = AppBlue,
                trackColor = Border
            )
            Spacer(Modifier.height(3.dp))
            Text(statusLabel(task.status), color = Muted, fontSize = 9.sp)
        }
        Spacer(Modifier.width(8.dp))
        Text("${(progress * 100).toInt()}%", color = AppBlue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
private fun LimitsCard(turboMode: Boolean, combineNetworks: Boolean, onManage: () -> Unit) {
    PremiumCard {
        SectionTitle("Speed Limits", "Manage", onManage)
        Spacer(Modifier.height(6.dp))
        LimitRow("≋", "Wi‑Fi", if (turboMode) "No limits" else "Balanced", "Using available speed")
        HorizontalDivider(color = Border)
        LimitRow("▥", "Mobile Data", if (combineNetworks) "Combined" else "Standby", if (combineNetworks) "Can contribute to downloads" else "Enable in Settings")
    }
}

@Composable
private fun LimitRow(symbol: String, label: String, value: String, subtitle: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(color = SoftBlue, shape = RoundedCornerShape(10.dp)) {
            Text(symbol, modifier = Modifier.padding(9.dp), color = AppBlue, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Text(label, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Column(horizontalAlignment = Alignment.End) {
            Text(value, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(subtitle, color = Muted, fontSize = 9.sp)
        }
        Spacer(Modifier.width(8.dp))
        Text("›", fontSize = 24.sp, color = Muted)
    }
}

@Composable
private fun QueueScreen(
    modifier: Modifier,
    tasks: List<DownloadTask>,
    onPause: (String) -> Unit,
    onResume: (String) -> Unit,
    onCancel: (String) -> Unit,
    onRetry: (String) -> Unit,
    onOpen: (DownloadTask) -> Unit,
    onShare: (DownloadTask) -> Unit,
    onDelete: (DownloadTask) -> Unit,
    onPauseAll: () -> Unit,
    onResumeAll: () -> Unit,
    onClearCompleted: () -> Unit,
    searchQuery: String,
    onClearSearch: () -> Unit
) {
    val visibleTasks = if (searchQuery.isBlank()) {
        tasks
    } else {
        tasks.filter { task ->
            task.fileName.orEmpty().contains(searchQuery, ignoreCase = true) ||
                task.url.contains(searchQuery, ignoreCase = true) ||
                task.status.name.contains(searchQuery, ignoreCase = true)
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 30.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            BrandSubHeader("Queue", "Persistent downloads, resume & history")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = onPauseAll, modifier = Modifier.weight(1f)) { Text("Pause all") }
                FilledTonalButton(onClick = onResumeAll, modifier = Modifier.weight(1f)) { Text("Resume all") }
                TextButton(onClick = onClearCompleted) { Text("Clear") }
            }
        }
        if (searchQuery.isNotBlank()) {
            item {
                Surface(color = SoftBlue, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Search: $searchQuery", modifier = Modifier.weight(1f), fontSize = 12.sp)
                        TextButton(onClick = onClearSearch) { Text("Clear") }
                    }
                }
            }
        }
        if (visibleTasks.isEmpty()) {
            item {
                PremiumCard {
                    Text(
                        if (searchQuery.isBlank()) "No downloads yet." else "No downloads match your search.",
                        color = Muted
                    )
                }
            }
        } else {
            items(visibleTasks, key = { it.id }) { task ->
                FullQueueCard(task, onPause, onResume, onCancel, onRetry, onOpen, onShare, onDelete)
            }
        }
    }
}

@Composable
private fun FullQueueCard(
    task: DownloadTask,
    onPause: (String) -> Unit,
    onResume: (String) -> Unit,
    onCancel: (String) -> Unit,
    onRetry: (String) -> Unit,
    onOpen: (DownloadTask) -> Unit,
    onShare: (DownloadTask) -> Unit,
    onDelete: (DownloadTask) -> Unit
) {
    PremiumCard {
        val progress = progressOf(task)
        Row(verticalAlignment = Alignment.CenterVertically) {
            FileBadge(categoryFor(task), 46)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(task.fileName ?: shortUrl(task.url), fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${formatBytes(task.downloadedBytes)} / ${formatBytes(task.totalBytes)} • ${task.segmentCount} parts", color = Muted, fontSize = 11.sp)
            }
            Text("${(progress * 100).toInt()}%", color = AppBlue, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
        }
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
            color = AppBlue,
            trackColor = Border
        )
        Spacer(Modifier.height(8.dp))
        Text(task.message.ifBlank { statusLabel(task.status) }, color = Muted, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            when (task.status) {
                DownloadStatus.DOWNLOADING -> {
                    SmallAction("Pause") { onPause(task.id) }
                    SmallAction("Cancel", tonal = false) { onCancel(task.id) }
                }
                DownloadStatus.QUEUED -> SmallAction("Cancel", tonal = false) { onCancel(task.id) }
                DownloadStatus.PAUSED -> {
                    SmallAction("Resume") { onResume(task.id) }
                    SmallAction("Cancel", tonal = false) { onCancel(task.id) }
                }
                DownloadStatus.FAILED, DownloadStatus.CANCELLED -> {
                    SmallAction("Retry") { onRetry(task.id) }
                    SmallAction("Delete", tonal = false) { onDelete(task) }
                }
                DownloadStatus.COMPLETED -> {
                    SmallAction("Open") { onOpen(task) }
                    SmallAction("Share", tonal = false) { onShare(task) }
                    SmallAction("Delete", tonal = false) { onDelete(task) }
                }
            }
        }
    }
}

@Composable
private fun SmallAction(label: String, tonal: Boolean = true, onClick: () -> Unit) {
    if (tonal) {
        FilledTonalButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) { Text(label, fontSize = 11.sp) }
    } else {
        OutlinedButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) { Text(label, fontSize = 11.sp) }
    }
}

@Composable
private fun ConnectionsScreen(
    modifier: Modifier,
    tasks: List<DownloadTask>,
    combineNetworks: Boolean,
    onCombineNetworksChange: (Boolean) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val network = remember(tasks, combineNetworks) { networkSnapshot(context) }
    val active = tasks.firstOrNull { it.status == DownloadStatus.DOWNLOADING }
    val combinedActive = active?.message?.contains("Wi‑Fi + Mobile", ignoreCase = true) == true

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 30.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { BrandSubHeader("Connections", "Actual network state & routing") }
        item {
            PremiumCard {
                ConnectionDetail(
                    "Wi‑Fi",
                    connectionStatus(network.wifi, network.activeTransport == "Wi‑Fi", combinedActive && network.wifi),
                    when {
                        combinedActive && network.wifi -> "Actively carrying download segments"
                        network.activeTransport == "Wi‑Fi" -> "Android default internet route"
                        network.wifi -> "Available but not currently used"
                        else -> "No validated Wi‑Fi internet route"
                    }
                )
                HorizontalDivider(color = Border)
                ConnectionDetail(
                    "Mobile Data",
                    connectionStatus(network.cellular, network.activeTransport == "Mobile", combinedActive && network.cellular),
                    when {
                        combinedActive && network.cellular -> "Actively carrying download segments"
                        network.activeTransport == "Mobile" -> "Android default internet route"
                        network.cellular && combineNetworks -> "Available; combine mode is armed"
                        network.cellular -> "Available, combine mode is off"
                        else -> "No validated mobile-data internet route"
                    }
                )
                HorizontalDivider(color = Border)
                ConnectionDetail(
                    "Ethernet / USB",
                    connectionStatus(network.ethernet, network.activeTransport == "Ethernet", false),
                    if (network.ethernet) "Validated Android Ethernet route" else "No Android Ethernet route"
                )
            }
        }
        item {
            PremiumCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Combine Wi‑Fi + Mobile Data", fontWeight = FontWeight.Bold)
                        Text(
                            "When both validated routes are available, different file segments are bound to separate Android Network objects.",
                            color = Muted,
                            fontSize = 12.sp
                        )
                    }
                    Switch(checked = combineNetworks, onCheckedChange = onCombineNetworksChange)
                }
                Spacer(Modifier.height(8.dp))
                val combineState = when {
                    combinedActive -> "ACTIVE now • this download is using Wi‑Fi + Mobile Data"
                    combineNetworks && network.wifi && network.cellular -> "READY • both routes are available; next fresh download can combine them"
                    combineNetworks -> "ARMED • waiting for both validated Wi‑Fi and mobile-data routes"
                    else -> "OFF"
                }
                Text(
                    combineState,
                    color = if (combinedActive) Success else if (combineNetworks) AppBlue else Muted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(4.dp))
                Text("Mobile data may be consumed quickly in Turbo Mode.", color = Color(0xFFE08A00), fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun ConnectionDetail(name: String, status: String, note: String) {
    val active = status == "Connected" || status == "Combined"
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(10.dp).clip(CircleShape)
                .background(if (active) Success else Color(0xFFB7BECC))
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(name, fontWeight = FontWeight.Bold)
            Text(note, color = Muted, fontSize = 11.sp)
        }
        Text(
            status,
            color = if (active) Success else Muted,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun SettingsScreen(
    modifier: Modifier,
    turboMode: Boolean,
    combineNetworks: Boolean,
    onTurboModeChange: (Boolean) -> Unit,
    onCombineNetworksChange: (Boolean) -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 30.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { BrandSubHeader("Settings", "Performance & network behavior") }
        item {
            PremiumCard {
                SettingToggle(
                    "Turbo Mode",
                    "Uses up to 32 aggressive parallel segments with no app-side speed cap. It is active only when a fresh download starts and the server supports HTTP range requests.",
                    turboMode,
                    onTurboModeChange
                )
                HorizontalDivider(color = Border)
                SettingToggle(
                    "Combine Wi‑Fi + Mobile Data",
                    "Binds different segments to validated Wi‑Fi and mobile-data routes. Connections screen shows READY vs ACTIVE truthfully.",
                    combineNetworks,
                    onCombineNetworksChange
                )
            }
        }
        item {
            PremiumCard {
                Text("Browser integration", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Share a link from Chrome/Firefox/other apps to MultiFetch, or choose MultiFetch from Android's Open with menu for HTTP/HTTPS links.", color = Muted, fontSize = 12.sp)
            }
        }
        item {
            PremiumCard {
                Text("Storage", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Completed files are saved to Downloads/MultiFetch. Clearing history does not delete completed files.", color = Muted, fontSize = 12.sp)
            }
        }
        item {
            Text("MultiFetch Alpha 0.4.1 • Stability fix", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(4.dp))
        }
    }
}

@Composable
private fun SettingToggle(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun BrandSubHeader(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(R.drawable.multifetch_logo),
                contentDescription = null,
                modifier = Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = DeepNavy)
                Text(subtitle, fontSize = 11.sp, color = Muted)
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, action: String?, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, color = DeepNavy)
        if (action != null) {
            Text(
                action,
                color = AppBlue,
                fontSize = 12.sp,
                modifier = if (onAction != null) Modifier.clickable(onClick = onAction) else Modifier
            )
        }
    }
}

@Composable
private fun PremiumCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), content = content)
    }
}

@Composable
private fun FileBadge(category: String, size: Int = 44) {
    val background = when (category) {
        "VIDEO" -> Color(0xFFECE5FF)
        "AUDIO" -> Color(0xFFFFE9EE)
        "APK" -> Color(0xFFE8F8E5)
        "ARCHIVE" -> Color(0xFFEAF4FF)
        "DOC" -> Color(0xFFFFF3DD)
        else -> Color(0xFFF0F2F7)
    }
    Surface(color = background, shape = RoundedCornerShape(12.dp), modifier = Modifier.size(size.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Text(category.take(3), fontWeight = FontWeight.ExtraBold, fontSize = 9.sp, color = DeepNavy)
        }
    }
}

private data class NetworkSnapshot(
    val wifi: Boolean,
    val cellular: Boolean,
    val ethernet: Boolean,
    val activeTransport: String
)

private fun networkSnapshot(context: Context): NetworkSnapshot {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    var wifi = false
    var cellular = false
    var ethernet = false

    cm.allNetworks.forEach { network ->
        val caps = cm.getNetworkCapabilities(network) ?: return@forEach
        val validatedInternet =
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        if (!validatedInternet) return@forEach

        wifi = wifi || caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
        cellular = cellular || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
        ethernet = ethernet || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    val activeCaps = cm.activeNetwork?.let(cm::getNetworkCapabilities)
    val activeTransport = when {
        activeCaps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi‑Fi"
        activeCaps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Mobile"
        activeCaps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"
        else -> "None"
    }

    return NetworkSnapshot(wifi, cellular, ethernet, activeTransport)
}

private fun measuredNetworkShares(
    message: String,
    network: NetworkSnapshot,
    totalSpeed: Long,
    combinedActive: Boolean
): Pair<Int, Int> {
    val wifi = Regex("WiFi\\s+(\\d+)%", RegexOption.IGNORE_CASE)
        .find(message)?.groupValues?.getOrNull(1)?.toIntOrNull()
    val mobile = Regex("Mobile\\s+(\\d+)%", RegexOption.IGNORE_CASE)
        .find(message)?.groupValues?.getOrNull(1)?.toIntOrNull()

    if (wifi != null && mobile != null) {
        return wifi.coerceIn(0, 100) to mobile.coerceIn(0, 100)
    }
    if (totalSpeed <= 0L) return 0 to 0
    if (combinedActive) return 0 to 0

    return when (network.activeTransport) {
        "Wi‑Fi" -> 100 to 0
        "Mobile" -> 0 to 100
        else -> 0 to 0
    }
}

private fun progressOf(task: DownloadTask): Float = if (task.totalBytes > 0) {
    (task.downloadedBytes.toFloat() / task.totalBytes.toFloat()).coerceIn(0f, 1f)
} else 0f

private fun parseSpeedBytesPerSecond(message: String): Long {
    val match = Regex("(\\d+(?:\\.\\d+)?)\\s*(KB|MB|GB)/s", RegexOption.IGNORE_CASE).find(message) ?: return 0L
    val value = match.groupValues[1].toDoubleOrNull() ?: return 0L
    val multiplier = when (match.groupValues[2].uppercase(Locale.US)) {
        "GB" -> 1024.0 * 1024.0 * 1024.0
        "MB" -> 1024.0 * 1024.0
        else -> 1024.0
    }
    return (value * multiplier).toLong()
}

private fun speedShare(total: Long, share: Double): Long = (total * share).toLong().coerceAtLeast(0L)

private fun shortSpeed(bytes: Long): String = when {
    bytes >= 1024L * 1024L * 1024L -> String.format(Locale.US, "%.1fG", bytes / 1024.0 / 1024.0 / 1024.0)
    bytes >= 1024L * 1024L -> String.format(Locale.US, "%.1fM", bytes / 1024.0 / 1024.0)
    bytes >= 1024L -> String.format(Locale.US, "%.0fK", bytes / 1024.0)
    else -> "0"
}

private fun formatSpeed(bytes: Long): String = when {
    bytes >= 1024L * 1024L * 1024L -> String.format(Locale.US, "%.2f GB/s", bytes / 1024.0 / 1024.0 / 1024.0)
    bytes >= 1024L * 1024L -> String.format(Locale.US, "%.1f MB/s", bytes / 1024.0 / 1024.0)
    bytes >= 1024L -> String.format(Locale.US, "%.0f KB/s", bytes / 1024.0)
    else -> "0 B/s"
}

private fun categoryFor(task: DownloadTask): String {
    val name = (task.fileName ?: task.url).substringBefore('?').lowercase(Locale.US)
    return when {
        name.endsWith(".mp4") || name.endsWith(".mkv") || name.endsWith(".webm") || name.endsWith(".mov") -> "VIDEO"
        name.endsWith(".mp3") || name.endsWith(".m4a") || name.endsWith(".wav") || name.endsWith(".flac") -> "AUDIO"
        name.endsWith(".apk") || name.endsWith(".xapk") -> "APK"
        name.endsWith(".zip") || name.endsWith(".rar") || name.endsWith(".7z") || name.endsWith(".tar") || name.endsWith(".gz") -> "ARCHIVE"
        name.endsWith(".pdf") || name.endsWith(".doc") || name.endsWith(".docx") || name.endsWith(".txt") -> "DOC"
        else -> "FILE"
    }
}

private fun statusLabel(status: DownloadStatus): String = when (status) {
    DownloadStatus.QUEUED -> "Queued"
    DownloadStatus.DOWNLOADING -> "Downloading"
    DownloadStatus.PAUSED -> "Paused"
    DownloadStatus.COMPLETED -> "Completed"
    DownloadStatus.FAILED -> "Failed"
    DownloadStatus.CANCELLED -> "Cancelled"
}

private fun shortUrl(url: String): String = url
    .removePrefix("https://")
    .removePrefix("http://")
    .take(70)

private fun formatBytes(bytes: Long): String = when {
    bytes < 0 -> "Unknown"
    bytes >= 1024L * 1024L * 1024L -> String.format(Locale.US, "%.2f GB", bytes / 1024.0 / 1024.0 / 1024.0)
    bytes >= 1024L * 1024L -> String.format(Locale.US, "%.1f MB", bytes / 1024.0 / 1024.0)
    bytes >= 1024L -> String.format(Locale.US, "%.0f KB", bytes / 1024.0)
    else -> "$bytes B"
}
