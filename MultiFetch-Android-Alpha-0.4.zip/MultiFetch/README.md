# MultiFetch Android — Alpha 0.4

Phase 4 adds the premium dashboard UI and Android link-capture workflow while retaining the Alpha 0.3 multi-network download engine.

## Alpha 0.4
- New light premium dashboard inspired by the approved UI reference
- User-provided MultiFetch logo in app header and launcher icon
- Home / Queue / Connections / Settings bottom navigation
- Total speed summary and active-download dashboard
- Network share visualization and active route cards
- URL / Magnet / .Torrent intake tiles
- Browser/app Share -> MultiFetch support
- Android Open with support for HTTP/HTTPS links
- Duplicate URL detection
- File category badges
- Queue controls: pause, resume, retry, cancel, pause all, resume all, clear completed
- Completed file actions: open, share, delete
- Persistent queue + byte resume retained
- Turbo Mode retained (up to 16 segments)
- Wi-Fi + mobile-data per-segment routing retained

## Torrent note
Magnet and .torrent intake UI is present in Alpha 0.4. The actual BitTorrent engine is planned for Phase 5.

## Output
Completed direct downloads are saved to `Downloads/MultiFetch`.
