package com.multifetch.app

import android.content.Context

class SettingsStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    var turboMode: Boolean
        get() = prefs.getBoolean(KEY_TURBO, true)
        set(value) = prefs.edit().putBoolean(KEY_TURBO, value).apply()

    var combineWifiAndCellular: Boolean
        get() = prefs.getBoolean(KEY_COMBINE, false)
        set(value) = prefs.edit().putBoolean(KEY_COMBINE, value).apply()

    companion object {
        private const val PREFS = "multifetch_settings"
        private const val KEY_TURBO = "turbo_mode"
        private const val KEY_COMBINE = "combine_wifi_cellular"
    }
}
