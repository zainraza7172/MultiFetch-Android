package com.multifetch.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.net.wifi.WifiManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.multifetch.app.download.DownloadEngine
import com.multifetch.app.download.DownloadStatus
import com.multifetch.app.download.DownloadStore
import com.multifetch.app.download.DownloadTask
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

class DownloadService : Service() {

    private val worker = Executors.newSingleThreadExecutor()
    private val draining = AtomicBoolean(false)
    private val pauseRequested = AtomicBoolean(false)
    private val cancelled = AtomicBoolean(false)

    private lateinit var store: DownloadStore

    @Volatile
    private var currentTaskId: String? = null

    private var lastNotifyAt = 0L
    private var lastSpeedAt = 0L
    private var lastSpeedBytes = 0L
    private var lastPublishedBytes = 0L
    private var currentSpeed = 0L

    override fun onCreate() {
        super.onCreate()
        store = DownloadStore(applicationContext)
        store.recoverInterrupted()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ENQUEUE, ACTION_RECOVER -> {
                ensureForeground("Preparing queue…")
                drainQueue()
            }

            ACTION_PAUSE -> pauseTask(intent.getStringExtra(EXTRA_TASK_ID))
            ACTION_RESUME -> resumeTask(intent.getStringExtra(EXTRA_TASK_ID))
            ACTION_CANCEL -> cancelTask(intent.getStringExtra(EXTRA_TASK_ID))
            ACTION_RETRY -> retryTask(intent.getStringExtra(EXTRA_TASK_ID))
        }
        return START_STICKY
    }

    private fun pauseTask(requestedId: String?) {
        val id = requestedId ?: currentTaskId ?: return
        if (id == currentTaskId) {
            pauseRequested.set(true)
            store.setStatus(id, DownloadStatus.PAUSED, "Paused")
            notifyQueueChanged()
        } else {
            val task = store.get(id) ?: return
            if (task.status == DownloadStatus.QUEUED) {
                store.setStatus(id, DownloadStatus.PAUSED, "Paused")
                notifyQueueChanged()
            }
        }
    }

    private fun resumeTask(requestedId: String?) {
        val id = requestedId ?: return
        val task = store.get(id) ?: return
        if (id == currentTaskId) {
            pauseRequested.set(false)
            store.setStatus(id, DownloadStatus.DOWNLOADING, "Downloading")
            notifyQueueChanged()
            return
        }
        if (task.status == DownloadStatus.PAUSED || task.status == DownloadStatus.FAILED) {
            store.resetForRetry(id)
            ensureForeground("Resuming queue…")
            notifyQueueChanged()
            drainQueue()
        }
    }

    private fun retryTask(requestedId: String?) {
        val id = requestedId ?: return
        val task = store.get(id) ?: return
        if (task.status == DownloadStatus.FAILED || task.status == DownloadStatus.CANCELLED) {
            store.resetForRetry(id)
            ensureForeground("Retrying…")
            notifyQueueChanged()
            drainQueue()
        }
    }

    private fun cancelTask(requestedId: String?) {
        val id = requestedId ?: currentTaskId ?: return
        if (id == currentTaskId) {
            cancelled.set(true)
            pauseRequested.set(false)
            store.setStatus(id, DownloadStatus.CANCELLED, "Cancelling…")
        } else {
            val task = store.get(id) ?: return
            if (task.status != DownloadStatus.COMPLETED) {
                store.setStatus(id, DownloadStatus.CANCELLED, "Cancelled")
                DownloadEngine(applicationContext).deleteWorkspace(id)
            }
        }
        notifyQueueChanged()
    }

    private fun drainQueue() {
        if (!draining.compareAndSet(false, true)) return
        worker.execute {
            try {
                while (true) {
                    val task = store.nextQueued() ?: break
                    runTask(task)
                }
            } finally {
                draining.set(false)
                currentTaskId = null
                if (store.nextQueued() != null) {
                    drainQueue()
                } else {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
        }
    }

    private fun runTask(task: DownloadTask) {
        currentTaskId = task.id
        pauseRequested.set(false)
        cancelled.set(false)
        resetSpeed(task.downloadedBytes)
        val settings = SettingsStore(applicationContext)
        val startLabel = buildString {
            append("Starting")
            if (settings.turboMode) append(" • Turbo")
            if (settings.combineWifiAndCellular) append(" • Multi-network")
        }
        store.setStatus(task.id, DownloadStatus.DOWNLOADING, startLabel)
        notifyQueueChanged()
        ensureForeground(startLabel)

        var wakeLock: PowerManager.WakeLock? = null
        var wifiLock: WifiManager.WifiLock? = null

        try {
            // Keep CPU/Wi-Fi awake while a foreground download is active. This avoids
            // Android power saving collapsing throughput when the screen dims or locks.
            wakeLock = runCatching {
                val power = getSystemService(POWER_SERVICE) as PowerManager
                power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MultiFetch:Download").apply {
                    setReferenceCounted(false)
                    acquire(6 * 60 * 60 * 1000L)
                }
            }.getOrNull()

            wifiLock = runCatching {
                val wifi = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                wifi.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "MultiFetch:HighPerf").apply {
                    setReferenceCounted(false)
                    acquire()
                }
            }.getOrNull()

            val engine = DownloadEngine(applicationContext)
            val result = engine.download(
                taskId = task.id,
                rawUrl = task.url,
                existingSegmentCount = if (task.downloadedBytes > 0) task.segmentCount else 0,
                turboMode = settings.turboMode,
                combineWifiAndCellular = settings.combineWifiAndCellular,
                pauseRequested = pauseRequested,
                cancelled = cancelled,
                onProbe = { probe ->
                    store.updateProbe(
                        id = task.id,
                        fileName = probe.fileName,
                        mimeType = probe.mimeType,
                        totalBytes = probe.totalBytes,
                        segmentCount = probe.segmentCount
                    )
                    notifyQueueChanged()
                },
                onProgress = { progress ->
                    updateProgress(task.id, progress.downloadedBytes, progress.totalBytes, progress.message)
                }
            )
            store.markCompleted(task.id, result.fileName, result.totalBytes, result.uri.toString())
            notifyQueueChanged()
            NotificationManagerCompat.from(this).notify(
                notificationId(task.id),
                completionNotification(result.fileName)
            )
        } catch (_: DownloadEngine.DownloadPausedException) {
            val latest = store.get(task.id)
            when {
                latest?.status == DownloadStatus.PAUSED ->
                    store.setStatus(task.id, DownloadStatus.PAUSED, "Paused • progress saved")
                latest?.status == DownloadStatus.DOWNLOADING && !pauseRequested.get() ->
                    store.resetForRetry(task.id)
            }
            notifyQueueChanged()
        } catch (_: DownloadEngine.DownloadCancelledException) {
            store.setStatus(task.id, DownloadStatus.CANCELLED, "Cancelled")
            notifyQueueChanged()
        } catch (t: Throwable) {
            val message = rootMessage(t)
            store.setStatus(task.id, DownloadStatus.FAILED, message)
            notifyQueueChanged()
            NotificationManagerCompat.from(this).notify(
                notificationId(task.id),
                failureNotification(task.fileName ?: "Download", message)
            )
        } finally {
            runCatching { if (wifiLock?.isHeld == true) wifiLock?.release() }
            runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
            currentTaskId = null
            pauseRequested.set(false)
            cancelled.set(false)
        }
    }

    @Synchronized
    private fun updateProgress(taskId: String, downloaded: Long, total: Long, message: String) {
        val now = System.currentTimeMillis()
        val safeDownloaded = max(downloaded, lastPublishedBytes)

        if (now - lastSpeedAt >= 1000) {
            val seconds = max(1.0, (now - lastSpeedAt) / 1000.0)
            val speedBytes = max(safeDownloaded, lastSpeedBytes)
            val instant = ((speedBytes - lastSpeedBytes) / seconds).toLong().coerceAtLeast(0L)
            currentSpeed = if (currentSpeed <= 0L) {
                instant
            } else {
                (currentSpeed * 0.55 + instant * 0.45).toLong().coerceAtLeast(0L)
            }
            lastSpeedAt = now
            lastSpeedBytes = speedBytes
        }

        val isTransferMessage = message.startsWith("Downloading") || message.startsWith("Resuming")
        val shouldPublish = !isTransferMessage || now - lastNotifyAt >= 500
        if (!shouldPublish) return

        lastNotifyAt = now
        lastPublishedBytes = max(lastPublishedBytes, safeDownloaded)
        val label = if (isTransferMessage && currentSpeed > 0) {
            "$message • ${formatSpeed(currentSpeed)}"
        } else message

        // Alpha 0.4.4: at most two persistent/UI progress writes per second during transfer.
        // This removes synchronized SQLite + notification + Compose churn from hot I/O paths.
        store.updateProgress(taskId, lastPublishedBytes, total, label)
        updateNotification(taskId, lastPublishedBytes, total, label)
        notifyQueueChanged()
    }

    private fun resetSpeed(existing: Long) {
        lastNotifyAt = 0L
        lastSpeedAt = System.currentTimeMillis()
        lastSpeedBytes = existing
        lastPublishedBytes = existing
        currentSpeed = 0L
    }

    private fun ensureForeground(text: String) {
        val notification = notification(
            taskId = currentTaskId,
            text = text,
            progress = 0,
            max = 0,
            indeterminate = true
        )
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(FOREGROUND_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(FOREGROUND_ID, notification)
        }
    }

    private fun updateNotification(taskId: String, downloaded: Long, total: Long, text: String) {
        val percent = if (total > 0) ((downloaded * 100) / total).toInt().coerceIn(0, 100) else 0
        NotificationManagerCompat.from(this).notify(
            FOREGROUND_ID,
            notification(taskId, text, percent, 100, total <= 0)
        )
    }

    private fun notification(
        taskId: String?,
        text: String,
        progress: Int,
        max: Int,
        indeterminate: Boolean
    ): android.app.Notification {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("MultiFetch")
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setContentIntent(openAppPendingIntent())
            .setProgress(max, progress, indeterminate)

        if (taskId != null) {
            builder
                .addAction(0, "Pause", controlPendingIntent(ACTION_PAUSE, taskId, 10))
                .addAction(0, "Cancel", controlPendingIntent(ACTION_CANCEL, taskId, 11))
        }
        return builder.build()
    }

    private fun completionNotification(fileName: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.stat_sys_download_done)
        .setContentTitle("Download complete")
        .setContentText(fileName)
        .setAutoCancel(true)
        .setContentIntent(openAppPendingIntent())
        .build()

    private fun failureNotification(fileName: String, message: String) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle("Download failed: $fileName")
            .setContentText(message)
            .setAutoCancel(true)
            .setContentIntent(openAppPendingIntent())
            .build()

    private fun openAppPendingIntent(): PendingIntent {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            this,
            1,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun controlPendingIntent(action: String, taskId: String, requestCode: Int): PendingIntent {
        val intent = Intent(this, DownloadService::class.java).apply {
            this.action = action
            putExtra(EXTRA_TASK_ID, taskId)
        }
        return PendingIntent.getService(
            this,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun notifyQueueChanged() {
        sendBroadcast(Intent(ACTION_QUEUE_CHANGED).apply { setPackage(packageName) })
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Downloads",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Active MultiFetch downloads"
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun formatSpeed(bytesPerSecond: Long): String = when {
        bytesPerSecond >= 1024L * 1024L -> String.format("%.1f MB/s", bytesPerSecond / 1024.0 / 1024.0)
        bytesPerSecond >= 1024L -> String.format("%.0f KB/s", bytesPerSecond / 1024.0)
        else -> "$bytesPerSecond B/s"
    }

    private fun rootMessage(t: Throwable): String {
        var root = t
        while (root.cause != null) root = root.cause!!
        return root.message?.takeIf { it.isNotBlank() } ?: "Download failed"
    }

    private fun notificationId(taskId: String): Int = 2000 + (taskId.hashCode() and 0x3FFF)

    override fun onDestroy() {
        currentTaskId?.let { id ->
            val task = store.get(id)
            if (task?.status == DownloadStatus.DOWNLOADING) {
                store.setStatus(id, DownloadStatus.QUEUED, "Interrupted • ready to resume")
            }
        }
        pauseRequested.set(true)
        worker.shutdownNow()
        store.close()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_ENQUEUE = "com.multifetch.app.action.ENQUEUE"
        const val ACTION_RECOVER = "com.multifetch.app.action.RECOVER"
        const val ACTION_PAUSE = "com.multifetch.app.action.PAUSE"
        const val ACTION_RESUME = "com.multifetch.app.action.RESUME"
        const val ACTION_CANCEL = "com.multifetch.app.action.CANCEL"
        const val ACTION_RETRY = "com.multifetch.app.action.RETRY"
        const val ACTION_QUEUE_CHANGED = "com.multifetch.app.action.QUEUE_CHANGED"

        const val EXTRA_TASK_ID = "task_id"

        private const val CHANNEL_ID = "downloads"
        private const val FOREGROUND_ID = 1001
    }
}
