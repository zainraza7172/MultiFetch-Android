package com.multifetch.app.download

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import com.multifetch.app.network.NetworkRouter
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicInteger

class DownloadEngine(private val context: Context) {

    data class Progress(
        val downloadedBytes: Long,
        val totalBytes: Long,
        val message: String
    )

    data class ProbeInfo(
        val totalBytes: Long,
        val supportsRanges: Boolean,
        val fileName: String,
        val mimeType: String,
        val segmentCount: Int,
        val networkLabel: String
    )

    data class Result(
        val uri: Uri,
        val fileName: String,
        val totalBytes: Long,
        val usedSegments: Int
    )

    class DownloadPausedException : RuntimeException("Download paused")
    class DownloadCancelledException : RuntimeException("Download cancelled")
    private class WorkerYieldException : RuntimeException("Worker yielded to adaptive tuner")

    fun download(
        taskId: String,
        rawUrl: String,
        existingSegmentCount: Int,
        turboMode: Boolean,
        combineWifiAndCellular: Boolean,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean,
        onProbe: (ProbeInfo) -> Unit,
        onProgress: (Progress) -> Unit
    ): Result {
        val url = validateUrl(rawUrl)
        val router = NetworkRouter(context)
        val session = router.acquire(combineWifiAndCellular)
        val downloadMessage = activeMessage(session.label, turboMode)

        try {
            onProgress(Progress(0, -1, "Checking server • ${session.label}"))
            val probe = probe(url, session.routes)
            val segments = chooseSegmentCount(
                totalBytes = probe.totalBytes,
                supportsRanges = probe.supportsRanges,
                turboMode = turboMode,
                existingSegmentCount = existingSegmentCount
            )
            val info = ProbeInfo(
                totalBytes = probe.totalBytes,
                supportsRanges = probe.supportsRanges,
                fileName = probe.fileName,
                mimeType = probe.mimeType,
                segmentCount = segments,
                networkLabel = session.label
            )
            onProbe(info)

            val workDir = File(context.filesDir, "multifetch/$taskId").apply { mkdirs() }
            val downloaded = AtomicLong(existingBytes(workDir, probe.totalBytes, segments))
            val wifiSessionBytes = AtomicLong(0L)
            val mobileSessionBytes = AtomicLong(0L)
            val initialMessage = if (downloaded.get() > 0) {
                "Resuming • ${session.label}${if (turboMode) " • Turbo" else ""}"
            } else {
                downloadMessage
            }
            onProgress(Progress(downloaded.get(), probe.totalBytes, initialMessage))

            try {
                if (segments > 1) {
                    downloadSegmented(
                        url = url,
                        totalBytes = probe.totalBytes,
                        segmentCount = segments,
                        turboMode = turboMode,
                        routes = session.routes,
                        workDir = workDir,
                        pauseRequested = pauseRequested,
                        cancelled = cancelled,
                        downloaded = downloaded,
                        wifiSessionBytes = wifiSessionBytes,
                        mobileSessionBytes = mobileSessionBytes,
                        progressMessage = downloadMessage,
                        onProgress = onProgress
                    )
                } else {
                    downloadSingle(
                        url = url,
                        routes = session.routes,
                        supportsRanges = probe.supportsRanges,
                        output = File(workDir, "part_0.tmp"),
                        pauseRequested = pauseRequested,
                        cancelled = cancelled,
                        downloaded = downloaded,
                        wifiSessionBytes = wifiSessionBytes,
                        mobileSessionBytes = mobileSessionBytes,
                        totalBytes = probe.totalBytes,
                        progressMessage = downloadMessage,
                        onProgress = onProgress
                    )
                }

                ensureRunning(pauseRequested, cancelled)
                val finalTotal = if (probe.totalBytes > 0) probe.totalBytes else {
                    (0 until segments).sumOf { index -> File(workDir, "part_$index.tmp").length() }
                }
                onProgress(Progress(finalTotal, finalTotal, "Saving to Downloads…"))
                val uri = publishToDownloads(
                    workDir = workDir,
                    partCount = segments,
                    fileName = probe.fileName,
                    mimeType = probe.mimeType,
                    cancelled = cancelled
                )
                workDir.deleteRecursively()
                onProgress(Progress(finalTotal, finalTotal, "Complete"))
                return Result(uri, probe.fileName, finalTotal, segments)
            } catch (t: Throwable) {
                if (t is DownloadCancelledException) workDir.deleteRecursively()
                throw t
            }
        } finally {
            session.close()
        }
    }

    fun deleteWorkspace(taskId: String) {
        File(context.filesDir, "multifetch/$taskId").deleteRecursively()
    }

    private data class Probe(
        val totalBytes: Long,
        val supportsRanges: Boolean,
        val fileName: String,
        val mimeType: String
    )

    private fun validateUrl(raw: String): URL {
        val trimmed = raw.trim()
        require(trimmed.startsWith("https://") || trimmed.startsWith("http://")) {
            "Only http:// and https:// links are supported."
        }
        return URL(trimmed)
    }

    private fun probe(url: URL, routes: List<NetworkRouter.Route>): Probe {
        var lastError: Throwable? = null
        for (route in routes) {
            try {
                return probeOnRoute(url, route)
            } catch (t: Throwable) {
                lastError = t
            }
        }
        throw IllegalStateException("Could not reach the download server.", lastError)
    }

    private fun probeOnRoute(url: URL, route: NetworkRouter.Route): Probe {
        val connection = open(url, route).apply {
            setRequestProperty("Range", "bytes=0-0")
        }
        try {
            val code = connection.responseCode
            if (code !in 200..299) error("Server returned HTTP $code")
            val contentRange = connection.getHeaderField("Content-Range")
            val totalFromRange = parseTotalFromContentRange(contentRange)
            val supportsRanges = code == HttpURLConnection.HTTP_PARTIAL && totalFromRange > 0
            val total = when {
                totalFromRange > 0 -> totalFromRange
                connection.contentLengthLong > 0 -> connection.contentLengthLong
                else -> -1L
            }
            val fileName = extractFileName(connection, url)
            val mime = connection.contentType?.substringBefore(';')?.trim()
                ?.takeIf { it.isNotBlank() }
                ?: "application/octet-stream"

            runCatching { connection.inputStream.close() }
            return Probe(total, supportsRanges, fileName, mime)
        } finally {
            connection.disconnect()
        }
    }

    private fun chooseSegmentCount(
        totalBytes: Long,
        supportsRanges: Boolean,
        turboMode: Boolean,
        existingSegmentCount: Int
    ): Int {
        if (!supportsRanges || totalBytes <= 0) return 1
        if (existingSegmentCount > 1) return existingSegmentCount.coerceIn(2, MAX_PARTS)

        // Alpha 0.4.3: use more smaller chunks than active connections.
        // This keeps the worker pool busy instead of letting fast connections finish
        // early and leaving one slow fixed segment to drag the whole download down.
        return if (turboMode) {
            when {
                totalBytes < 8L * MIB -> 4
                totalBytes < 32L * MIB -> 8
                totalBytes < 128L * MIB -> 16
                totalBytes < 512L * MIB -> 32
                totalBytes < 2048L * MIB -> 64
                else -> 96
            }
        } else {
            when {
                totalBytes < 4L * MIB -> 1
                totalBytes < 16L * MIB -> 2
                totalBytes < 64L * MIB -> 4
                totalBytes < 256L * MIB -> 8
                else -> 16
            }
        }
    }

    private fun existingBytes(workDir: File, totalBytes: Long, segmentCount: Int): Long {
        if (totalBytes <= 0) return File(workDir, "part_0.tmp").takeIf { it.exists() }?.length() ?: 0L
        val chunk = totalBytes / segmentCount
        var sum = 0L
        for (index in 0 until segmentCount) {
            val start = index * chunk
            val end = if (index == segmentCount - 1) totalBytes - 1 else start + chunk - 1
            val expected = end - start + 1
            val file = File(workDir, "part_$index.tmp")
            if (file.exists() && file.length() > expected) file.delete()
            sum += file.takeIf { it.exists() }?.length()?.coerceAtMost(expected) ?: 0L
        }
        return sum.coerceAtMost(totalBytes)
    }

    private fun downloadSegmented(
        url: URL,
        totalBytes: Long,
        segmentCount: Int,
        turboMode: Boolean,
        routes: List<NetworkRouter.Route>,
        workDir: File,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean,
        downloaded: AtomicLong,
        wifiSessionBytes: AtomicLong,
        mobileSessionBytes: AtomicLong,
        progressMessage: String,
        onProgress: (Progress) -> Unit
    ) {
        val chunk = totalBytes / segmentCount
        val pending = java.util.concurrent.ConcurrentLinkedQueue<Int>()

        // Completed chunks are skipped, partial chunks remain resumable.
        for (index in 0 until segmentCount) {
            val start = index * chunk
            val end = if (index == segmentCount - 1) totalBytes - 1 else start + chunk - 1
            val expected = end - start + 1
            val output = File(workDir, "part_$index.tmp")
            if (!output.exists() || output.length() < expected) pending.add(index)
        }
        if (pending.isEmpty()) return
        val remainingChunks = AtomicInteger(pending.size)

        val maxWorkers = chooseWorkerCount(segmentCount, turboMode, routes.size)
        val initialWorkers = if (turboMode) minOf(4, maxWorkers) else maxWorkers
        val activeWorkerLimit = AtomicInteger(initialWorkers)
        val tuning = AtomicBoolean(turboMode && maxWorkers > initialWorkers)
        val transferDone = AtomicBoolean(false)

        // Alpha 0.4.5: Auto Turbo benchmarks real aggregate throughput at several
        // connection counts, then settles on the fastest count instead of blindly
        // forcing 12/16 connections on every server. Some CDNs throttle clients that
        // open too many parallel range requests, so more connections can be slower.
        val tunerThread = if (tuning.get()) {
            Thread({
                val candidates = adaptiveCandidates(maxWorkers, routes.size)
                var bestWorkers = initialWorkers
                var bestSpeed = 0L
                try {
                    // Give the first sockets time to leave TCP/TLS startup before measuring.
                    sleepInterruptibly(AUTO_TURBO_WARMUP_MS, transferDone)
                    for (candidate in candidates) {
                        if (transferDone.get()) break
                        activeWorkerLimit.set(candidate)
                        val startBytes = downloaded.get()
                        val startedAt = System.nanoTime()
                        onProgress(
                            Progress(
                                downloaded.get(),
                                totalBytes,
                                "$progressMessage • Auto-tuning $candidate conn"
                            )
                        )
                        sleepInterruptibly(AUTO_TURBO_SAMPLE_MS, transferDone)
                        if (transferDone.get()) break
                        val elapsed = (System.nanoTime() - startedAt).coerceAtLeast(1L)
                        val moved = (downloaded.get() - startBytes).coerceAtLeast(0L)
                        val bytesPerSecond = ((moved * 1_000_000_000L) / elapsed).coerceAtLeast(0L)

                        if (bytesPerSecond > bestSpeed) {
                            bestSpeed = bytesPerSecond
                            bestWorkers = candidate
                        }

                        // If adding connections causes a large throughput collapse,
                        // return to the best known count immediately instead of testing
                        // even more aggressive values.
                        if (bestSpeed > 0L && candidate > bestWorkers &&
                            bytesPerSecond * 100L < bestSpeed * AUTO_TURBO_DROP_PERCENT
                        ) {
                            break
                        }
                    }
                } catch (_: InterruptedException) {
                    // Normal when the transfer finishes before tuning completes.
                } finally {
                    if (!transferDone.get()) {
                        activeWorkerLimit.set(bestWorkers)
                        tuning.set(false)
                        onProgress(
                            Progress(
                                downloaded.get(),
                                totalBytes,
                                "$progressMessage • Auto-selected $bestWorkers conn"
                            )
                        )
                    }
                }
            }, "MultiFetch-AutoTurbo").apply {
                isDaemon = true
                start()
            }
        } else null

        val executor = Executors.newFixedThreadPool(maxWorkers)
        try {
            val tasks = (0 until maxWorkers).map { workerIndex ->
                Callable {
                    while (true) {
                        ensureRunning(pauseRequested, cancelled)

                        // Workers above the current adaptive limit stay parked. When the
                        // tuner lowers the limit, an in-flight excess worker yields its
                        // HTTP range quickly and its partial chunk is re-queued/resumed.
                        while (workerIndex >= activeWorkerLimit.get()) {
                            if (remainingChunks.get() <= 0 || transferDone.get()) return@Callable
                            ensureRunning(pauseRequested, cancelled)
                            Thread.sleep(75)
                        }

                        val index = pending.poll()
                        if (index == null) {
                            if (remainingChunks.get() <= 0) break
                            Thread.sleep(50)
                            continue
                        }
                        val start = index * chunk
                        val end = if (index == segmentCount - 1) totalBytes - 1 else start + chunk - 1
                        val output = File(workDir, "part_$index.tmp")
                        try {
                            downloadRangeWithRetry(
                                url = url,
                                rangeStart = start,
                                rangeEnd = end,
                                output = output,
                                routes = routes,
                                initialRouteIndex = preferredRouteIndex(workerIndex, routes),
                                pauseRequested = pauseRequested,
                                cancelled = cancelled,
                                downloaded = downloaded,
                                wifiSessionBytes = wifiSessionBytes,
                                mobileSessionBytes = mobileSessionBytes,
                                totalBytes = totalBytes,
                                progressMessage = {
                                    val count = activeWorkerLimit.get()
                                    when {
                                        turboMode && tuning.get() -> "$progressMessage • Auto-tuning $count conn"
                                        turboMode -> "$progressMessage • Auto Turbo $count conn"
                                        else -> "$progressMessage • Parallel $count conn"
                                    }
                                },
                                shouldYield = { turboMode && workerIndex >= activeWorkerLimit.get() },
                                onProgress = onProgress
                            )
                            remainingChunks.decrementAndGet()
                        } catch (_: WorkerYieldException) {
                            pending.add(index)
                            Thread.sleep(40)
                        }
                    }
                }
            }
            executor.invokeAll(tasks).forEach { it.get() }
        } catch (t: Throwable) {
            val root = unwrap(t)
            when (root) {
                is DownloadPausedException -> throw root
                is DownloadCancelledException -> throw root
                else -> throw root
            }
        } finally {
            transferDone.set(true)
            tunerThread?.interrupt()
            runCatching { tunerThread?.join(500) }
            executor.shutdownNow()
        }
    }

    private fun adaptiveCandidates(maxWorkers: Int, routeCount: Int): List<Int> {
        val base = if (routeCount > 1) listOf(4, 6, 8, 10, 12, 14, 16) else listOf(4, 6, 8, 10, 12)
        return base.filter { it <= maxWorkers }.ifEmpty { listOf(maxWorkers) }
    }

    private fun sleepInterruptibly(durationMs: Long, done: AtomicBoolean) {
        var remaining = durationMs
        while (remaining > 0 && !done.get()) {
            val slice = minOf(250L, remaining)
            Thread.sleep(slice)
            remaining -= slice
        }
    }

    private fun chooseWorkerCount(partCount: Int, turboMode: Boolean, routeCount: Int): Int {
        val target = if (turboMode) {
            if (routeCount > 1) 16 else 12
        } else {
            6
        }
        return target.coerceAtMost(partCount).coerceAtLeast(1)
    }

    private fun preferredRouteIndex(workerIndex: Int, routes: List<NetworkRouter.Route>): Int {
        if (routes.size <= 1) return 0
        val wifi = routes.indexOfFirst { it.label == "Wi‑Fi" }
        val mobile = routes.indexOfFirst { it.label == "Mobile" }
        if (wifi >= 0 && mobile >= 0) {
            // Wi-Fi gets three workers for each mobile worker by default.
            // Mobile still contributes, but a slower cellular link is less likely
            // to become the tail that drags the whole file down.
            return if (workerIndex % 4 == 3) mobile else wifi
        }
        return workerIndex % routes.size
    }

    private fun downloadRangeWithRetry(
        url: URL,
        rangeStart: Long,
        rangeEnd: Long,
        output: File,
        routes: List<NetworkRouter.Route>,
        initialRouteIndex: Int,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean,
        downloaded: AtomicLong,
        wifiSessionBytes: AtomicLong,
        mobileSessionBytes: AtomicLong,
        totalBytes: Long,
        progressMessage: () -> String,
        shouldYield: () -> Boolean,
        onProgress: (Progress) -> Unit
    ) {
        val expectedSize = rangeEnd - rangeStart + 1
        if (output.exists() && output.length() > expectedSize) output.delete()
        if (output.exists() && output.length() == expectedSize) return

        var lastError: Throwable? = null
        repeat(5) { attempt ->
            ensureRunning(pauseRequested, cancelled)
            val already = output.takeIf { it.exists() }?.length() ?: 0L
            if (already >= expectedSize) return
            val requestStart = rangeStart + already
            val route = routes[(initialRouteIndex + attempt) % routes.size]
            try {
                val connection = open(url, route).apply {
                    setRequestProperty("Range", "bytes=$requestStart-$rangeEnd")
                }
                try {
                    if (connection.responseCode != HttpURLConnection.HTTP_PARTIAL) {
                        error("Server stopped supporting range requests (HTTP ${connection.responseCode}).")
                    }
                    BufferedInputStream(connection.inputStream, BUFFER_SIZE).use { input ->
                        BufferedOutputStream(FileOutputStream(output, true), BUFFER_SIZE).use { out ->
                            copyWithState(input, out, pauseRequested, cancelled, shouldYield) { count ->
                                val delta = count.toLong()
                                val current = downloaded.addAndGet(delta)
                                addRouteBytes(route.label, delta, wifiSessionBytes, mobileSessionBytes)
                                onProgress(
                                    Progress(
                                        current,
                                        totalBytes,
                                        withMeasuredNetworkShare(progressMessage(), wifiSessionBytes, mobileSessionBytes)
                                    )
                                )
                            }
                        }
                    }
                    if (output.length() == expectedSize) return
                    error("Segment ended early (${output.length()} / $expectedSize bytes).")
                } finally {
                    connection.disconnect()
                }
            } catch (t: Throwable) {
                when (t) {
                    is DownloadPausedException -> throw t
                    is DownloadCancelledException -> throw t
                    is WorkerYieldException -> throw t
                }
                lastError = t
                if (attempt < 4) Thread.sleep(500L * (attempt + 1))
            }
        }
        throw IllegalStateException("A download segment failed after network retries.", lastError)
    }

    private fun downloadSingle(
        url: URL,
        routes: List<NetworkRouter.Route>,
        supportsRanges: Boolean,
        output: File,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean,
        downloaded: AtomicLong,
        wifiSessionBytes: AtomicLong,
        mobileSessionBytes: AtomicLong,
        totalBytes: Long,
        progressMessage: String,
        onProgress: (Progress) -> Unit
    ) {
        var lastError: Throwable? = null
        routes.forEachIndexed { routeIndex, route ->
            ensureRunning(pauseRequested, cancelled)
            var existing = output.takeIf { it.exists() }?.length() ?: 0L
            if (!supportsRanges && existing > 0) {
                output.delete()
                downloaded.set(0L)
                existing = 0L
            }
            if (totalBytes > 0 && existing >= totalBytes) return

            try {
                val connection = open(url, route).apply {
                    if (supportsRanges && existing > 0) setRequestProperty("Range", "bytes=$existing-")
                }
                try {
                    val code = connection.responseCode
                    val appending = supportsRanges && existing > 0 && code == HttpURLConnection.HTTP_PARTIAL
                    if (existing > 0 && supportsRanges && !appending) {
                        output.delete()
                        downloaded.set(0L)
                        existing = 0L
                    }
                    if (code !in 200..299) error("Download failed with HTTP $code")
                    val resolvedTotal = if (totalBytes > 0) totalBytes else {
                        if (appending) existing + connection.contentLengthLong else connection.contentLengthLong
                    }
                    BufferedInputStream(connection.inputStream, BUFFER_SIZE).use { input ->
                        BufferedOutputStream(FileOutputStream(output, appending), BUFFER_SIZE).use { out ->
                            copyWithState(input, out, pauseRequested, cancelled) { count ->
                                val delta = count.toLong()
                                val current = downloaded.addAndGet(delta)
                                addRouteBytes(route.label, delta, wifiSessionBytes, mobileSessionBytes)
                                onProgress(
                                    Progress(
                                        current,
                                        resolvedTotal,
                                        withMeasuredNetworkShare(progressMessage, wifiSessionBytes, mobileSessionBytes)
                                    )
                                )
                            }
                        }
                    }
                    return
                } finally {
                    connection.disconnect()
                }
            } catch (t: Throwable) {
                when (t) {
                    is DownloadPausedException -> throw t
                    is DownloadCancelledException -> throw t
                }
                lastError = t
                if (routeIndex < routes.lastIndex) Thread.sleep(500)
            }
        }
        throw IllegalStateException("Download failed on all available networks.", lastError)
    }

    private fun copyWithState(
        input: BufferedInputStream,
        output: BufferedOutputStream,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean,
        shouldYield: () -> Boolean = { false },
        onBytes: (Int) -> Unit
    ) {
        val buffer = ByteArray(BUFFER_SIZE)
        var pendingProgressBytes = 0
        var lastProgressReportNanos = System.nanoTime()

        while (true) {
            ensureRunning(pauseRequested, cancelled)
            if (shouldYield()) {
                if (pendingProgressBytes > 0) {
                    onBytes(pendingProgressBytes)
                    pendingProgressBytes = 0
                }
                output.flush()
                throw WorkerYieldException()
            }
            val read = input.read(buffer)
            if (read == -1) break
            output.write(buffer, 0, read)
            pendingProgressBytes += read

            // Alpha 0.4.4: never push a DB/notification/UI update for every socket read.
            // Network streams can return many tiny reads, especially with several workers.
            // Batch progress so downloader threads spend their time moving bytes instead.
            val now = System.nanoTime()
            if (pendingProgressBytes >= PROGRESS_BATCH_BYTES ||
                now - lastProgressReportNanos >= PROGRESS_BATCH_NANOS
            ) {
                onBytes(pendingProgressBytes)
                pendingProgressBytes = 0
                lastProgressReportNanos = now
            }
        }

        if (pendingProgressBytes > 0) onBytes(pendingProgressBytes)
    }

    private fun publishToDownloads(
        workDir: File,
        partCount: Int,
        fileName: String,
        mimeType: String,
        cancelled: AtomicBoolean
    ): Uri {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName)
            put(MediaStore.Downloads.MIME_TYPE, mimeType)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MultiFetch")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }

        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Android could not create the output file.")
        try {
            resolver.openOutputStream(uri, "w")?.use { rawOut ->
                BufferedOutputStream(rawOut, BUFFER_SIZE).use { out ->
                    for (index in 0 until partCount) {
                        if (cancelled.get()) throw DownloadCancelledException()
                        val part = File(workDir, "part_$index.tmp")
                        require(part.exists()) { "Missing segment $index" }
                        part.inputStream().buffered(BUFFER_SIZE).use { input ->
                            input.copyTo(out, BUFFER_SIZE)
                        }
                    }
                }
            } ?: error("Unable to open output stream.")

            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return uri
        } catch (t: Throwable) {
            resolver.delete(uri, null, null)
            throw t
        }
    }

    private fun open(url: URL, route: NetworkRouter.Route): HttpURLConnection =
        route.open(url).apply {
            connectTimeout = 15_000
            readTimeout = 25_000
            instanceFollowRedirects = true
            useCaches = false
            setRequestProperty("Accept-Encoding", "identity")
            setRequestProperty("Connection", "keep-alive")
            setRequestProperty("User-Agent", "MultiFetch/0.4.5 Android")
        }

    private fun addRouteBytes(
        routeLabel: String,
        delta: Long,
        wifiBytes: AtomicLong,
        mobileBytes: AtomicLong
    ) {
        when (routeLabel) {
            "Wi‑Fi" -> wifiBytes.addAndGet(delta)
            "Mobile" -> mobileBytes.addAndGet(delta)
        }
    }

    private fun withMeasuredNetworkShare(
        base: String,
        wifiBytes: AtomicLong,
        mobileBytes: AtomicLong
    ): String {
        val wifi = wifiBytes.get().coerceAtLeast(0L)
        val mobile = mobileBytes.get().coerceAtLeast(0L)
        val total = wifi + mobile
        if (total <= 0L) return base
        val wifiPct = ((wifi * 100L) / total).toInt().coerceIn(0, 100)
        val mobilePct = 100 - wifiPct
        return "$base • WiFi $wifiPct% • Mobile $mobilePct%"
    }

    private fun activeMessage(networkLabel: String, turboMode: Boolean): String =
        "Downloading • $networkLabel${if (turboMode) " • Turbo" else ""}"

    private fun parseTotalFromContentRange(value: String?): Long {
        if (value.isNullOrBlank()) return -1L
        return value.substringAfter('/', "").toLongOrNull() ?: -1L
    }

    private fun extractFileName(connection: HttpURLConnection, url: URL): String {
        val disposition = connection.getHeaderField("Content-Disposition").orEmpty()
        val encoded = Regex("filename\\*=UTF-8''([^;]+)", RegexOption.IGNORE_CASE)
            .find(disposition)?.groupValues?.getOrNull(1)
        val plain = Regex("filename=\"?([^\";]+)", RegexOption.IGNORE_CASE)
            .find(disposition)?.groupValues?.getOrNull(1)

        val candidate = encoded?.let {
            runCatching { URLDecoder.decode(it, StandardCharsets.UTF_8.name()) }.getOrNull()
        } ?: plain ?: url.path.substringAfterLast('/').substringBefore('?')

        return sanitizeFileName(candidate.ifBlank { "download_${System.currentTimeMillis()}" })
    }

    private fun sanitizeFileName(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .take(180)
            .ifBlank { "download_${System.currentTimeMillis()}" }

    private fun ensureRunning(pauseRequested: AtomicBoolean, cancelled: AtomicBoolean) {
        if (cancelled.get()) throw DownloadCancelledException()
        if (pauseRequested.get()) throw DownloadPausedException()
        if (Thread.currentThread().isInterrupted) {
            if (pauseRequested.get()) throw DownloadPausedException()
            if (cancelled.get()) throw DownloadCancelledException()
        }
    }

    private fun unwrap(t: Throwable): Throwable {
        var current = t
        while (current.cause != null && current !is DownloadPausedException && current !is DownloadCancelledException) {
            current = current.cause!!
        }
        return current
    }

    companion object {
        private const val BUFFER_SIZE = 512 * 1024
        private const val PROGRESS_BATCH_BYTES = 256 * 1024
        private const val PROGRESS_BATCH_NANOS = 250_000_000L
        private const val MIB = 1024 * 1024
        private const val MAX_PARTS = 96
        private const val AUTO_TURBO_WARMUP_MS = 2_000L
        private const val AUTO_TURBO_SAMPLE_MS = 4_000L
        private const val AUTO_TURBO_DROP_PERCENT = 72L
    }
}
