package com.multifetch.app.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import java.io.Closeable
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

class NetworkRouter(context: Context) {
    private val connectivity = context.applicationContext
        .getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    data class Route(
        val label: String,
        val network: Network?
    ) {
        fun open(url: URL): HttpURLConnection = if (network != null) {
            network.openConnection(url) as HttpURLConnection
        } else {
            url.openConnection() as HttpURLConnection
        }
    }

    class Session internal constructor(
        val routes: List<Route>,
        private val connectivity: ConnectivityManager,
        private val callbacks: List<ConnectivityManager.NetworkCallback>
    ) : Closeable {
        val label: String = when {
            routes.any { it.label == "Wi‑Fi" } && routes.any { it.label == "Mobile" } -> "Wi‑Fi + Mobile"
            routes.any { it.label == "Wi‑Fi" } -> "Wi‑Fi"
            routes.any { it.label == "Mobile" } -> "Mobile"
            else -> "Default network"
        }

        override fun close() {
            callbacks.forEach { callback ->
                runCatching { connectivity.unregisterNetworkCallback(callback) }
            }
        }
    }

    fun acquire(combineWifiAndCellular: Boolean, timeoutMs: Long = 5_000): Session {
        if (!combineWifiAndCellular) {
            val active = connectivity.activeNetwork
            val label = transportLabel(active) ?: "Default network"
            return Session(listOf(Route(label, active)), connectivity, emptyList())
        }

        val callbacks = mutableListOf<ConnectivityManager.NetworkCallback>()
        val routes = mutableListOf<Route>()

        val wifi = findExisting(NetworkCapabilities.TRANSPORT_WIFI)
            ?: requestTransport(NetworkCapabilities.TRANSPORT_WIFI, timeoutMs, callbacks)
        val cellular = findExisting(NetworkCapabilities.TRANSPORT_CELLULAR)
            ?: requestTransport(NetworkCapabilities.TRANSPORT_CELLULAR, timeoutMs, callbacks)

        if (wifi != null) routes += Route("Wi‑Fi", wifi)
        if (cellular != null && cellular != wifi) routes += Route("Mobile", cellular)

        if (routes.isEmpty()) {
            val active = connectivity.activeNetwork
            routes += Route(transportLabel(active) ?: "Default network", active)
        }

        return Session(routes.distinctBy { it.network }, connectivity, callbacks)
    }

    private fun findExisting(transport: Int): Network? = connectivity.allNetworks.firstOrNull { network ->
        val caps = connectivity.getNetworkCapabilities(network) ?: return@firstOrNull false
        caps.hasTransport(transport) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun requestTransport(
        transport: Int,
        timeoutMs: Long,
        callbacks: MutableList<ConnectivityManager.NetworkCallback>
    ): Network? {
        val result = AtomicReference<Network?>(null)
        val latch = CountDownLatch(1)
        val request = NetworkRequest.Builder()
            .addTransportType(transport)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                if (result.compareAndSet(null, network)) latch.countDown()
            }

            override fun onUnavailable() {
                latch.countDown()
            }
        }

        return try {
            connectivity.requestNetwork(request, callback)
            callbacks += callback
            latch.await(timeoutMs, TimeUnit.MILLISECONDS)
            result.get()
        } catch (_: SecurityException) {
            runCatching { connectivity.unregisterNetworkCallback(callback) }
            callbacks.remove(callback)
            null
        } catch (_: Throwable) {
            runCatching { connectivity.unregisterNetworkCallback(callback) }
            callbacks.remove(callback)
            null
        }
    }

    private fun transportLabel(network: Network?): String? {
        val caps = network?.let(connectivity::getNetworkCapabilities) ?: return null
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi‑Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Default network"
        }
    }
}
