package com.multifetch.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.multifetch.app.download.DownloadStatus
import com.multifetch.app.download.DownloadStore
import com.multifetch.app.download.DownloadTask

class MainActivity : ComponentActivity() {

    private lateinit var store: DownloadStore
    private lateinit var settings: SettingsStore
    private var tasks by mutableStateOf<List<DownloadTask>>(emptyList())
    private var initialUrl by mutableStateOf("")
    private var inputMessage by mutableStateOf("")
    private var turboMode by mutableStateOf(true)
    private var combineNetworks by mutableStateOf(false)

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    private val queueReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == DownloadService.ACTION_QUEUE_CHANGED) refreshTasks()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = DownloadStore(applicationContext)
        settings = SettingsStore(applicationContext)
        turboMode = settings.turboMode
        combineNetworks = settings.combineWifiAndCellular
        initialUrl = extractSharedUrl(intent)
        requestNotificationPermissionIfNeeded()
        refreshTasks()
        recoverQueue()

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    DownloadScreen(
                        initialUrl = initialUrl,
                        tasks = tasks,
                        inputMessage = inputMessage,
                        turboMode = turboMode,
                        combineNetworks = combineNetworks,
                        onTurboModeChange = { enabled ->
                            turboMode = enabled
                            settings.turboMode = enabled
                        },
                        onCombineNetworksChange = { enabled ->
                            combineNetworks = enabled
                            settings.combineWifiAndCellular = enabled
                        },
                        onQueue = ::queueDownload,
                        onPause = { control(DownloadService.ACTION_PAUSE, it) },
                        onResume = { control(DownloadService.ACTION_RESUME, it) },
                        onCancel = { control(DownloadService.ACTION_CANCEL, it) },
                        onRetry = { control(DownloadService.ACTION_RETRY, it) },
                        onOpen = ::openCompletedFile
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val shared = extractSharedUrl(intent)
        if (shared.isNotBlank()) initialUrl = shared
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(
            this,
            queueReceiver,
            IntentFilter(DownloadService.ACTION_QUEUE_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        refreshTasks()
    }

    override fun onStop() {
        runCatching { unregisterReceiver(queueReceiver) }
        super.onStop()
    }

    override fun onDestroy() {
        store.close()
        super.onDestroy()
    }

    private fun queueDownload(url: String) {
        val clean = url.trim()
        if (!(clean.startsWith("http://") || clean.startsWith("https://"))) {
            inputMessage = "Enter a valid http/https direct link."
            return
        }
        val task = store.enqueue(clean)
        inputMessage = "Added to queue"
        refreshTasks()
        val intent = Intent(this, DownloadService::class.java).apply {
            action = DownloadService.ACTION_ENQUEUE
            putExtra(DownloadService.EXTRA_TASK_ID, task.id)
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun recoverQueue() {
        if (tasks.none { it.status == DownloadStatus.QUEUED || it.status == DownloadStatus.DOWNLOADING }) return
        val intent = Intent(this, DownloadService::class.java).apply {
            action = DownloadService.ACTION_RECOVER
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun control(action: String, taskId: String) {
        val intent = Intent(this, DownloadService::class.java).apply {
            this.action = action
            putExtra(DownloadService.EXTRA_TASK_ID, taskId)
        }
        if (action == DownloadService.ACTION_RESUME || action == DownloadService.ACTION_RETRY) {
            ContextCompat.startForegroundService(this, intent)
        } else {
            startService(intent)
        }
    }

    private fun refreshTasks() {
        tasks = runCatching { store.getAll() }.getOrDefault(emptyList())
    }

    private fun openCompletedFile(task: DownloadTask) {
        val uri = task.outputUri?.let(Uri::parse) ?: return
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, task.mimeType ?: "application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { startActivity(intent) }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun extractSharedUrl(intent: Intent?): String {
        if (intent?.action != Intent.ACTION_SEND || intent.type != "text/plain") return ""
        val text = intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
        return Regex("https?://\\S+").find(text)?.value.orEmpty().trimEnd('.', ',', ')', ']')
    }
}

@androidx.compose.runtime.Composable
private fun DownloadScreen(
    initialUrl: String,
    tasks: List<DownloadTask>,
    inputMessage: String,
    turboMode: Boolean,
    combineNetworks: Boolean,
    onTurboModeChange: (Boolean) -> Unit,
    onCombineNetworksChange: (Boolean) -> Unit,
    onQueue: (String) -> Unit,
    onPause: (String) -> Unit,
    onResume: (String) -> Unit,
    onCancel: (String) -> Unit,
    onRetry: (String) -> Unit,
    onOpen: (DownloadTask) -> Unit
) {
    var url by androidx.compose.runtime.remember(initialUrl) { mutableStateOf(initialUrl) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(8.dp))
        Text("MultiFetch", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text(
            "Multi-network segmented download manager • Alpha 0.3",
            style = MaterialTheme.typography.bodyMedium
        )

        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Direct download URL") },
            placeholder = { Text("https://example.com/file.zip") },
            minLines = 2
        )

        Button(
            onClick = { onQueue(url) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Add to download queue")
        }

        if (inputMessage.isNotBlank()) {
            Text(inputMessage, style = MaterialTheme.typography.bodySmall)
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Speed & network", fontWeight = FontWeight.SemiBold)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Turbo Mode", fontWeight = FontWeight.Medium)
                        Text(
                            "Aggressive parallel downloading to use as much available bandwidth as possible.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Switch(checked = turboMode, onCheckedChange = onTurboModeChange)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Combine Wi‑Fi + mobile data", fontWeight = FontWeight.Medium)
                        Text(
                            "Routes different segments over both networks when Android/device/carrier allows it. Uses mobile data.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Switch(checked = combineNetworks, onCheckedChange = onCombineNetworksChange)
                }

                Text(
                    "Settings apply when the next queued/resumed download starts.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Text("Downloads", fontWeight = FontWeight.SemiBold)

        if (tasks.isEmpty()) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Text("No downloads yet.", modifier = Modifier.padding(18.dp))
            }
        } else {
            tasks.forEach { task ->
                DownloadCard(
                    task = task,
                    onPause = { onPause(task.id) },
                    onResume = { onResume(task.id) },
                    onCancel = { onCancel(task.id) },
                    onRetry = { onRetry(task.id) },
                    onOpen = { onOpen(task) }
                )
            }
        }

        Text("Alpha 0.3 engine", fontWeight = FontWeight.SemiBold)
        Text(
            "• Wi‑Fi + mobile-data per-segment routing\n" +
                "• Turbo Mode uses up to 16 parallel segments\n" +
                "• Automatic fallback if one route fails\n" +
                "• Persistent queue and byte-level resume\n" +
                "• Pause / retry keeps partial segment data\n" +
                "• Saves final files to Downloads/MultiFetch"
        )

        Text(
            "Android cannot reserve 100% of system bandwidth for one app, but Turbo Mode aggressively fills available capacity.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@androidx.compose.runtime.Composable
private fun DownloadCard(
    task: DownloadTask,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    onRetry: () -> Unit,
    onOpen: () -> Unit
) {
    val progress = if (task.totalBytes > 0) {
        (task.downloadedBytes.toFloat() / task.totalBytes.toFloat()).coerceIn(0f, 1f)
    } else 0f

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                task.fileName ?: shortUrl(task.url),
                fontWeight = FontWeight.SemiBold
            )
            Text(statusLabel(task.status), style = MaterialTheme.typography.labelMedium)

            if (task.status == DownloadStatus.DOWNLOADING ||
                task.status == DownloadStatus.PAUSED ||
                task.status == DownloadStatus.COMPLETED ||
                task.downloadedBytes > 0
            ) {
                if (task.totalBytes > 0) {
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        "${(progress * 100).toInt()}% • ${formatBytes(task.downloadedBytes)} / ${formatBytes(task.totalBytes)}"
                    )
                } else if (task.status == DownloadStatus.DOWNLOADING) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
            }

            if (task.segmentCount > 1 && task.totalBytes > 0) {
                Text("${task.segmentCount} parallel segments", style = MaterialTheme.typography.bodySmall)
            }
            Text(task.message.ifBlank { statusLabel(task.status) })

            when (task.status) {
                DownloadStatus.DOWNLOADING -> {
                    Row(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = onPause, modifier = Modifier.weight(1f)) {
                            Text("Pause")
                        }
                        Spacer(Modifier.width(10.dp))
                        OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) {
                            Text("Cancel")
                        }
                    }
                }

                DownloadStatus.QUEUED -> {
                    OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) {
                        Text("Cancel")
                    }
                }

                DownloadStatus.PAUSED -> {
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = onResume, modifier = Modifier.weight(1f)) {
                            Text("Resume")
                        }
                        Spacer(Modifier.width(10.dp))
                        OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) {
                            Text("Cancel")
                        }
                    }
                }

                DownloadStatus.FAILED -> {
                    Button(onClick = onRetry, modifier = Modifier.fillMaxWidth()) {
                        Text("Retry from saved progress")
                    }
                }

                DownloadStatus.CANCELLED -> {
                    OutlinedButton(onClick = onRetry, modifier = Modifier.fillMaxWidth()) {
                        Text("Download again")
                    }
                }

                DownloadStatus.COMPLETED -> {
                    Button(onClick = onOpen, modifier = Modifier.fillMaxWidth()) {
                        Text("Open file")
                    }
                }
            }
        }
    }
}

private fun statusLabel(status: DownloadStatus): String = when (status) {
    DownloadStatus.QUEUED -> "Queued"
    DownloadStatus.DOWNLOADING -> "Downloading"
    DownloadStatus.PAUSED -> "Paused"
    DownloadStatus.COMPLETED -> "Completed"
    DownloadStatus.FAILED -> "Failed"
    DownloadStatus.CANCELLED -> "Cancelled"
}

private fun shortUrl(url: String): String = url
    .removePrefix("https://")
    .removePrefix("http://")
    .take(70)

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1024L * 1024L * 1024L -> String.format("%.2f GB", bytes / 1024.0 / 1024.0 / 1024.0)
    bytes >= 1024L * 1024L -> String.format("%.1f MB", bytes / 1024.0 / 1024.0)
    bytes >= 1024L -> String.format("%.0f KB", bytes / 1024.0)
    bytes >= 0 -> "$bytes B"
    else -> "Unknown"
}
