# MultiFetch Android — Alpha 0.3

Alpha 0.3 adds the first multi-network download engine and an aggressive Turbo Mode.

## Phase 3 features

- Per-segment Android network routing.
- Optional Wi-Fi + cellular simultaneous downloading when the device/carrier allows both networks to stay active.
- Automatic route fallback: a failed segment retries through another available route.
- Turbo Mode enabled by default: larger buffers and up to 16 parallel HTTP range segments to aggressively consume available download bandwidth.
- Persistent queue and byte-level segment resume from Alpha 0.2.
- Pause, resume, retry, notifications, speed display, history, and Downloads/MultiFetch publishing.

## Important Android limitation

Android does not expose a supported API that lets one normal app reserve 100% of the device's bandwidth or block every other app from networking. Turbo Mode instead increases parallelism and removes app-side throttling so MultiFetch can aggressively fill available capacity. Results depend on the server, Wi-Fi/mobile networks, Android device firmware, carrier policy, and whether the server supports HTTP Range requests.

Combining Wi-Fi and cellular may use paid mobile data and is therefore OFF by default. Turbo Mode is ON by default.
