# MultiFetch Android — Alpha 0.4

Phase 4 adds the premium dashboard UI and Android link-capture workflow while retaining the Alpha 0.3 multi-network download engine.

## Alpha 0.4
- New light premium dashboard inspired by the approved UI reference
- User-provided MultiFetch logo in app header and launcher icon
- Home / Queue / Connections / Settings bottom navigation
- Total speed summary and active-download dashboard
- Network share visualization and active route cards
- URL / Magnet / .Torrent intake tiles
- Browser/app Share -> MultiFetch support
- Android Open with support for HTTP/HTTPS links
- Duplicate URL detection
- File category badges
- Queue controls: pause, resume, retry, cancel, pause all, resume all, clear completed
- Completed file actions: open, share, delete
- Persistent queue + byte resume retained
- Turbo Mode retained (up to 32 segments)
- Wi-Fi + mobile-data per-segment routing retained

## Torrent note
Magnet and .torrent intake UI is present in Alpha 0.4. The actual BitTorrent engine is planned for Phase 5.

## Output
Completed direct downloads are saved to `Downloads/MultiFetch`.


## Alpha 0.4.1 stability fixes
- Search icon is now functional and searches file names, URLs, and statuses.
- Overflow (three-dot) menu now opens working quick actions.
- Cancelled/failed queue items now include Delete as well as Retry.
- Delete removes saved partial segment workspace for cancelled/failed items.
- Network cards now distinguish Connected, Available, Combined, and Offline.
- Mobile Data is no longer labelled Connected just because Android exposes a cellular network.
- Combine Wi-Fi + Mobile reports ACTIVE only when the download engine actually acquired both validated routes.
- Network share percentages are measured from bytes routed over Wi-Fi vs Mobile during the current session instead of using fixed fake percentages.
- Turbo status now shows ACTIVE only for a running multi-part download; fresh large downloads may use up to 32 segments.
- Turbo/Combine changes apply when a fresh download starts; an existing partial download keeps its segment layout for safe resume.


## Alpha 0.4.2 browser integration
- In-app browser tab with address/search bar, back, forward and reload.
- WebView DownloadListener sends normal website downloads into MultiFetch.
- Current page URL can be sent to Add Download.

## Alpha 0.4.3 Adaptive Turbo + stability
- Reworked fixed segmentation into a dynamic chunk queue so active workers keep pulling new chunks.
- Turbo uses up to 12 active connections on one network, or up to 16 when Wi-Fi + Mobile are both actually acquired.
- Large files are split into more resumable chunks (up to 96) to reduce slow-tail collapse near the end.
- Wi-Fi is weighted 3:1 over mobile in combine mode by default so a slower cellular link is less likely to become the tail bottleneck.
- CPU wake lock + high-performance Wi-Fi lock while a foreground download is active, improving screen-off/background throughput stability.
- Larger 512 KiB I/O buffer and faster stalled-connection recovery.
- Smoothed speed display so a short startup burst is less likely to be shown as the sustained rate.
- Browser now intercepts common direct-file links before WebView tries to navigate to them.

Important: MultiFetch can keep its own downloader from under-utilizing the connection, but it cannot force a server, ISP, Wi-Fi link, or mobile network to sustain a speed they are not offering.
