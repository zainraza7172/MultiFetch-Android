package com.multifetch.app.download

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.max
import kotlin.math.min

class DownloadEngine(private val context: Context) {

    data class Progress(
        val downloadedBytes: Long,
        val totalBytes: Long,
        val message: String
    )

    data class Result(
        val uri: Uri,
        val fileName: String,
        val totalBytes: Long,
        val usedSegments: Int
    )

    private data class Probe(
        val totalBytes: Long,
        val supportsRanges: Boolean,
        val fileName: String,
        val mimeType: String
    )

    fun download(
        rawUrl: String,
        paused: AtomicBoolean,
        cancelled: AtomicBoolean,
        onProgress: (Progress) -> Unit
    ): Result {
        val url = validateUrl(rawUrl)
        onProgress(Progress(0, -1, "Checking server…"))
        val probe = probe(url)

        val workDir = File(context.cacheDir, "multifetch/${UUID.randomUUID()}").apply { mkdirs() }
        try {
            val segments = chooseSegmentCount(probe.totalBytes, probe.supportsRanges)
            val downloaded = AtomicLong(0L)

            if (segments > 1) {
                onProgress(Progress(0, probe.totalBytes, "Downloading with $segments segments"))
                downloadSegmented(
                    url = url,
                    totalBytes = probe.totalBytes,
                    segmentCount = segments,
                    workDir = workDir,
                    paused = paused,
                    cancelled = cancelled,
                    downloaded = downloaded,
                    onProgress = onProgress
                )
            } else {
                onProgress(Progress(0, probe.totalBytes, "Downloading"))
                downloadSingle(
                    url = url,
                    output = File(workDir, "part_0.tmp"),
                    paused = paused,
                    cancelled = cancelled,
                    downloaded = downloaded,
                    totalBytes = probe.totalBytes,
                    onProgress = onProgress
                )
            }

            ensureNotCancelled(cancelled)
            onProgress(Progress(downloaded.get(), probe.totalBytes, "Saving to Downloads…"))
            val uri = publishToDownloads(
                workDir = workDir,
                partCount = segments,
                fileName = probe.fileName,
                mimeType = probe.mimeType,
                cancelled = cancelled
            )
            onProgress(Progress(probe.totalBytes, probe.totalBytes, "Complete"))
            return Result(uri, probe.fileName, probe.totalBytes, segments)
        } finally {
            workDir.deleteRecursively()
        }
    }

    private fun validateUrl(raw: String): URL {
        val trimmed = raw.trim()
        require(trimmed.startsWith("https://") || trimmed.startsWith("http://")) {
            "Only http:// and https:// links are supported in this build."
        }
        return URL(trimmed)
    }

    private fun probe(url: URL): Probe {
        val connection = open(url).apply {
            setRequestProperty("Range", "bytes=0-0")
        }
        try {
            val code = connection.responseCode
            val contentRange = connection.getHeaderField("Content-Range")
            val totalFromRange = parseTotalFromContentRange(contentRange)
            val supportsRanges = code == HttpURLConnection.HTTP_PARTIAL && totalFromRange > 0
            val total = when {
                totalFromRange > 0 -> totalFromRange
                connection.contentLengthLong > 0 -> connection.contentLengthLong
                else -> -1L
            }
            val fileName = extractFileName(connection, url)
            val mime = connection.contentType?.substringBefore(';')?.trim()
                ?.takeIf { it.isNotBlank() }
                ?: "application/octet-stream"

            runCatching { connection.inputStream.close() }
            return Probe(total, supportsRanges, fileName, mime)
        } finally {
            connection.disconnect()
        }
    }

    private fun chooseSegmentCount(totalBytes: Long, supportsRanges: Boolean): Int {
        if (!supportsRanges || totalBytes <= 0) return 1
        return when {
            totalBytes < 4L * MIB -> 1
            totalBytes < 16L * MIB -> 2
            totalBytes < 64L * MIB -> 4
            else -> 8
        }
    }

    private fun downloadSegmented(
        url: URL,
        totalBytes: Long,
        segmentCount: Int,
        workDir: File,
        paused: AtomicBoolean,
        cancelled: AtomicBoolean,
        downloaded: AtomicLong,
        onProgress: (Progress) -> Unit
    ) {
        val executor = Executors.newFixedThreadPool(segmentCount)
        try {
            val chunk = totalBytes / segmentCount
            val tasks = (0 until segmentCount).map { index ->
                Callable {
                    val start = index * chunk
                    val end = if (index == segmentCount - 1) totalBytes - 1 else (start + chunk - 1)
                    val output = File(workDir, "part_$index.tmp")
                    downloadRangeWithRetry(
                        url, start, end, output, paused, cancelled, downloaded, totalBytes, onProgress
                    )
                }
            }
            val futures = executor.invokeAll(tasks)
            futures.forEach { it.get() }
        } finally {
            executor.shutdownNow()
        }
    }

    private fun downloadRangeWithRetry(
        url: URL,
        start: Long,
        end: Long,
        output: File,
        paused: AtomicBoolean,
        cancelled: AtomicBoolean,
        downloaded: AtomicLong,
        totalBytes: Long,
        onProgress: (Progress) -> Unit
    ) {
        var lastError: Throwable? = null
        repeat(3) { attempt ->
            ensureNotCancelled(cancelled)
            var attemptBytes = 0L
            try {
                if (output.exists()) output.delete()
                val connection = open(url).apply {
                    setRequestProperty("Range", "bytes=$start-$end")
                }
                try {
                    if (connection.responseCode != HttpURLConnection.HTTP_PARTIAL) {
                        error("Server stopped supporting range requests (HTTP ${connection.responseCode}).")
                    }
                    BufferedInputStream(connection.inputStream, BUFFER_SIZE).use { input ->
                        BufferedOutputStream(FileOutputStream(output), BUFFER_SIZE).use { out ->
                            copyWithState(input, out, paused, cancelled) { count ->
                                val delta = count.toLong()
                                attemptBytes += delta
                                val current = downloaded.addAndGet(delta)
                                onProgress(Progress(current, totalBytes, "Downloading"))
                            }
                        }
                    }
                    return
                } finally {
                    connection.disconnect()
                }
            } catch (t: Throwable) {
                if (attemptBytes > 0) downloaded.addAndGet(-attemptBytes)
                if (t is DownloadCancelledException) throw t
                lastError = t
                if (attempt < 2) Thread.sleep(700L * (attempt + 1))
            }
        }
        throw IllegalStateException("A download segment failed after 3 attempts.", lastError)
    }

    private fun downloadSingle(
        url: URL,
        output: File,
        paused: AtomicBoolean,
        cancelled: AtomicBoolean,
        downloaded: AtomicLong,
        totalBytes: Long,
        onProgress: (Progress) -> Unit
    ) {
        val connection = open(url)
        try {
            val code = connection.responseCode
            if (code !in 200..299) error("Download failed with HTTP $code")
            val resolvedTotal = if (totalBytes > 0) totalBytes else connection.contentLengthLong
            BufferedInputStream(connection.inputStream, BUFFER_SIZE).use { input ->
                BufferedOutputStream(FileOutputStream(output), BUFFER_SIZE).use { out ->
                    copyWithState(input, out, paused, cancelled) { count ->
                        val current = downloaded.addAndGet(count.toLong())
                        onProgress(Progress(current, resolvedTotal, "Downloading"))
                    }
                }
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun copyWithState(
        input: BufferedInputStream,
        output: BufferedOutputStream,
        paused: AtomicBoolean,
        cancelled: AtomicBoolean,
        onBytes: (Int) -> Unit
    ) {
        val buffer = ByteArray(BUFFER_SIZE)
        while (true) {
            ensureNotCancelled(cancelled)
            while (paused.get()) {
                ensureNotCancelled(cancelled)
                Thread.sleep(150)
            }
            val read = input.read(buffer)
            if (read == -1) break
            output.write(buffer, 0, read)
            onBytes(read)
        }
    }

    private fun publishToDownloads(
        workDir: File,
        partCount: Int,
        fileName: String,
        mimeType: String,
        cancelled: AtomicBoolean
    ): Uri {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName)
            put(MediaStore.Downloads.MIME_TYPE, mimeType)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MultiFetch")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }

        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Android could not create the output file.")
        try {
            resolver.openOutputStream(uri, "w")?.use { rawOut ->
                BufferedOutputStream(rawOut, BUFFER_SIZE).use { out ->
                    for (index in 0 until partCount) {
                        ensureNotCancelled(cancelled)
                        val part = File(workDir, "part_$index.tmp")
                        require(part.exists()) { "Missing segment $index" }
                        part.inputStream().buffered(BUFFER_SIZE).use { input ->
                            input.copyTo(out, BUFFER_SIZE)
                        }
                    }
                }
            } ?: error("Unable to open output stream.")

            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return uri
        } catch (t: Throwable) {
            resolver.delete(uri, null, null)
            throw t
        }
    }

    private fun open(url: URL): HttpURLConnection =
        (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 30_000
            instanceFollowRedirects = true
            useCaches = false
            setRequestProperty("Accept-Encoding", "identity")
            setRequestProperty("User-Agent", "MultiFetch/0.1 Android")
        }

    private fun parseTotalFromContentRange(value: String?): Long {
        if (value.isNullOrBlank()) return -1L
        return value.substringAfter('/', "").toLongOrNull() ?: -1L
    }

    private fun extractFileName(connection: HttpURLConnection, url: URL): String {
        val disposition = connection.getHeaderField("Content-Disposition").orEmpty()
        val encoded = Regex("filename\\*=UTF-8''([^;]+)", RegexOption.IGNORE_CASE)
            .find(disposition)?.groupValues?.getOrNull(1)
        val plain = Regex("filename=\"?([^\";]+)", RegexOption.IGNORE_CASE)
            .find(disposition)?.groupValues?.getOrNull(1)

        val candidate = encoded?.let {
            runCatching { URLDecoder.decode(it, StandardCharsets.UTF_8.name()) }.getOrNull()
        } ?: plain ?: url.path.substringAfterLast('/').substringBefore('?')

        return sanitizeFileName(candidate.ifBlank { "download_${System.currentTimeMillis()}" })
    }

    private fun sanitizeFileName(name: String): String {
        return name.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(180)
            .ifBlank { "download_${System.currentTimeMillis()}" }
    }

    private fun ensureNotCancelled(cancelled: AtomicBoolean) {
        if (cancelled.get() || Thread.currentThread().isInterrupted) {
            throw DownloadCancelledException()
        }
    }

    private class DownloadCancelledException : RuntimeException("Download cancelled")

    companion object {
        private const val BUFFER_SIZE = 64 * 1024
        private const val MIB = 1024 * 1024
    }
}
