package com.multifetch.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.multifetch.app.download.DownloadEngine
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

class DownloadService : Service() {

    private val worker = Executors.newSingleThreadExecutor()
    private val paused = AtomicBoolean(false)
    private val cancelled = AtomicBoolean(false)

    @Volatile
    private var running = false

    private var lastNotifyAt = 0L
    private var lastSpeedAt = 0L
    private var lastSpeedBytes = 0L
    private var currentSpeed = 0L

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PAUSE -> {
                paused.set(true)
                sendState("Paused", -1, -1, true, false)
            }
            ACTION_RESUME -> {
                paused.set(false)
                sendState("Downloading", -1, -1, false, false)
            }
            ACTION_CANCEL -> {
                cancelled.set(true)
                paused.set(false)
                sendState("Cancelling…", -1, -1, false, false)
            }
            ACTION_START -> {
                val url = intent.getStringExtra(EXTRA_URL).orEmpty()
                if (url.isNotBlank()) startDownload(url)
            }
        }
        return START_NOT_STICKY
    }

    private fun startDownload(url: String) {
        if (running) {
            sendState("A download is already running", -1, -1, paused.get(), true)
            return
        }

        running = true
        paused.set(false)
        cancelled.set(false)
        lastNotifyAt = 0L
        lastSpeedAt = System.currentTimeMillis()
        lastSpeedBytes = 0L
        currentSpeed = 0L

        val initial = notification("Preparing…", 0, 0, indeterminate = true)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, initial, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, initial)
        }

        worker.execute {
            var keepFinalNotification = false
            try {
                val engine = DownloadEngine(applicationContext)
                val result = engine.download(url, paused, cancelled) { progress ->
                    updateProgress(progress.downloadedBytes, progress.totalBytes, progress.message)
                }
                running = false
                sendState(
                    message = "Saved: ${result.fileName}",
                    downloaded = result.totalBytes,
                    total = result.totalBytes,
                    isPaused = false,
                    isError = false,
                    isComplete = true
                )
                NotificationManagerCompat.from(this).notify(
                    NOTIFICATION_ID,
                    completionNotification(result.fileName)
                )
                keepFinalNotification = true
            } catch (t: Throwable) {
                val cancelledByUser = cancelled.get()
                running = false
                val message = if (cancelledByUser) "Download cancelled" else (t.message ?: "Download failed")
                sendState(message, -1, -1, false, !cancelledByUser)
                if (!cancelledByUser) {
                    NotificationManagerCompat.from(this).notify(
                        NOTIFICATION_ID,
                        failureNotification(message)
                    )
                    keepFinalNotification = true
                }
            } finally {
                if (keepFinalNotification) {
                    stopForeground(STOP_FOREGROUND_DETACH)
                } else {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                }
                stopSelf()
            }
        }
    }

    private fun updateProgress(downloaded: Long, total: Long, message: String) {
        val now = System.currentTimeMillis()
        if (now - lastSpeedAt >= 1000) {
            val seconds = max(1.0, (now - lastSpeedAt) / 1000.0)
            currentSpeed = ((downloaded - lastSpeedBytes) / seconds).toLong().coerceAtLeast(0L)
            lastSpeedAt = now
            lastSpeedBytes = downloaded
        }

        if (now - lastNotifyAt >= 350 || message != "Downloading") {
            lastNotifyAt = now
            val percent = if (total > 0) ((downloaded * 100) / total).toInt().coerceIn(0, 100) else 0
            val label = if (message == "Downloading" && currentSpeed > 0) {
                "$message • ${formatSpeed(currentSpeed)}"
            } else message
            NotificationManagerCompat.from(this).notify(
                NOTIFICATION_ID,
                notification(label, percent, 100, total <= 0)
            )
            sendState(label, downloaded, total, paused.get(), false)
        }
    }

    private fun notification(
        text: String,
        progress: Int,
        max: Int,
        indeterminate: Boolean
    ) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.stat_sys_download)
        .setContentTitle("MultiFetch")
        .setContentText(text)
        .setOnlyAlertOnce(true)
        .setOngoing(running)
        .setContentIntent(openAppPendingIntent())
        .setProgress(max, progress, indeterminate)
        .addAction(0, if (paused.get()) "Resume" else "Pause", controlPendingIntent(if (paused.get()) ACTION_RESUME else ACTION_PAUSE, 10))
        .addAction(0, "Cancel", controlPendingIntent(ACTION_CANCEL, 11))
        .build()

    private fun completionNotification(fileName: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.stat_sys_download_done)
        .setContentTitle("Download complete")
        .setContentText(fileName)
        .setAutoCancel(true)
        .setContentIntent(openAppPendingIntent())
        .build()


    private fun failureNotification(message: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.stat_notify_error)
        .setContentTitle("Download failed")
        .setContentText(message)
        .setAutoCancel(true)
        .setContentIntent(openAppPendingIntent())
        .build()

    private fun openAppPendingIntent(): PendingIntent {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            this, 1, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun controlPendingIntent(action: String, requestCode: Int): PendingIntent {
        val intent = Intent(this, DownloadService::class.java).setAction(action)
        return PendingIntent.getService(
            this, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun sendState(
        message: String,
        downloaded: Long,
        total: Long,
        isPaused: Boolean,
        isError: Boolean,
        isComplete: Boolean = false
    ) {
        val intent = Intent(ACTION_PROGRESS).apply {
            setPackage(packageName)
            putExtra(EXTRA_MESSAGE, message)
            putExtra(EXTRA_DOWNLOADED, downloaded)
            putExtra(EXTRA_TOTAL, total)
            putExtra(EXTRA_PAUSED, isPaused)
            putExtra(EXTRA_ERROR, isError)
            putExtra(EXTRA_COMPLETE, isComplete)
        }
        sendBroadcast(intent)
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Downloads",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Active MultiFetch downloads"
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun formatSpeed(bytesPerSecond: Long): String = when {
        bytesPerSecond >= 1024L * 1024L -> String.format("%.1f MB/s", bytesPerSecond / 1024.0 / 1024.0)
        bytesPerSecond >= 1024L -> String.format("%.0f KB/s", bytesPerSecond / 1024.0)
        else -> "$bytesPerSecond B/s"
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.multifetch.app.action.START"
        const val ACTION_PAUSE = "com.multifetch.app.action.PAUSE"
        const val ACTION_RESUME = "com.multifetch.app.action.RESUME"
        const val ACTION_CANCEL = "com.multifetch.app.action.CANCEL"
        const val ACTION_PROGRESS = "com.multifetch.app.action.PROGRESS"

        const val EXTRA_URL = "url"
        const val EXTRA_MESSAGE = "message"
        const val EXTRA_DOWNLOADED = "downloaded"
        const val EXTRA_TOTAL = "total"
        const val EXTRA_PAUSED = "paused"
        const val EXTRA_ERROR = "error"
        const val EXTRA_COMPLETE = "complete"

        private const val CHANNEL_ID = "downloads"
        private const val NOTIFICATION_ID = 1001
    }
}
