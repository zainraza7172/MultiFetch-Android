package com.multifetch.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private var uiState by mutableStateOf(DownloadUiState())
    private var initialUrl by mutableStateOf("")

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    private val progressReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != DownloadService.ACTION_PROGRESS) return
            val downloaded = intent.getLongExtra(DownloadService.EXTRA_DOWNLOADED, -1)
            val total = intent.getLongExtra(DownloadService.EXTRA_TOTAL, -1)
            val complete = intent.getBooleanExtra(DownloadService.EXTRA_COMPLETE, false)
            uiState = uiState.copy(
                message = intent.getStringExtra(DownloadService.EXTRA_MESSAGE).orEmpty(),
                downloaded = if (downloaded >= 0) downloaded else uiState.downloaded,
                total = if (total >= 0) total else uiState.total,
                paused = intent.getBooleanExtra(DownloadService.EXTRA_PAUSED, false),
                error = intent.getBooleanExtra(DownloadService.EXTRA_ERROR, false),
                running = !complete && !intent.getBooleanExtra(DownloadService.EXTRA_ERROR, false) &&
                    intent.getStringExtra(DownloadService.EXTRA_MESSAGE) != "Download cancelled",
                complete = complete
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initialUrl = extractSharedUrl(intent)
        requestNotificationPermissionIfNeeded()

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    DownloadScreen(
                        initialUrl = initialUrl,
                        state = uiState,
                        onStart = ::startDownload,
                        onPause = { sendControl(DownloadService.ACTION_PAUSE) },
                        onResume = { sendControl(DownloadService.ACTION_RESUME) },
                        onCancel = { sendControl(DownloadService.ACTION_CANCEL) }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val shared = extractSharedUrl(intent)
        if (shared.isNotBlank()) initialUrl = shared
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(
            this,
            progressReceiver,
            IntentFilter(DownloadService.ACTION_PROGRESS),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onStop() {
        runCatching { unregisterReceiver(progressReceiver) }
        super.onStop()
    }

    private fun startDownload(url: String) {
        val clean = url.trim()
        if (!(clean.startsWith("http://") || clean.startsWith("https://"))) {
            uiState = DownloadUiState(message = "Enter a valid http/https direct link.", error = true)
            return
        }
        uiState = DownloadUiState(message = "Starting…", running = true)
        val intent = Intent(this, DownloadService::class.java).apply {
            action = DownloadService.ACTION_START
            putExtra(DownloadService.EXTRA_URL, clean)
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun sendControl(action: String) {
        startService(Intent(this, DownloadService::class.java).setAction(action))
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun extractSharedUrl(intent: Intent?): String {
        if (intent?.action != Intent.ACTION_SEND || intent.type != "text/plain") return ""
        val text = intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
        return Regex("https?://\\S+").find(text)?.value.orEmpty().trimEnd('.', ',', ')', ']')
    }
}

private data class DownloadUiState(
    val message: String = "Ready",
    val downloaded: Long = 0,
    val total: Long = -1,
    val paused: Boolean = false,
    val error: Boolean = false,
    val running: Boolean = false,
    val complete: Boolean = false
)

@androidx.compose.runtime.Composable
private fun DownloadScreen(
    initialUrl: String,
    state: DownloadUiState,
    onStart: (String) -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit
) {
    var url by androidx.compose.runtime.remember(initialUrl) { mutableStateOf(initialUrl) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(8.dp))
        Text("MultiFetch", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text(
            "Android segmented download manager • Alpha 0.1",
            style = MaterialTheme.typography.bodyMedium
        )

        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Direct download URL") },
            placeholder = { Text("https://example.com/file.zip") },
            minLines = 2
        )

        Button(
            onClick = { onStart(url) },
            enabled = !state.running,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (state.running) "Download running" else "Start download")
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    when {
                        state.error -> "Problem"
                        state.complete -> "Completed"
                        state.paused -> "Paused"
                        state.running -> "Active download"
                        else -> "Status"
                    },
                    fontWeight = FontWeight.SemiBold
                )

                val progress = if (state.total > 0) {
                    (state.downloaded.toFloat() / state.total.toFloat()).coerceIn(0f, 1f)
                } else 0f

                if (state.running || state.complete) {
                    if (state.total > 0) {
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text("${(progress * 100).toInt()}% • ${formatBytes(state.downloaded)} / ${formatBytes(state.total)}")
                    } else {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                }

                Text(state.message.ifBlank { "Ready" })

                if (state.running) {
                    Row(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = if (state.paused) onResume else onPause,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (state.paused) "Resume" else "Pause")
                        }
                        Spacer(Modifier.width(10.dp))
                        OutlinedButton(
                            onClick = onCancel,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Cancel")
                        }
                    }
                }
            }
        }

        Text("V0.1 capabilities", fontWeight = FontWeight.SemiBold)
        Text("• HTTP/HTTPS direct links\n• Automatic 1/2/4/8-part downloads\n• Pause / resume while app is running\n• 3 retries per failed segment\n• Foreground download notification\n• Saves to Downloads/MultiFetch\n• Share a link from another app into MultiFetch")

        Text(
            "Next engine milestone: persistent queue + resume after process restart + Wi‑Fi/cellular network routing.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1024L * 1024L * 1024L -> String.format("%.2f GB", bytes / 1024.0 / 1024.0 / 1024.0)
    bytes >= 1024L * 1024L -> String.format("%.1f MB", bytes / 1024.0 / 1024.0)
    bytes >= 1024L -> String.format("%.0f KB", bytes / 1024.0)
    bytes >= 0 -> "$bytes B"
    else -> "Unknown"
}
