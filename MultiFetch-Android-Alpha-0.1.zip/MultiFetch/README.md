# MultiFetch Android — Alpha 0.1

A native Android segmented download manager prototype.

## What works in this alpha

- HTTP/HTTPS direct-download links
- Server capability probe using HTTP Range requests
- Automatic 1/2/4/8 segment selection
- Parallel segment downloads with 3 retries per segment
- Pause/resume while the process remains alive
- Cancel
- Foreground notification with progress and estimated live speed
- Saves completed files to `Downloads/MultiFetch`
- Android share-target support for text links
- GitHub Actions workflow that builds a debug APK

## Not implemented yet

- Persistence / restart-safe resume
- Multiple-download queue
- Per-download speed limiter
- Browser interception
- Wi-Fi + cellular simultaneous network routing
- Torrent / magnet support
- Release signing

## Mobile-only build using GitHub

1. Create a GitHub repository.
2. Upload the contents of this folder to the repository root.
3. Open **Actions** → **Build Android APK** → **Run workflow**.
4. When the workflow finishes, download the `MultiFetch-debug-apk` artifact.
5. Extract it and install `app-debug.apk` on Android.

The workflow installs Gradle 9.6 itself, generates a wrapper, then builds the app.

## Toolchain

- Android Gradle Plugin 9.4.0
- Gradle 9.6.0
- Kotlin / Compose Compiler plugin 2.4.10
- compileSdk 37 / targetSdk 36 / minSdk 29
- Compose BOM 2026.09.00

## Architecture

`MainActivity` → `DownloadService` → `DownloadEngine` → HTTP segment workers → MediaStore Downloads

The download engine is intentionally independent of the Compose UI so a future network-routing layer can bind specific segment connections to Wi-Fi or cellular networks.
