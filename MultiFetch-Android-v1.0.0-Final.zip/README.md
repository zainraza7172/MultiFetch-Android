# MultiFetch Android — Final Core 0.9.0

Final Core consolidates the working download manager, Torrent/Magnet engine, scheduler, network controls, Browser Shield, restart recovery, animated Light/Dark appearance, and optional SHA-256 verification. Browser feature expansion is frozen except for ad blocking.

## Alpha 0.4
- New light premium dashboard inspired by the approved UI reference
- User-provided MultiFetch logo in app header and launcher icon
- Home / Queue / Connections / Settings bottom navigation
- Total speed summary and active-download dashboard
- Network share visualization and active route cards
- URL / Magnet / .Torrent intake tiles
- Browser/app Share -> MultiFetch support
- Android Open with support for HTTP/HTTPS links
- Duplicate URL detection
- File category badges
- Queue controls: pause, resume, retry, cancel, pause all, resume all, clear completed
- Completed file actions: open, share, delete
- Persistent queue + byte resume retained
- Turbo Mode retained (up to 32 segments)
- Wi-Fi + mobile-data per-segment routing retained

## Torrent support
Alpha 0.7.0 adds a real libtorrent4j-backed BitTorrent engine for magnet links and `.torrent` files. MultiFetch downloads into an app-private resume workspace, reports peers/speed/progress, supports pause/cancel/retry, and publishes completed payload files into `Downloads/MultiFetch/Torrents`. MultiFetch does not bypass DRM and users are responsible for downloading content they have the right to access.

## Output
Completed direct downloads are saved to `Downloads/MultiFetch`.


## Alpha 0.4.1 stability fixes
- Search icon is now functional and searches file names, URLs, and statuses.
- Overflow (three-dot) menu now opens working quick actions.
- Cancelled/failed queue items now include Delete as well as Retry.
- Delete removes saved partial segment workspace for cancelled/failed items.
- Network cards now distinguish Connected, Available, Combined, and Offline.
- Mobile Data is no longer labelled Connected just because Android exposes a cellular network.
- Combine Wi-Fi + Mobile reports ACTIVE only when the download engine actually acquired both validated routes.
- Network share percentages are measured from bytes routed over Wi-Fi vs Mobile during the current session instead of using fixed fake percentages.
- Turbo status now shows ACTIVE only for a running multi-part download; fresh large downloads may use up to 32 segments.
- Turbo/Combine changes apply when a fresh download starts; an existing partial download keeps its segment layout for safe resume.


## Alpha 0.4.2 browser integration
- In-app browser tab with address/search bar, back, forward and reload.
- WebView DownloadListener sends normal website downloads into MultiFetch.
- Current page URL can be sent to Add Download.

## Alpha 0.4.5 Adaptive Turbo + stability
- Reworked fixed segmentation into a dynamic chunk queue so active workers keep pulling new chunks.
- Turbo uses up to 12 active connections on one network, or up to 16 when Wi-Fi + Mobile are both actually acquired.
- Large files are split into more resumable chunks (up to 96) to reduce slow-tail collapse near the end.
- Wi-Fi is weighted 3:1 over mobile in combine mode by default so a slower cellular link is less likely to become the tail bottleneck.
- CPU wake lock + high-performance Wi-Fi lock while a foreground download is active, improving screen-off/background throughput stability.
- Larger 512 KiB I/O buffer and faster stalled-connection recovery.
- Smoothed speed display so a short startup burst is less likely to be shown as the sustained rate.
- Browser now intercepts common direct-file links before WebView tries to navigate to them.

Important: MultiFetch can keep its own downloader from under-utilizing the connection, but it cannot force a server, ISP, Wi-Fi link, or mobile network to sustain a speed they are not offering.


## Alpha 0.4.5 speed hotfix
- Progress callbacks are batched instead of updating SQLite/notifications on every socket read.
- Persistent UI/notification writes are throttled to 2 per second while downloading.
- Progress is monotonic across parallel worker callbacks.
- UI now distinguishes total chunks from actual parallel connections.
- Wi-Fi Turbo uses up to 12 live workers; combined Wi-Fi + Mobile uses up to 16.


## Alpha 0.4.5 — Auto Turbo
- Starts Turbo at 4 live HTTP range connections instead of blindly forcing the maximum.
- Measures real aggregate throughput on the current server at 4/6/8/10/12 connections (up to 16 with multi-network).
- Automatically settles on the fastest measured connection count.
- If adding connections causes a large throughput collapse, it immediately returns to the best known count.
- Excess workers can yield an in-flight range and resume it later, so lowering the live connection count takes effect quickly without losing downloaded bytes.
- Dashboard reports the actual adaptive connection count.

Note: Auto Turbo can optimize MultiFetch-side concurrency, but it cannot force a server, CDN, ISP, or Wi-Fi link to sustain a speed that the network does not provide.


## Alpha 0.4.7 — Stable Turbo
- Starts at the maximum safe worker pool (12 on one route, 16 on combined routes) instead of beginning at 4.
- Benchmarks downward only when a smaller pool can outperform the maximum on the current server.
- Uses a dedicated raw-byte transfer meter so tuning is not distorted by batched UI/database progress updates.
- Quickly returns to the best measured connection count when a lower pool is clearly slower.
- Server/CDN/ISP limits still cannot be overridden by the app.


## Alpha 0.4.7 Stable Turbo
- Fixed connection pool during live transfer: 12 on single-network Turbo, up to 16 on combined Wi-Fi + Mobile.
- Removed destructive live downshift tests that could tear down active HTTP range requests and cause large speed dips.
- Keeps resumable 96-chunk scheduling and batched progress updates from previous builds.


## Alpha 0.4.8 — Manual Turbo Profiles
- Stable fixed connection count can be selected in Settings: 8 / 12 / 16.
- Default remains 12 connections; 16 is an optional aggressive profile.
- The selected connection count is locked for the full live transfer and never auto-downshifts.
- Android HttpURLConnection keep-alive pooling is expanded for better socket reuse between chunks.
- Browser-friendly HTTP Accept header and updated downloader User-Agent.
- Existing 96 resumable chunk queue, background wake locks, browser integration and multi-network routing remain.

Use the same URL/server when comparing 8 vs 12 vs 16 profiles; server/CDN throttling can still dominate the result.


## Alpha 0.4.9 — Speed Diagnostics & ETA
- Live ETA on the active download and queue card.
- Read-only Speed Diagnostics card with server host, current speed, fixed connection count, chunks and measured Wi-Fi/Mobile share.
- Keeps Manual Turbo Profiles from Alpha 0.4.8: no mid-download auto downshift or intentional connection teardown.
- Diagnostics do not alter the active transfer.

## Alpha 0.5.0 — Smart Queue & Download Details
- Queue filters: All / Active / Done / Issues.
- Queue summary counts for active, completed and problem downloads.
- Tap any queue card to open a full download details dialog.
- Details include server, status, bytes, progress, chunks, current speed and ETA.
- Copy the exact download URL from the details dialog.
- Copy live Speed Diagnostics from the Connections screen for easier troubleshooting.
- Download engine / fixed Turbo connection behavior is intentionally unchanged from Alpha 0.4.9.


## Alpha 0.5.2 — Queue Priority & Auto Retry
- Persistent queue priority: Low / Normal / High.
- Download service always chooses higher-priority queued items first, then oldest within the same priority.
- Queued cards can cycle priority directly from the Queue screen.
- Priority is shown in download details.
- Existing user download history is preserved with a non-destructive SQLite v1 → v2 migration.
- Optional Auto retry setting retries temporary server/network failures up to 2 times while preserving partial chunks.
- Pauses and cancellations never trigger automatic retry.
- Turbo connection behavior remains fixed/manual; this release does not reintroduce adaptive connection-count changes.


## Alpha 0.5.2
- Wi-Fi-only download guard (off by default)
- Queued jobs wait for validated Wi-Fi instead of consuming mobile data
- Automatic resume when Wi-Fi returns while the foreground service is alive
- Wi-Fi-only and Combine Wi-Fi + Mobile are mutually exclusive
- Existing Stable Turbo, queue priority, auto retry, diagnostics and browser flow retained


## Alpha 0.5.3 — Smart Storage Organizer
- Optional Smart storage folders setting (ON by default).
- Completed files can be automatically organized into Downloads/MultiFetch/Video, Audio, Apps, Archives, Documents or Other.
- Turning the option off restores the single Downloads/MultiFetch output folder.
- Queue, resume, Stable Turbo, Wi-Fi Guard, priority and auto-retry behavior are unchanged.

## Alpha 0.5.4 — Batch Link Import
- Add Download now accepts one or many HTTP/HTTPS URLs in the same dialog.
- Links can be pasted one-per-line or mixed inside ordinary shared text.
- MultiFetch extracts unique links, preserves their input order and queues them together.
- Existing non-failed/non-cancelled URLs are skipped instead of being duplicated.
- Android Share text can hand multiple links to MultiFetch at once.
- The download service is started once for the whole batch, then existing queue priority rules decide execution order.
- Stable Turbo, Wi-Fi Guard, Smart Storage, priority and auto-retry behavior are unchanged.

## Alpha 0.5.5 — Duplicate-Safe Saving

- Added a **Duplicate-safe filenames** setting (ON by default).
- Before publishing a completed file, MultiFetch checks the exact target smart-storage folder for an existing display name.
- Name conflicts are resolved safely as `file (1).ext`, `file (2).ext`, and so on.
- The final saved name is written back to download history and used by the completion notification.
- Existing files are never intentionally overwritten by the duplicate-safe mode.
- Turbo profiles, batch import, Wi-Fi Guard, queue priority, retry logic, and smart folders are unchanged.


## Alpha 0.5.6 — Notification Actions

- Active foreground download notification keeps working **Pause** and **Cancel** actions.
- Completed-download notification now opens the downloaded file directly when tapped.
- Completed notifications include explicit **Open** and **Share** actions.
- Failed-download notifications include a direct **Retry** action that requeues the exact failed task.
- PendingIntent request codes are task-specific so actions from older notifications cannot accidentally target a newer download.
- Stable Turbo, Wi-Fi Guard, queue priority, Smart Storage, Batch Import and Duplicate-Safe Saving are unchanged.

## Alpha 0.5.7 — Professional Browser UI

- Browser-only release: downloader engine, Turbo profiles, queue, Wi-Fi Guard, storage, retry and notification behavior are intentionally unchanged.
- Professional browser header with live page title, host and HTTPS security state.
- Real WebView loading progress bar.
- Redesigned address/search bar and compact bottom navigation controls.
- Back, Forward, Home, Stop/Reload and Browser Menu controls.
- Browser menu adds: Download current URL, Find on page, Desktop/Mobile site toggle, Copy link, Share page and Open in another browser.
- Desktop-site preference and last visited URL persist between app launches.
- Existing direct-download interception and WebView DownloadListener capture remain active.


## Alpha 0.5.8 — Tabs, Bookmarks & History
- Real multi-tab browser (up to 12 tabs)
- Each tab keeps its own WebView navigation stack
- Persistent bookmarks with add/remove/open
- Persistent recent browsing history with clear action
- Tab switcher, new tab, and close tab controls
- Open tab URLs and selected tab restore after leaving/returning to Browser
- Downloader/Turbo/queue/storage/network engine intentionally unchanged

## Alpha 0.5.9 — Private Tabs & Privacy Center
- Browser-only release; downloader/Turbo/queue/network/storage/notification code remains unchanged.
- Added private tabs that are excluded from MultiFetch browsing history, last-page persistence and restored tab sessions.
- Private tabs use WebView no-cache mode and clear their navigation/form state when closed.
- Tab switcher clearly labels private tabs and can create a private tab directly.
- Browser menu now includes **New private tab** and **Clear browsing data**.
- Clear browsing data removes browser history, cookies, site storage, form data and WebView cache while keeping bookmarks and downloaded files.
- Existing tabs, bookmarks, history, desktop mode, find-on-page and download capture remain available.

## Alpha 0.6.0 — Browser Compatibility Pack

Browser-only upgrade. Download engine/network/queue/storage behavior is unchanged from Alpha 0.5.9.

- Website file-upload chooser support through Android's document picker.
- HTML links/popups that request a new window are handed off into a real MultiFetch tab.
- Popup tabs inherit normal/private mode from the source tab.
- HTML5 custom/full-screen media view support with Android Back to exit full screen.
- Multi-window JavaScript support enabled for compatible sites.
- Existing tabs, private tabs, bookmarks, history, desktop mode and download capture are preserved.


## Alpha 0.6.1 — Protected Downloads & Site Permissions

- Browser-captured downloads can carry the active browser session into MultiFetch using the current Cookie, Referer and User-Agent headers.
- Login-protected/direct downloads from compatible sites can therefore continue outside the WebView instead of immediately losing the authenticated session.
- Session headers are kept only while a task is queued/active/paused; they are cleared when a task completes, is cancelled, or reaches final failure.
- Added browser permission prompts for camera and microphone, backed by Android runtime permissions.
- Added website geolocation permission flow with Android approximate/precise location controls.
- Unsupported WebView permission resources are denied instead of being silently granted.
- File upload, tabs, private tabs, fullscreen media, bookmarks/history and popup handling remain intact.
- Stable Turbo worker counts, segmentation, retry timing, network routing, storage behavior and queue scheduling are intentionally unchanged.


## Alpha 0.6.2 — HLS Media Detector
- Browser now detects common direct video/audio resources and HLS `.m3u8` manifests per tab.
- Detected media panel can send media links straight to the existing queue with the browser session cookies, referer, and user-agent.
- HLS VOD engine resolves master playlists and automatically selects the highest-bandwidth variant.
- HLS segment downloader supports fixed parallel workers, pause/resume via completed segment files, retries, Wi-Fi/mobile routing, and existing Turbo connection profiles.
- Supports MPEG-TS HLS, fMP4 `EXT-X-MAP`, `EXT-X-BYTERANGE`, and standard AES-128 encrypted HLS.
- DRM/SAMPLE-AES streams are rejected rather than bypassed. Live playlists are downloaded as the currently available snapshot.
- Existing normal direct-download range engine remains separate; normal HTTP/HTTPS downloads keep their previous behavior.


## Alpha 0.6.3 — Save Controls + Speed Limiter

- Optional custom file name before a single download is queued; the original extension is preserved when the custom name omits one.
- Android system folder picker for a per-download or batch custom destination with persisted write permission.
- Default Downloads/MultiFetch smart folders remain unchanged when no custom folder is selected.
- Duplicate-safe naming also applies inside user-selected folders.
- Aggregate speed limiter profiles: Unlimited, 512 KiB/s, 1 MiB/s, 2 MiB/s and 5 MiB/s.
- The limiter is shared across all segment/HLS workers so parallel Turbo connections do not multiply the configured cap.
- Existing Turbo, queue, Wi-Fi guard, retry, media detector and browser behavior remain otherwise unchanged.


## Alpha 0.6.4 — Simultaneous Downloads + Scheduler

- Real multi-file concurrency: choose 1, 2, or 3 separate active downloads from Settings (default 2).
- Each active file keeps its existing Turbo 8/12/16 worker profile; reducing the simultaneous-file setting never tears down healthy active transfers.
- Foreground service now uses a coordinator plus independent per-task pause/cancel/speed state, so one file can be paused or cancelled without affecting the others.
- Per-download progress notifications remain independently actionable while a foreground summary notification reports the total number of active files.
- Dashboard total speed and network-share telemetry aggregate all currently active downloads instead of showing only the first task.
- Add Download now includes an Android date/time scheduler for a single link or a whole batch.
- Scheduled jobs remain queued until their due time, then AlarmManager wakes MultiFetch and starts them when a download slot is available.
- Queue cards and Download Details show the scheduled date/time.
- Scheduler uses Android's battery-friendly `setAndAllowWhileIdle`, so the OS can delay execution slightly; no special exact-alarm permission is required.
- Priority still decides which due queued item gets the next available slot.
- Existing Turbo segment engine, HLS engine, protected-session headers, Wi-Fi Guard, Smart Storage, duplicate-safe naming, and auto-retry behavior are preserved.
- The existing speed limit is now described accurately as a per-active-file cap when multiple files run simultaneously.

## Alpha 0.7.0 — Real Torrent + Magnet Engine
- Real magnet URI downloads using libtorrent4j / libtorrent native Android builds.
- Real `.torrent` file picker and Android Open/Share handling.
- DHT/tracker/peer discovery is handled by libtorrent.
- Live torrent progress, peer/seed count and download speed are surfaced through the existing queue/notification system.
- Pause keeps the private payload workspace; resume/restart re-checks existing pieces. Cancel removes the active private payload workspace.
- Existing MultiFetch speed-limit setting is applied to the torrent handle.
- Completed single-file and multi-file payloads are copied into `Downloads/MultiFetch/Torrents/<torrent name>/` using duplicate-safe names.
- Completion stops the torrent instead of continuing to seed.
- Existing HTTP/HLS/Turbo/Wi-Fi Guard/browser engines remain separate and unchanged.
- Native Android ABIs included: armeabi-v7a, arm64-v8a, x86 and x86_64.


## Alpha 0.8.0 — Browser Shield + Search Engine
- Added a conservative in-WebView Browser Shield that blocks requests to known third-party advertising hosts.
- Added tracker protection for common analytics/tracking hosts while leaving main-frame and first-party requests untouched.
- Per-tab live counters show how many ad/tracker requests were blocked on the current page.
- Per-site shield exceptions can disable filtering for sites that do not behave correctly with blocking enabled.
- Ad blocking and tracker protection can be toggled independently from the Browser Shield panel.
- Added persistent address-bar search engine selection: Google, DuckDuckGo, Bing, or Brave Search.
- Existing private tabs, media detection, protected-download cookies, file upload, site permissions, tabs/bookmarks/history, desktop mode, HLS, HTTP/Turbo, scheduler, and torrent engines remain intact.
- The shield is intentionally request-based and conservative; same-origin/player-integrated ads are not claimed to be universally removable.

## Alpha 0.8.1 — Browser Link Actions & Page Controls

Browser-only compatibility and navigation polish. The HTTP/Turbo downloader, HLS engine, scheduler, queue, network routing and torrent engine are unchanged.

- Long-press web links/images for Open in tab, Open in private tab, Copy, Share and Download.
- Safe external-app handling for `intent://`, `tel:`, `mailto:`, SMS, maps, market links and other browsable schemes.
- `intent://` browser fallback URLs are opened inside MultiFetch when the target app is not installed.
- Persistent browser text-size controls: 80%, 100%, 120% and 140%.
- Pinch zoom remains enabled.

## Alpha 0.8.2 — Restart Recovery + Reliability

- Added durable reboot/app-update recovery for the download queue.
- Any row left in `DOWNLOADING` after a process/device restart is safely returned to `QUEUED` without deleting its partial workspace.
- Future scheduled downloads are re-armed after `BOOT_COMPLETED` and `MY_PACKAGE_REPLACED` because Android alarms do not survive a reboot.
- Optional **Resume queue after restart** setting is ON by default. Due queued work is handed back to the existing foreground download service through a separate recovery alarm.
- Recovery intentionally avoids doing network I/O inside the boot receiver. Android/OEM battery policies can delay the recovery alarm; opening MultiFetch still performs the normal queue recovery path.
- Settings footer now reads `BuildConfig.VERSION_NAME`, removing stale hard-coded release text.
- Browser Shield, browser link actions, HTTP/HLS engines, Torrent/Magnet engine, Turbo, scheduler, speed limiter and network routing are otherwise unchanged.

## MultiFetch v1.0.0 Final — Feature Freeze

This build closes the planned MultiFetch feature backlog. Browser feature expansion is frozen; browser work in this final pass is limited to Browser Shield/ad-blocking reliability.

- Persistent app-wide **Light / Dark** appearance across the dashboard, queue, connections, settings, cards, navigation and system bars.
- Requested celestial theme transition: **Light mode drops an animated sun from the top**, then the light palette takes over; **Dark mode drops an animated moon from the top**, then the dark palette takes over. The theme switches at the animation midpoint rather than flashing instantly.
- Final Browser Shield pass: expanded conservative third-party ad/tracker host coverage, unmistakable third-party ad/tracker URL-path blocking, cosmetic removal of common ad containers, per-site allowlisting and separate ad/tracker toggles. Main-frame/first-party requests remain protected from blanket blocking.
- Optional **Expected SHA-256** for a single HTTP/HLS download. The hash is verified **before publishing** the file; a mismatch keeps the bad file out of Downloads and follows normal retry/failure handling. Common `SHA256:` / `SHA-256:` prefixes are accepted.
- Torrent payloads continue to use libtorrent piece-hash verification. Multi-file torrents are not given a fake single-file checksum.
- Known-size HTTP and Torrent downloads use a free-storage preflight with safety reserve so MultiFetch can fail early instead of filling the private workspace mid-transfer.
- Queue includes **Retry all issues** for failed/cancelled downloads.
- Existing direct HTTP/HTTPS, segmented Turbo 8/12/16, simultaneous downloads, scheduler, speed limiter, protected browser-session downloads, HLS/M3U8, custom folder/rename, Smart Storage, duplicate-safe naming, Wi-Fi-only guard, Wi-Fi+mobile routing, restart recovery, queue priorities, Torrent/Magnet, notifications and completed-file actions are retained.
- Browser tabs/private tabs/bookmarks/history/media detection/navigation tools are retained but are now feature-frozen.

### Ad-blocking scope
Browser Shield is deliberately conservative to avoid breaking websites. It can block many known ad/tracker requests and hide common ad containers, but MultiFetch does **not** claim universal removal of same-origin or player-integrated ads (including every YouTube ad).

### Release rule
After v1.0.0 Final, new development should only start from an explicit new feature request instead of reopening the old backlog.
