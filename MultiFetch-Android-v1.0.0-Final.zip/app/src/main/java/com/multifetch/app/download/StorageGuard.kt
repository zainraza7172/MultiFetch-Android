package com.multifetch.app.download

import java.io.File
import kotlin.math.max
import kotlin.math.min

object StorageGuard {
    private const val MIN_RESERVE = 64L * 1024L * 1024L
    private const val MAX_RESERVE = 512L * 1024L * 1024L

    fun ensureWorkspaceCapacity(workDir: File, totalBytes: Long, alreadyDownloaded: Long = 0L) {
        if (totalBytes <= 0L) return
        val remaining = (totalBytes - alreadyDownloaded.coerceAtLeast(0L)).coerceAtLeast(0L)
        if (remaining <= 0L) return
        val reserve = min(MAX_RESERVE, max(MIN_RESERVE, totalBytes / 20L))
        val required = remaining + reserve
        val available = workDir.usableSpace.coerceAtLeast(0L)
        require(available >= required) {
            "Not enough free storage for this download. Need about ${formatBytes(required)}, available ${formatBytes(available)}."
        }
    }

    private fun formatBytes(bytes: Long): String = when {
        bytes >= 1024L * 1024L * 1024L -> String.format("%.1f GB", bytes / 1024.0 / 1024.0 / 1024.0)
        bytes >= 1024L * 1024L -> String.format("%.0f MB", bytes / 1024.0 / 1024.0)
        else -> String.format("%.0f KB", bytes / 1024.0)
    }
}
