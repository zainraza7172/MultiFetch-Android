package com.multifetch.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

object DownloadScheduleManager {
    private const val SCHEDULE_REQUEST_CODE = 6400
    private const val RECOVERY_REQUEST_CODE = 6401
    private const val ACTION_SCHEDULE_WAKE = "com.multifetch.app.action.SCHEDULE_WAKE"
    private const val ACTION_RESTART_RECOVERY = "com.multifetch.app.action.RESTART_RECOVERY"

    fun scheduleNext(context: Context, triggerAtMillis: Long?) {
        val appContext = context.applicationContext
        val alarmManager = appContext.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pendingIntent = alarmPendingIntent(appContext, SCHEDULE_REQUEST_CODE, ACTION_SCHEDULE_WAKE)

        if (triggerAtMillis == null) {
            alarmManager.cancel(pendingIntent)
            return
        }

        val safeTrigger = triggerAtMillis.coerceAtLeast(System.currentTimeMillis() + 1_000L)
        // Intentionally uses setAndAllowWhileIdle instead of exact-alarm privileges.
        // Android may defer execution slightly to protect battery, but no special
        // user-granted exact-alarm access is required.
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTrigger, pendingIntent)
    }

    /**
     * Re-enters the normal foreground download service shortly after a reboot/app update.
     * A separate PendingIntent keeps this wake-up independent from user schedules.
     */
    fun scheduleRecovery(context: Context, triggerAtMillis: Long = System.currentTimeMillis() + 30_000L) {
        val appContext = context.applicationContext
        val alarmManager = appContext.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pendingIntent = alarmPendingIntent(appContext, RECOVERY_REQUEST_CODE, ACTION_RESTART_RECOVERY)
        val safeTrigger = triggerAtMillis.coerceAtLeast(System.currentTimeMillis() + 1_000L)
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTrigger, pendingIntent)
    }

    fun cancelRecovery(context: Context) {
        val appContext = context.applicationContext
        val alarmManager = appContext.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(alarmPendingIntent(appContext, RECOVERY_REQUEST_CODE, ACTION_RESTART_RECOVERY))
    }

    private fun alarmPendingIntent(context: Context, requestCode: Int, action: String): PendingIntent =
        PendingIntent.getBroadcast(
            context,
            requestCode,
            Intent(context, DownloadScheduleReceiver::class.java).apply { this.action = action },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
}

class DownloadScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val serviceIntent = Intent(context, DownloadService::class.java).apply {
            action = DownloadService.ACTION_RECOVER
        }
        runCatching { ContextCompat.startForegroundService(context, serviceIntent) }
    }
}
