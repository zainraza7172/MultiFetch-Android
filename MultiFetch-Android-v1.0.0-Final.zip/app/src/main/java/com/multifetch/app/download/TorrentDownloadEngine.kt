package com.multifetch.app.download

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import org.libtorrent4j.AlertListener
import org.libtorrent4j.SessionManager
import org.libtorrent4j.TorrentHandle
import org.libtorrent4j.TorrentInfo
import org.libtorrent4j.TorrentStatus
import org.libtorrent4j.alerts.AddTorrentAlert
import org.libtorrent4j.alerts.Alert
import org.libtorrent4j.alerts.MetadataReceivedAlert
import org.libtorrent4j.swig.torrent_flags_t
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Real BitTorrent/magnet transport backed by libtorrent4j.
 *
 * Each active MultiFetch torrent owns an isolated libtorrent session and private workspace.
 * The private workspace makes pause/restart safe. On completion the verified payload is copied
 * into MediaStore Downloads and the private payload is removed.
 */
class TorrentDownloadEngine(private val context: Context) {

    fun download(
        taskId: String,
        source: String,
        speedLimitBytesPerSecond: Long,
        duplicateSafeFileNames: Boolean,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean,
        onProbe: (DownloadEngine.ProbeInfo) -> Unit,
        onProgress: (DownloadEngine.Progress) -> Unit
    ): DownloadEngine.Result {
        require(isTorrentSource(source)) { "Unsupported torrent source" }

        val workDir = File(context.filesDir, "multifetch-torrent/$taskId").apply { mkdirs() }
        val dataDir = File(workDir, "data").apply { mkdirs() }
        val handleRef = AtomicReference<TorrentHandle?>(null)
        val infoRef = AtomicReference<TorrentInfo?>(null)
        val manager = SessionManager()
        var probePublished = false
        var storageChecked = false

        val listener = object : AlertListener {
            override fun types(): IntArray? = null

            override fun alert(alert: Alert<*>) {
                when (alert) {
                    is AddTorrentAlert -> {
                        val handle = alert.handle()
                        handleRef.compareAndSet(null, handle)
                        runCatching { handle.resume() }
                    }
                    is MetadataReceivedAlert -> {
                        val handle = alert.handle()
                        handleRef.compareAndSet(null, handle)
                        runCatching { handle.torrentFile() }.getOrNull()?.let(infoRef::set)
                    }
                }
            }
        }

        manager.addListener(listener)
        try {
            onProgress(DownloadEngine.Progress(0L, -1L, "Starting BitTorrent engine"))
            manager.start()

            if (source.startsWith(MAGNET_PREFIX, ignoreCase = true)) {
                manager.download(source, dataDir, torrent_flags_t())
            } else {
                val metainfo = sourceFile(source)
                if (!metainfo.isFile || metainfo.length() <= 0L) {
                    throw IllegalArgumentException("Torrent file is missing")
                }
                val info = TorrentInfo(metainfo)
                infoRef.set(info)
                manager.download(info, dataDir)
            }

            val handle = waitForHandle(handleRef, pauseRequested, cancelled)
            if (speedLimitBytesPerSecond > 0L) {
                runCatching {
                    handle.setDownloadLimit(speedLimitBytesPerSecond.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
                }
            }
            runCatching { handle.resume() }

            var lastProgressAt = 0L
            while (true) {
                checkControl(handle, workDir, pauseRequested, cancelled)

                val info = infoRef.get() ?: runCatching { handle.torrentFile() }.getOrNull()?.also(infoRef::set)
                if (info != null && !storageChecked) {
                    val existing = dataDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
                    StorageGuard.ensureWorkspaceCapacity(dataDir, info.totalSize(), existing)
                    storageChecked = true
                }
                if (info != null && !probePublished) {
                    val firstName = runCatching {
                        if (info.files().numFiles() > 0) info.files().fileName(0) else info.name()
                    }.getOrDefault(info.name())
                    onProbe(
                        DownloadEngine.ProbeInfo(
                            totalBytes = info.totalSize(),
                            supportsRanges = false,
                            fileName = sanitizeName(info.name()).ifBlank { "torrent" },
                            mimeType = mimeForName(firstName),
                            segmentCount = 1,
                            networkLabel = "BitTorrent"
                        )
                    )
                    probePublished = true
                }

                val status = handle.status()
                val total = when {
                    status.totalWanted() > 0L -> status.totalWanted()
                    info != null -> info.totalSize()
                    else -> -1L
                }
                val done = when {
                    status.totalWantedDone() > 0L -> status.totalWantedDone()
                    status.totalDone() > 0L -> status.totalDone()
                    else -> 0L
                }.coerceAtLeast(0L)

                val now = System.currentTimeMillis()
                if (now - lastProgressAt >= 500L) {
                    val state = stateLabel(status.state())
                    val peers = status.numPeers().coerceAtLeast(0)
                    val seeds = status.numSeeds().coerceAtLeast(0)
                    val rate = status.downloadRate().coerceAtLeast(0)
                    val message = buildString {
                        append(state)
                        append(" • ").append(peers).append(" peers")
                        if (seeds > 0) append(" • ").append(seeds).append(" seeds")
                        if (rate > 0) append(" • ").append(formatSpeed(rate.toLong()))
                    }
                    onProgress(DownloadEngine.Progress(done, total, message))
                    lastProgressAt = now
                }

                val state = status.state()
                val finished = state == TorrentStatus.State.FINISHED || state == TorrentStatus.State.SEEDING ||
                    (total > 0L && done >= total && state != TorrentStatus.State.CHECKING_FILES &&
                        state != TorrentStatus.State.CHECKING_RESUME_DATA &&
                        state != TorrentStatus.State.DOWNLOADING_METADATA)
                if (finished) {
                    runCatching { handle.pause() }
                    val finalInfo = info ?: runCatching { handle.torrentFile() }.getOrNull()
                        ?: throw IllegalStateException("Torrent metadata unavailable after completion")
                    val published = publishPayload(
                        dataDir = dataDir,
                        torrentName = finalInfo.name(),
                        duplicateSafe = duplicateSafeFileNames
                    )
                    val totalPublished = published.totalBytes.coerceAtLeast(finalInfo.totalSize())
                    workDir.deleteRecursively()
                    cleanupOwnedMetainfo(source)
                    return DownloadEngine.Result(
                        uri = published.firstUri,
                        fileName = if (published.fileCount > 1) {
                            "${sanitizeName(finalInfo.name())} (${published.fileCount} files)"
                        } else {
                            published.firstName
                        },
                        totalBytes = totalPublished,
                        usedSegments = 1
                    )
                }

                Thread.sleep(450L)
            }
        } finally {
            runCatching { manager.removeListener(listener) }
            runCatching { handleRef.get()?.pause() }
            runCatching { manager.stop() }
        }
    }

    fun deleteWorkspace(taskId: String) {
        File(context.filesDir, "multifetch-torrent/$taskId").deleteRecursively()
    }

    private fun waitForHandle(
        ref: AtomicReference<TorrentHandle?>,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean
    ): TorrentHandle {
        val started = System.currentTimeMillis()
        while (true) {
            if (cancelled.get()) throw DownloadEngine.DownloadCancelledException()
            if (pauseRequested.get()) throw DownloadEngine.DownloadPausedException()
            ref.get()?.let { return it }
            if (System.currentTimeMillis() - started > HANDLE_TIMEOUT_MS) {
                throw IllegalStateException("BitTorrent session did not start")
            }
            Thread.sleep(150L)
        }
    }

    private fun checkControl(
        handle: TorrentHandle,
        workDir: File,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean
    ) {
        if (cancelled.get()) {
            runCatching { handle.pause() }
            workDir.deleteRecursively()
            throw DownloadEngine.DownloadCancelledException()
        }
        if (pauseRequested.get()) {
            runCatching { handle.pause() }
            throw DownloadEngine.DownloadPausedException()
        }
    }

    private data class PublishedPayload(
        val firstUri: Uri,
        val firstName: String,
        val fileCount: Int,
        val totalBytes: Long
    )

    private fun publishPayload(dataDir: File, torrentName: String, duplicateSafe: Boolean): PublishedPayload {
        val files = dataDir.walkTopDown().filter { it.isFile }.toList()
        if (files.isEmpty()) throw IllegalStateException("Torrent completed but no payload files were found")

        val safeTorrent = sanitizeName(torrentName).ifBlank { "Torrent" }
        val rootCanonical = dataDir.canonicalFile
        var firstUri: Uri? = null
        var firstName = ""
        var totalBytes = 0L

        files.forEach { source ->
            val relativeRaw = source.canonicalFile.relativeTo(rootCanonical).invariantSeparatorsPath
            val normalized = dropDuplicateTorrentRoot(relativeRaw, safeTorrent)
            val relativeFile = File(normalized)
            val parent = relativeFile.parent?.takeIf { it != "." && it.isNotBlank() }
            val targetPath = buildString {
                append(Environment.DIRECTORY_DOWNLOADS).append("/MultiFetch/Torrents/").append(safeTorrent).append('/')
                if (parent != null) append(parent.trim('/')).append('/')
            }
            val requestedName = sanitizeName(relativeFile.name).ifBlank { "torrent-file" }
            val displayName = if (duplicateSafe) uniqueDisplayName(requestedName, targetPath) else requestedName
            val mime = mimeForName(displayName)
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, displayName)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, targetPath)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Unable to create torrent output file")
            try {
                context.contentResolver.openOutputStream(uri, "w")?.use { rawOut ->
                    BufferedOutputStream(rawOut, COPY_BUFFER).use { out ->
                        BufferedInputStream(FileInputStream(source), COPY_BUFFER).use { input ->
                            input.copyTo(out, COPY_BUFFER)
                        }
                    }
                } ?: throw IllegalStateException("Unable to open torrent output file")
                context.contentResolver.update(
                    uri,
                    ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) },
                    null,
                    null
                )
            } catch (t: Throwable) {
                runCatching { context.contentResolver.delete(uri, null, null) }
                throw t
            }
            totalBytes += source.length()
            if (firstUri == null) {
                firstUri = uri
                firstName = displayName
            }
        }

        return PublishedPayload(
            firstUri = requireNotNull(firstUri),
            firstName = firstName,
            fileCount = files.size,
            totalBytes = totalBytes
        )
    }

    private fun uniqueDisplayName(originalName: String, relativePath: String): String {
        if (!mediaStoreNameExists(originalName, relativePath)) return originalName
        val dot = originalName.lastIndexOf('.')
        val base = if (dot > 0) originalName.substring(0, dot) else originalName
        val ext = if (dot > 0) originalName.substring(dot) else ""
        for (index in 1..9999) {
            val candidate = "$base ($index)$ext"
            if (!mediaStoreNameExists(candidate, relativePath)) return candidate
        }
        return "$base-${System.currentTimeMillis()}$ext"
    }

    private fun mediaStoreNameExists(name: String, relativePath: String): Boolean {
        return context.contentResolver.query(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Downloads._ID),
            "${MediaStore.Downloads.DISPLAY_NAME} = ? AND ${MediaStore.Downloads.RELATIVE_PATH} = ?",
            arrayOf(name, relativePath),
            null
        )?.use { it.moveToFirst() } == true
    }

    private fun cleanupOwnedMetainfo(source: String) {
        if (!source.startsWith(TORRENT_FILE_PREFIX, ignoreCase = true)) return
        val file = runCatching { sourceFile(source) }.getOrNull() ?: return
        val ownedRoot = File(context.filesDir, METAINFO_DIR).canonicalFile
        val target = runCatching { file.canonicalFile }.getOrNull() ?: return
        if (target.path.startsWith(ownedRoot.path + File.separator)) runCatching { target.delete() }
    }

    private fun dropDuplicateTorrentRoot(relative: String, safeTorrent: String): String {
        val clean = relative.trimStart('/')
        val slash = clean.indexOf('/')
        if (slash <= 0) return clean
        val first = sanitizeName(clean.substring(0, slash))
        return if (first.equals(safeTorrent, ignoreCase = true)) clean.substring(slash + 1) else clean
    }

    private fun sanitizeName(value: String): String = value
        .replace(Regex("[\\/:*?\"<>|]"), "_")
        .trim()
        .trimEnd('.')
        .take(180)

    private fun mimeForName(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.US)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun stateLabel(state: TorrentStatus.State): String = when (state) {
        TorrentStatus.State.CHECKING_FILES -> "Checking torrent"
        TorrentStatus.State.DOWNLOADING_METADATA -> "Fetching metadata"
        TorrentStatus.State.DOWNLOADING -> "Torrent downloading"
        TorrentStatus.State.FINISHED -> "Torrent complete"
        TorrentStatus.State.SEEDING -> "Torrent complete"
        TorrentStatus.State.CHECKING_RESUME_DATA -> "Checking resume data"
        else -> "BitTorrent"
    }

    private fun formatSpeed(bytesPerSecond: Long): String = when {
        bytesPerSecond >= 1024L * 1024L -> String.format(Locale.US, "%.1f MB/s", bytesPerSecond / 1024.0 / 1024.0)
        bytesPerSecond >= 1024L -> String.format(Locale.US, "%.0f KB/s", bytesPerSecond / 1024.0)
        else -> "$bytesPerSecond B/s"
    }

    companion object {
        const val MAGNET_PREFIX = "magnet:"
        const val TORRENT_FILE_PREFIX = "torrent-file:"
        const val METAINFO_DIR = "torrent_metainfo"
        private const val HANDLE_TIMEOUT_MS = 30_000L
        private const val COPY_BUFFER = 512 * 1024

        fun isTorrentSource(value: String): Boolean =
            value.startsWith(MAGNET_PREFIX, ignoreCase = true) ||
                value.startsWith(TORRENT_FILE_PREFIX, ignoreCase = true)

        fun makeFileSource(path: String): String = TORRENT_FILE_PREFIX + Uri.encode(path)

        fun sourceFile(source: String): File {
            require(source.startsWith(TORRENT_FILE_PREFIX, ignoreCase = true)) { "Not a torrent file source" }
            return File(Uri.decode(source.substring(TORRENT_FILE_PREFIX.length)))
        }
    }
}
