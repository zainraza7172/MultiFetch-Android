package com.multifetch.app.download

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.provider.DocumentsContract
import com.multifetch.app.BuildConfig
import com.multifetch.app.network.NetworkRouter
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicInteger

class DownloadEngine(private val context: Context) {

    data class Progress(
        val downloadedBytes: Long,
        val totalBytes: Long,
        val message: String
    )

    data class ProbeInfo(
        val totalBytes: Long,
        val supportsRanges: Boolean,
        val fileName: String,
        val mimeType: String,
        val segmentCount: Int,
        val networkLabel: String
    )

    data class Result(
        val uri: Uri,
        val fileName: String,
        val totalBytes: Long,
        val usedSegments: Int,
        val sha256: String? = null
    )

    class DownloadPausedException : RuntimeException("Download paused")
    class DownloadCancelledException : RuntimeException("Download cancelled")
    private class WorkerYieldException : RuntimeException("Worker yielded to adaptive tuner")

    fun download(
        taskId: String,
        rawUrl: String,
        existingSegmentCount: Int,
        turboMode: Boolean,
        combineWifiAndCellular: Boolean,
        turboConnections: Int,
        autoOrganizeDownloads: Boolean,
        duplicateSafeFileNames: Boolean,
        requestedFileName: String?,
        outputTreeUri: String?,
        speedLimitBytesPerSecond: Long,
        requestCookie: String?,
        requestReferer: String?,
        requestUserAgent: String?,
        expectedSha256: String?,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean,
        onProbe: (ProbeInfo) -> Unit,
        onProgress: (Progress) -> Unit
    ): Result {
        if (HlsDownloadEngine.looksLikeHlsUrl(rawUrl)) {
            return HlsDownloadEngine(context).download(
                taskId = taskId,
                rawUrl = rawUrl,
                turboMode = turboMode,
                combineWifiAndCellular = combineWifiAndCellular,
                turboConnections = turboConnections,
                autoOrganizeDownloads = autoOrganizeDownloads,
                duplicateSafeFileNames = duplicateSafeFileNames,
                requestedFileName = requestedFileName,
                outputTreeUri = outputTreeUri,
                speedLimitBytesPerSecond = speedLimitBytesPerSecond,
                requestCookie = requestCookie,
                requestReferer = requestReferer,
                requestUserAgent = requestUserAgent,
                expectedSha256 = expectedSha256,
                pauseRequested = pauseRequested,
                cancelled = cancelled,
                onProbe = onProbe,
                onProgress = onProgress
            )
        }

        val url = validateUrl(rawUrl)
        val requestHeaders = RequestHeaders(
            cookie = requestCookie?.takeIf { it.isNotBlank() },
            referer = requestReferer?.takeIf { it.isNotBlank() },
            userAgent = requestUserAgent?.takeIf { it.isNotBlank() }
        )
        val limiter = BandwidthLimiter(speedLimitBytesPerSecond)
        val router = NetworkRouter(context)
        val session = router.acquire(combineWifiAndCellular)
        val downloadMessage = activeMessage(session.label, turboMode)

        try {
            onProgress(Progress(0, -1, "Checking server • ${session.label}"))
            val probe = probe(url, session.routes, requestHeaders)
            val segments = chooseSegmentCount(
                totalBytes = probe.totalBytes,
                supportsRanges = probe.supportsRanges,
                turboMode = turboMode,
                existingSegmentCount = existingSegmentCount
            )
            val finalRequestedName = resolveRequestedFileName(requestedFileName, probe.fileName)
            val info = ProbeInfo(
                totalBytes = probe.totalBytes,
                supportsRanges = probe.supportsRanges,
                fileName = finalRequestedName,
                mimeType = probe.mimeType,
                segmentCount = segments,
                networkLabel = session.label
            )
            onProbe(info)

            val workDir = File(context.filesDir, "multifetch/$taskId").apply { mkdirs() }
            val downloaded = AtomicLong(existingBytes(workDir, probe.totalBytes, segments))
            StorageGuard.ensureWorkspaceCapacity(workDir, probe.totalBytes, downloaded.get())
            val wifiSessionBytes = AtomicLong(0L)
            val mobileSessionBytes = AtomicLong(0L)
            val initialMessage = if (downloaded.get() > 0) {
                "Resuming • ${session.label}${if (turboMode) " • Turbo" else ""}"
            } else {
                downloadMessage
            }
            onProgress(Progress(downloaded.get(), probe.totalBytes, initialMessage))

            try {
                if (segments > 1) {
                    downloadSegmented(
                        url = url,
                        totalBytes = probe.totalBytes,
                        segmentCount = segments,
                        turboMode = turboMode,
                        turboConnections = turboConnections,
                        routes = session.routes,
                        requestHeaders = requestHeaders,
                        workDir = workDir,
                        pauseRequested = pauseRequested,
                        cancelled = cancelled,
                        downloaded = downloaded,
                        wifiSessionBytes = wifiSessionBytes,
                        mobileSessionBytes = mobileSessionBytes,
                        progressMessage = downloadMessage,
                        limiter = limiter,
                        onProgress = onProgress
                    )
                } else {
                    downloadSingle(
                        url = url,
                        routes = session.routes,
                        requestHeaders = requestHeaders,
                        supportsRanges = probe.supportsRanges,
                        output = File(workDir, "part_0.tmp"),
                        pauseRequested = pauseRequested,
                        cancelled = cancelled,
                        downloaded = downloaded,
                        wifiSessionBytes = wifiSessionBytes,
                        mobileSessionBytes = mobileSessionBytes,
                        totalBytes = probe.totalBytes,
                        progressMessage = downloadMessage,
                        limiter = limiter,
                        onProgress = onProgress
                    )
                }

                ensureRunning(pauseRequested, cancelled)
                val finalTotal = if (probe.totalBytes > 0) probe.totalBytes else {
                    (0 until segments).sumOf { index -> File(workDir, "part_$index.tmp").length() }
                }
                val expectedHash = FileIntegrity.normalizeSha256(expectedSha256)
                val actualHash = if (expectedHash != null) {
                    onProgress(Progress(finalTotal, finalTotal, "Verifying SHA-256…"))
                    val hash = FileIntegrity.sha256((0 until segments).map { index -> File(workDir, "part_$index.tmp") })
                    try {
                        FileIntegrity.requireMatch(expectedHash, hash)
                    } catch (t: Throwable) {
                        workDir.deleteRecursively()
                        throw t
                    }
                    hash
                } else null
                onProgress(Progress(finalTotal, finalTotal, "Saving to Downloads…"))
                val published = publishToDownloads(
                    workDir = workDir,
                    partCount = segments,
                    fileName = finalRequestedName,
                    mimeType = probe.mimeType,
                    autoOrganizeDownloads = autoOrganizeDownloads,
                    duplicateSafeFileNames = duplicateSafeFileNames,
                    outputTreeUri = outputTreeUri,
                    cancelled = cancelled
                )
                workDir.deleteRecursively()
                onProgress(Progress(finalTotal, finalTotal, "Complete"))
                return Result(published.first, published.second, finalTotal, segments, actualHash)
            } catch (t: Throwable) {
                if (t is DownloadCancelledException) workDir.deleteRecursively()
                throw t
            }
        } finally {
            session.close()
        }
    }

    fun deleteWorkspace(taskId: String) {
        File(context.filesDir, "multifetch/$taskId").deleteRecursively()
    }

    private data class RequestHeaders(
        val cookie: String?,
        val referer: String?,
        val userAgent: String?
    )

    private data class Probe(
        val totalBytes: Long,
        val supportsRanges: Boolean,
        val fileName: String,
        val mimeType: String
    )

    private fun validateUrl(raw: String): URL {
        val trimmed = raw.trim()
        require(trimmed.startsWith("https://") || trimmed.startsWith("http://")) {
            "Only http:// and https:// links are supported."
        }
        return URL(trimmed)
    }

    private fun probe(
        url: URL,
        routes: List<NetworkRouter.Route>,
        requestHeaders: RequestHeaders
    ): Probe {
        var lastError: Throwable? = null
        for (route in routes) {
            try {
                return probeOnRoute(url, route, requestHeaders)
            } catch (t: Throwable) {
                lastError = t
            }
        }
        throw IllegalStateException("Could not reach the download server.", lastError)
    }

    private fun probeOnRoute(
        url: URL,
        route: NetworkRouter.Route,
        requestHeaders: RequestHeaders
    ): Probe {
        val connection = open(url, route, requestHeaders).apply {
            setRequestProperty("Range", "bytes=0-0")
        }
        try {
            val code = connection.responseCode
            if (code !in 200..299) error("Server returned HTTP $code")
            val contentRange = connection.getHeaderField("Content-Range")
            val totalFromRange = parseTotalFromContentRange(contentRange)
            val supportsRanges = code == HttpURLConnection.HTTP_PARTIAL && totalFromRange > 0
            val total = when {
                totalFromRange > 0 -> totalFromRange
                connection.contentLengthLong > 0 -> connection.contentLengthLong
                else -> -1L
            }
            val fileName = extractFileName(connection, url)
            val mime = connection.contentType?.substringBefore(';')?.trim()
                ?.takeIf { it.isNotBlank() }
                ?: "application/octet-stream"

            runCatching { connection.inputStream.close() }
            return Probe(total, supportsRanges, fileName, mime)
        } finally {
            connection.disconnect()
        }
    }

    private fun chooseSegmentCount(
        totalBytes: Long,
        supportsRanges: Boolean,
        turboMode: Boolean,
        existingSegmentCount: Int
    ): Int {
        if (!supportsRanges || totalBytes <= 0) return 1
        if (existingSegmentCount > 1) return existingSegmentCount.coerceIn(2, MAX_PARTS)

        // Alpha 0.4.3: use more smaller chunks than active connections.
        // This keeps the worker pool busy instead of letting fast connections finish
        // early and leaving one slow fixed segment to drag the whole download down.
        return if (turboMode) {
            when {
                totalBytes < 8L * MIB -> 4
                totalBytes < 32L * MIB -> 8
                totalBytes < 128L * MIB -> 16
                totalBytes < 512L * MIB -> 32
                totalBytes < 2048L * MIB -> 64
                else -> 96
            }
        } else {
            when {
                totalBytes < 4L * MIB -> 1
                totalBytes < 16L * MIB -> 2
                totalBytes < 64L * MIB -> 4
                totalBytes < 256L * MIB -> 8
                else -> 16
            }
        }
    }

    private fun existingBytes(workDir: File, totalBytes: Long, segmentCount: Int): Long {
        if (totalBytes <= 0) return File(workDir, "part_0.tmp").takeIf { it.exists() }?.length() ?: 0L
        val chunk = totalBytes / segmentCount
        var sum = 0L
        for (index in 0 until segmentCount) {
            val start = index * chunk
            val end = if (index == segmentCount - 1) totalBytes - 1 else start + chunk - 1
            val expected = end - start + 1
            val file = File(workDir, "part_$index.tmp")
            if (file.exists() && file.length() > expected) file.delete()
            sum += file.takeIf { it.exists() }?.length()?.coerceAtMost(expected) ?: 0L
        }
        return sum.coerceAtMost(totalBytes)
    }

    private fun downloadSegmented(
        url: URL,
        totalBytes: Long,
        segmentCount: Int,
        turboMode: Boolean,
        turboConnections: Int,
        routes: List<NetworkRouter.Route>,
        requestHeaders: RequestHeaders,
        workDir: File,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean,
        downloaded: AtomicLong,
        wifiSessionBytes: AtomicLong,
        mobileSessionBytes: AtomicLong,
        progressMessage: String,
        limiter: BandwidthLimiter,
        onProgress: (Progress) -> Unit
    ) {
        val chunk = totalBytes / segmentCount
        val pending = java.util.concurrent.ConcurrentLinkedQueue<Int>()

        // Completed chunks are skipped, partial chunks remain resumable.
        for (index in 0 until segmentCount) {
            val start = index * chunk
            val end = if (index == segmentCount - 1) totalBytes - 1 else start + chunk - 1
            val expected = end - start + 1
            val output = File(workDir, "part_$index.tmp")
            if (!output.exists() || output.length() < expected) pending.add(index)
        }
        if (pending.isEmpty()) return
        val remainingChunks = AtomicInteger(pending.size)

        // Alpha 0.4.8 Manual Turbo Profiles:
        // Keep the selected worker pool fixed for the whole transfer. Users can choose
        // 8 / 12 / 16 before starting a new job. The count never auto-downshifts mid-range,
        // so healthy HTTP requests are not intentionally torn down.
        val workerCount = chooseWorkerCount(segmentCount, turboMode, turboConnections)
        val transferMeter = AtomicLong(0L)
        val stableLabel = when {
            turboMode && routes.size > 1 -> "$progressMessage • Stable Turbo $workerCount conn"
            turboMode -> "$progressMessage • Stable Turbo $workerCount conn"
            else -> "$progressMessage • Parallel $workerCount conn"
        }

        onProgress(Progress(downloaded.get(), totalBytes, stableLabel))

        val executor = Executors.newFixedThreadPool(workerCount)
        try {
            val tasks = (0 until workerCount).map { workerIndex ->
                Callable {
                    while (true) {
                        ensureRunning(pauseRequested, cancelled)

                        val index = pending.poll()
                        if (index == null) {
                            if (remainingChunks.get() <= 0) break
                            Thread.sleep(40)
                            continue
                        }

                        val start = index * chunk
                        val end = if (index == segmentCount - 1) totalBytes - 1 else start + chunk - 1
                        val output = File(workDir, "part_$index.tmp")
                        try {
                            downloadRangeWithRetry(
                                url = url,
                                rangeStart = start,
                                rangeEnd = end,
                                output = output,
                                routes = routes,
                                requestHeaders = requestHeaders,
                                initialRouteIndex = preferredRouteIndex(workerIndex, routes),
                                pauseRequested = pauseRequested,
                                cancelled = cancelled,
                                downloaded = downloaded,
                                wifiSessionBytes = wifiSessionBytes,
                                mobileSessionBytes = mobileSessionBytes,
                                totalBytes = totalBytes,
                                progressMessage = { stableLabel },
                                shouldYield = { false },
                                transferMeter = transferMeter,
                                limiter = limiter,
                                onProgress = onProgress
                            )
                            remainingChunks.decrementAndGet()
                        } catch (t: Throwable) {
                            // A chunk is only re-queued for transient worker-yield events.
                            // Stable Turbo itself never emits WorkerYieldException.
                            if (t is WorkerYieldException) {
                                pending.add(index)
                                Thread.sleep(40)
                            } else {
                                throw t
                            }
                        }
                    }
                }
            }
            executor.invokeAll(tasks).forEach { it.get() }
        } catch (t: Throwable) {
            val root = unwrap(t)
            when (root) {
                is DownloadPausedException -> throw root
                is DownloadCancelledException -> throw root
                else -> throw root
            }
        } finally {
            executor.shutdownNow()
        }
    }

    private fun chooseWorkerCount(partCount: Int, turboMode: Boolean, turboConnections: Int): Int {
        val target = if (turboMode) turboConnections.coerceIn(8, 16) else 6
        return target.coerceAtMost(partCount).coerceAtLeast(1)
    }

    private fun preferredRouteIndex(workerIndex: Int, routes: List<NetworkRouter.Route>): Int {
        if (routes.size <= 1) return 0
        val wifi = routes.indexOfFirst { it.label == "Wi‑Fi" }
        val mobile = routes.indexOfFirst { it.label == "Mobile" }
        if (wifi >= 0 && mobile >= 0) {
            // Wi-Fi gets three workers for each mobile worker by default.
            // Mobile still contributes, but a slower cellular link is less likely
            // to become the tail that drags the whole file down.
            return if (workerIndex % 4 == 3) mobile else wifi
        }
        return workerIndex % routes.size
    }

    private fun downloadRangeWithRetry(
        url: URL,
        rangeStart: Long,
        rangeEnd: Long,
        output: File,
        routes: List<NetworkRouter.Route>,
        requestHeaders: RequestHeaders,
        initialRouteIndex: Int,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean,
        downloaded: AtomicLong,
        wifiSessionBytes: AtomicLong,
        mobileSessionBytes: AtomicLong,
        totalBytes: Long,
        progressMessage: () -> String,
        shouldYield: () -> Boolean,
        transferMeter: AtomicLong,
        limiter: BandwidthLimiter,
        onProgress: (Progress) -> Unit
    ) {
        val expectedSize = rangeEnd - rangeStart + 1
        if (output.exists() && output.length() > expectedSize) output.delete()
        if (output.exists() && output.length() == expectedSize) return

        var lastError: Throwable? = null
        repeat(5) { attempt ->
            ensureRunning(pauseRequested, cancelled)
            val already = output.takeIf { it.exists() }?.length() ?: 0L
            if (already >= expectedSize) return
            val requestStart = rangeStart + already
            val route = routes[(initialRouteIndex + attempt) % routes.size]
            try {
                val connection = open(url, route, requestHeaders).apply {
                    setRequestProperty("Range", "bytes=$requestStart-$rangeEnd")
                }
                try {
                    if (connection.responseCode != HttpURLConnection.HTTP_PARTIAL) {
                        error("Server stopped supporting range requests (HTTP ${connection.responseCode}).")
                    }
                    BufferedInputStream(connection.inputStream, BUFFER_SIZE).use { input ->
                        BufferedOutputStream(FileOutputStream(output, true), BUFFER_SIZE).use { out ->
                            copyWithState(
                                input,
                                out,
                                pauseRequested,
                                cancelled,
                                shouldYield,
                                onRawBytes = { count -> transferMeter.addAndGet(count.toLong()) },
                                limiter = limiter
                            ) { count ->
                                val delta = count.toLong()
                                val current = downloaded.addAndGet(delta)
                                addRouteBytes(route.label, delta, wifiSessionBytes, mobileSessionBytes)
                                onProgress(
                                    Progress(
                                        current,
                                        totalBytes,
                                        withMeasuredNetworkShare(progressMessage(), wifiSessionBytes, mobileSessionBytes)
                                    )
                                )
                            }
                        }
                    }
                    if (output.length() == expectedSize) return
                    error("Segment ended early (${output.length()} / $expectedSize bytes).")
                } finally {
                    connection.disconnect()
                }
            } catch (t: Throwable) {
                when (t) {
                    is DownloadPausedException -> throw t
                    is DownloadCancelledException -> throw t
                    is WorkerYieldException -> throw t
                }
                lastError = t
                if (attempt < 4) Thread.sleep(500L * (attempt + 1))
            }
        }
        throw IllegalStateException("A download segment failed after network retries.", lastError)
    }

    private fun downloadSingle(
        url: URL,
        routes: List<NetworkRouter.Route>,
        requestHeaders: RequestHeaders,
        supportsRanges: Boolean,
        output: File,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean,
        downloaded: AtomicLong,
        wifiSessionBytes: AtomicLong,
        mobileSessionBytes: AtomicLong,
        totalBytes: Long,
        progressMessage: String,
        limiter: BandwidthLimiter,
        onProgress: (Progress) -> Unit
    ) {
        var lastError: Throwable? = null
        routes.forEachIndexed { routeIndex, route ->
            ensureRunning(pauseRequested, cancelled)
            var existing = output.takeIf { it.exists() }?.length() ?: 0L
            if (!supportsRanges && existing > 0) {
                output.delete()
                downloaded.set(0L)
                existing = 0L
            }
            if (totalBytes > 0 && existing >= totalBytes) return

            try {
                val connection = open(url, route, requestHeaders).apply {
                    if (supportsRanges && existing > 0) setRequestProperty("Range", "bytes=$existing-")
                }
                try {
                    val code = connection.responseCode
                    val appending = supportsRanges && existing > 0 && code == HttpURLConnection.HTTP_PARTIAL
                    if (existing > 0 && supportsRanges && !appending) {
                        output.delete()
                        downloaded.set(0L)
                        existing = 0L
                    }
                    if (code !in 200..299) error("Download failed with HTTP $code")
                    val resolvedTotal = if (totalBytes > 0) totalBytes else {
                        if (appending) existing + connection.contentLengthLong else connection.contentLengthLong
                    }
                    BufferedInputStream(connection.inputStream, BUFFER_SIZE).use { input ->
                        BufferedOutputStream(FileOutputStream(output, appending), BUFFER_SIZE).use { out ->
                            copyWithState(input, out, pauseRequested, cancelled, limiter = limiter) { count ->
                                val delta = count.toLong()
                                val current = downloaded.addAndGet(delta)
                                addRouteBytes(route.label, delta, wifiSessionBytes, mobileSessionBytes)
                                onProgress(
                                    Progress(
                                        current,
                                        resolvedTotal,
                                        withMeasuredNetworkShare(progressMessage, wifiSessionBytes, mobileSessionBytes)
                                    )
                                )
                            }
                        }
                    }
                    return
                } finally {
                    connection.disconnect()
                }
            } catch (t: Throwable) {
                when (t) {
                    is DownloadPausedException -> throw t
                    is DownloadCancelledException -> throw t
                }
                lastError = t
                if (routeIndex < routes.lastIndex) Thread.sleep(500)
            }
        }
        throw IllegalStateException("Download failed on all available networks.", lastError)
    }

    private fun copyWithState(
        input: BufferedInputStream,
        output: BufferedOutputStream,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean,
        shouldYield: () -> Boolean = { false },
        onRawBytes: (Int) -> Unit = { },
        limiter: BandwidthLimiter,
        onBytes: (Int) -> Unit
    ) {
        val buffer = ByteArray(BUFFER_SIZE)
        var pendingProgressBytes = 0
        var lastProgressReportNanos = System.nanoTime()

        while (true) {
            ensureRunning(pauseRequested, cancelled)
            if (shouldYield()) {
                if (pendingProgressBytes > 0) {
                    onBytes(pendingProgressBytes)
                    pendingProgressBytes = 0
                }
                output.flush()
                throw WorkerYieldException()
            }
            val read = input.read(buffer)
            if (read == -1) break
            limiter.throttle(read)
            output.write(buffer, 0, read)
            onRawBytes(read)
            pendingProgressBytes += read

            // Alpha 0.4.4: never push a DB/notification/UI update for every socket read.
            // Network streams can return many tiny reads, especially with several workers.
            // Batch progress so downloader threads spend their time moving bytes instead.
            val now = System.nanoTime()
            if (pendingProgressBytes >= PROGRESS_BATCH_BYTES ||
                now - lastProgressReportNanos >= PROGRESS_BATCH_NANOS
            ) {
                onBytes(pendingProgressBytes)
                pendingProgressBytes = 0
                lastProgressReportNanos = now
            }
        }

        if (pendingProgressBytes > 0) onBytes(pendingProgressBytes)
    }

    private fun storageCategory(fileName: String, mimeType: String): String {
        val lowerName = fileName.lowercase()
        val lowerMime = mimeType.lowercase()
        return when {
            lowerMime.startsWith("video/") || lowerName.endsWith(".mp4") || lowerName.endsWith(".mkv") || lowerName.endsWith(".webm") || lowerName.endsWith(".mov") -> "Video"
            lowerMime.startsWith("audio/") || lowerName.endsWith(".mp3") || lowerName.endsWith(".m4a") || lowerName.endsWith(".flac") || lowerName.endsWith(".wav") -> "Audio"
            lowerName.endsWith(".apk") || lowerName.endsWith(".xapk") || lowerName.endsWith(".apks") -> "Apps"
            lowerName.endsWith(".zip") || lowerName.endsWith(".rar") || lowerName.endsWith(".7z") || lowerName.endsWith(".tar") || lowerName.endsWith(".gz") || lowerName.endsWith(".iso") -> "Archives"
            lowerMime.startsWith("text/") || lowerMime.contains("pdf") || lowerName.endsWith(".pdf") || lowerName.endsWith(".doc") || lowerName.endsWith(".docx") || lowerName.endsWith(".xls") || lowerName.endsWith(".xlsx") || lowerName.endsWith(".ppt") || lowerName.endsWith(".pptx") || lowerName.endsWith(".txt") -> "Documents"
            else -> "Other"
        }
    }

    private fun uniqueDisplayName(originalName: String, relativePath: String): String {
        val resolver = context.contentResolver
        val dot = originalName.lastIndexOf('.')
        val hasExtension = dot > 0 && dot < originalName.length - 1
        val base = if (hasExtension) originalName.substring(0, dot) else originalName
        val extension = if (hasExtension) originalName.substring(dot) else ""

        fun exists(candidate: String): Boolean {
            val projection = arrayOf(MediaStore.Downloads._ID)
            val selection = "${MediaStore.Downloads.DISPLAY_NAME} = ? AND ${MediaStore.Downloads.RELATIVE_PATH} LIKE ?"
            val pathArg = relativePath.trimEnd('/') + "/%"
            return runCatching {
                resolver.query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    projection,
                    selection,
                    arrayOf(candidate, pathArg),
                    null
                )?.use { it.moveToFirst() } ?: false
            }.getOrDefault(false)
        }

        if (!exists(originalName)) return originalName
        for (index in 1..9999) {
            val candidate = "$base ($index)$extension"
            if (!exists(candidate)) return candidate
        }
        return "$base (${System.currentTimeMillis()})$extension"
    }

    private fun resolveRequestedFileName(requested: String?, fallback: String): String {
        val raw = requested?.trim()?.takeIf { it.isNotBlank() } ?: return fallback
        val safe = raw.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(180).trim().ifBlank { return fallback }
        val fallbackDot = fallback.lastIndexOf('.')
        val fallbackExt = if (fallbackDot > 0 && fallbackDot < fallback.length - 1) fallback.substring(fallbackDot) else ""
        val requestedHasExt = safe.lastIndexOf('.').let { it > 0 && it < safe.length - 1 }
        return if (!requestedHasExt && fallbackExt.isNotBlank()) "$safe$fallbackExt" else safe
    }

    private fun customFolderNames(treeUri: Uri): Set<String> {
        val resolver = context.contentResolver
        val treeId = DocumentsContract.getTreeDocumentId(treeUri)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, treeId)
        val names = linkedSetOf<String>()
        resolver.query(
            children,
            arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            while (cursor.moveToNext()) if (nameIndex >= 0) names += cursor.getString(nameIndex)
        }
        return names
    }

    private fun uniqueCustomName(treeUri: Uri, originalName: String): String {
        val existing = runCatching { customFolderNames(treeUri) }.getOrDefault(emptySet())
        if (originalName !in existing) return originalName
        val dot = originalName.lastIndexOf('.')
        val hasExtension = dot > 0 && dot < originalName.length - 1
        val base = if (hasExtension) originalName.substring(0, dot) else originalName
        val extension = if (hasExtension) originalName.substring(dot) else ""
        for (index in 1..9999) {
            val candidate = "$base ($index)$extension"
            if (candidate !in existing) return candidate
        }
        return "$base (${System.currentTimeMillis()})$extension"
    }

    private fun publishToCustomFolder(
        workDir: File,
        partCount: Int,
        fileName: String,
        mimeType: String,
        duplicateSafeFileNames: Boolean,
        outputTreeUri: String,
        cancelled: AtomicBoolean
    ): Pair<Uri, String> {
        val resolver = context.contentResolver
        val treeUri = Uri.parse(outputTreeUri)
        val treeId = DocumentsContract.getTreeDocumentId(treeUri)
        val parentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, treeId)
        val finalFileName = if (duplicateSafeFileNames) uniqueCustomName(treeUri, fileName) else fileName
        val uri = DocumentsContract.createDocument(
            resolver,
            parentUri,
            mimeType.ifBlank { "application/octet-stream" },
            finalFileName
        ) ?: error("Android could not create a file in the selected folder.")
        try {
            resolver.openOutputStream(uri, "w")?.use { rawOut ->
                BufferedOutputStream(rawOut, BUFFER_SIZE).use { out ->
                    for (index in 0 until partCount) {
                        if (cancelled.get()) throw DownloadCancelledException()
                        val part = File(workDir, "part_$index.tmp")
                        require(part.exists()) { "Missing segment $index" }
                        part.inputStream().buffered(BUFFER_SIZE).use { input -> input.copyTo(out, BUFFER_SIZE) }
                    }
                }
            } ?: error("Unable to open the selected output folder.")
            return uri to finalFileName
        } catch (t: Throwable) {
            runCatching { DocumentsContract.deleteDocument(resolver, uri) }
            throw t
        }
    }

    private fun publishToDownloads(
        workDir: File,
        partCount: Int,
        fileName: String,
        mimeType: String,
        autoOrganizeDownloads: Boolean,
        duplicateSafeFileNames: Boolean,
        outputTreeUri: String?,
        cancelled: AtomicBoolean
    ): Pair<Uri, String> {
        if (!outputTreeUri.isNullOrBlank()) {
            return publishToCustomFolder(workDir, partCount, fileName, mimeType, duplicateSafeFileNames, outputTreeUri, cancelled)
        }
        val resolver = context.contentResolver
        val basePath = Environment.DIRECTORY_DOWNLOADS + "/MultiFetch"
        val relativePath = if (autoOrganizeDownloads) {
            "$basePath/${storageCategory(fileName, mimeType)}"
        } else {
            basePath
        }
        val finalFileName = if (duplicateSafeFileNames) {
            uniqueDisplayName(fileName, relativePath)
        } else {
            fileName
        }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, finalFileName)
            put(MediaStore.Downloads.MIME_TYPE, mimeType)
            put(MediaStore.Downloads.RELATIVE_PATH, relativePath)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }

        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Android could not create the output file.")
        try {
            resolver.openOutputStream(uri, "w")?.use { rawOut ->
                BufferedOutputStream(rawOut, BUFFER_SIZE).use { out ->
                    for (index in 0 until partCount) {
                        if (cancelled.get()) throw DownloadCancelledException()
                        val part = File(workDir, "part_$index.tmp")
                        require(part.exists()) { "Missing segment $index" }
                        part.inputStream().buffered(BUFFER_SIZE).use { input ->
                            input.copyTo(out, BUFFER_SIZE)
                        }
                    }
                }
            } ?: error("Unable to open output stream.")

            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return uri to finalFileName
        } catch (t: Throwable) {
            resolver.delete(uri, null, null)
            throw t
        }
    }

    private fun open(
        url: URL,
        route: NetworkRouter.Route,
        requestHeaders: RequestHeaders
    ): HttpURLConnection = route.open(url).apply {
        connectTimeout = 15_000
        readTimeout = 25_000
        instanceFollowRedirects = true
        useCaches = false
        setRequestProperty("Accept-Encoding", "identity")
        setRequestProperty("Connection", "keep-alive")
        setRequestProperty("Accept", "*/*")
        setRequestProperty(
            "User-Agent",
            requestHeaders.userAgent ?: "MultiFetch/0.6.3 Android Download Manager"
        )
        requestHeaders.referer?.let { setRequestProperty("Referer", it) }
        requestHeaders.cookie?.let { setRequestProperty("Cookie", it) }
    }

    private fun addRouteBytes(
        routeLabel: String,
        delta: Long,
        wifiBytes: AtomicLong,
        mobileBytes: AtomicLong
    ) {
        when (routeLabel) {
            "Wi‑Fi" -> wifiBytes.addAndGet(delta)
            "Mobile" -> mobileBytes.addAndGet(delta)
        }
    }

    private fun withMeasuredNetworkShare(
        base: String,
        wifiBytes: AtomicLong,
        mobileBytes: AtomicLong
    ): String {
        val wifi = wifiBytes.get().coerceAtLeast(0L)
        val mobile = mobileBytes.get().coerceAtLeast(0L)
        val total = wifi + mobile
        if (total <= 0L) return base
        val wifiPct = ((wifi * 100L) / total).toInt().coerceIn(0, 100)
        val mobilePct = 100 - wifiPct
        return "$base • WiFi $wifiPct% • Mobile $mobilePct%"
    }

    private fun activeMessage(networkLabel: String, turboMode: Boolean): String =
        "Downloading • $networkLabel${if (turboMode) " • Turbo" else ""}"

    private fun parseTotalFromContentRange(value: String?): Long {
        if (value.isNullOrBlank()) return -1L
        return value.substringAfter('/', "").toLongOrNull() ?: -1L
    }

    private fun extractFileName(connection: HttpURLConnection, url: URL): String {
        val disposition = connection.getHeaderField("Content-Disposition").orEmpty()
        val encoded = Regex("filename\\*=UTF-8''([^;]+)", RegexOption.IGNORE_CASE)
            .find(disposition)?.groupValues?.getOrNull(1)
        val plain = Regex("filename=\"?([^\";]+)", RegexOption.IGNORE_CASE)
            .find(disposition)?.groupValues?.getOrNull(1)

        val candidate = encoded?.let {
            runCatching { URLDecoder.decode(it, StandardCharsets.UTF_8.name()) }.getOrNull()
        } ?: plain ?: url.path.substringAfterLast('/').substringBefore('?')

        return sanitizeFileName(candidate.ifBlank { "download_${System.currentTimeMillis()}" })
    }

    private fun sanitizeFileName(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .take(180)
            .ifBlank { "download_${System.currentTimeMillis()}" }

    private fun ensureRunning(pauseRequested: AtomicBoolean, cancelled: AtomicBoolean) {
        if (cancelled.get()) throw DownloadCancelledException()
        if (pauseRequested.get()) throw DownloadPausedException()
        if (Thread.currentThread().isInterrupted) {
            if (pauseRequested.get()) throw DownloadPausedException()
            if (cancelled.get()) throw DownloadCancelledException()
        }
    }

    private fun unwrap(t: Throwable): Throwable {
        var current = t
        while (current.cause != null && current !is DownloadPausedException && current !is DownloadCancelledException) {
            current = current.cause!!
        }
        return current
    }

    companion object {
        init {
            // Android's HttpURLConnection keeps a small idle connection pool by default.
            // Turbo uses several long-lived parallel range requests, so allow more reusable
            // keep-alive sockets between chunks instead of repeatedly paying TCP/TLS setup cost.
            runCatching { System.setProperty("http.keepAlive", "true") }
            runCatching { System.setProperty("http.maxConnections", "32") }
        }

        private const val BUFFER_SIZE = 512 * 1024
        private const val PROGRESS_BATCH_BYTES = 256 * 1024
        private const val PROGRESS_BATCH_NANOS = 250_000_000L
        private const val MIB = 1024 * 1024
        private const val MAX_PARTS = 96
    }
}
