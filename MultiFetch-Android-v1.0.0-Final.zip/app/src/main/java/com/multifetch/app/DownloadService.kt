package com.multifetch.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.multifetch.app.download.DownloadEngine
import com.multifetch.app.download.DownloadStatus
import com.multifetch.app.download.DownloadStore
import com.multifetch.app.download.DownloadTask
import com.multifetch.app.download.TorrentDownloadEngine
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

class DownloadService : Service() {

    private data class TaskControl(
        val pauseRequested: AtomicBoolean = AtomicBoolean(false),
        val cancelled: AtomicBoolean = AtomicBoolean(false)
    )

    private data class SpeedState(
        var lastNotifyAt: Long = 0L,
        var lastSpeedAt: Long = System.currentTimeMillis(),
        var lastSpeedBytes: Long = 0L,
        var lastPublishedBytes: Long = 0L,
        var currentSpeed: Long = 0L
    )

    private val coordinator = Executors.newSingleThreadExecutor()
    private val downloadWorkers = Executors.newFixedThreadPool(MAX_SIMULTANEOUS_DOWNLOADS)
    private val delayedCoordinator = Executors.newSingleThreadScheduledExecutor()
    private val drainScheduled = AtomicBoolean(false)
    private val wifiRecheckScheduled = AtomicBoolean(false)
    private val activeControls = ConcurrentHashMap<String, TaskControl>()

    private lateinit var store: DownloadStore

    private val performanceLockGuard = Any()
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    override fun onCreate() {
        super.onCreate()
        store = DownloadStore(applicationContext)
        store.recoverInterrupted()
        createNotificationChannel()
        scheduleNextAlarm()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ENQUEUE, ACTION_RECOVER -> {
                ensureForegroundSummary("Preparing queue…")
                scheduleDrain()
            }

            ACTION_PAUSE -> pauseTask(intent.getStringExtra(EXTRA_TASK_ID))
            ACTION_RESUME -> resumeTask(intent.getStringExtra(EXTRA_TASK_ID))
            ACTION_CANCEL -> cancelTask(intent.getStringExtra(EXTRA_TASK_ID))
            ACTION_RETRY -> retryTask(intent.getStringExtra(EXTRA_TASK_ID))
            else -> {
                // START_STICKY may recreate the service with a null intent.
                ensureForegroundSummary("Recovering queue…")
                scheduleDrain()
            }
        }
        return START_STICKY
    }

    private fun pauseTask(requestedId: String?) {
        val id = requestedId ?: return
        val control = activeControls[id]
        if (control != null) {
            control.pauseRequested.set(true)
            store.setStatus(id, DownloadStatus.PAUSED, "Paused")
        } else {
            val task = store.get(id) ?: return
            if (task.status == DownloadStatus.QUEUED) {
                store.setStatus(id, DownloadStatus.PAUSED, "Paused")
            }
        }
        NotificationManagerCompat.from(this).cancel(notificationId(id))
        notifyQueueChanged()
        scheduleNextAlarm()
        scheduleDrain()
    }

    private fun resumeTask(requestedId: String?) {
        val id = requestedId ?: return
        val task = store.get(id) ?: return
        val control = activeControls[id]
        if (control != null) {
            control.pauseRequested.set(false)
            store.setStatus(id, DownloadStatus.DOWNLOADING, "Downloading")
            notifyQueueChanged()
            return
        }
        if (task.status == DownloadStatus.PAUSED || task.status == DownloadStatus.FAILED) {
            store.clearSchedule(id)
            store.resetForRetry(id)
            ensureForegroundSummary("Resuming queue…")
            notifyQueueChanged()
            scheduleNextAlarm()
            scheduleDrain()
        }
    }

    private fun retryTask(requestedId: String?) {
        val id = requestedId ?: return
        val task = store.get(id) ?: return
        if (task.status == DownloadStatus.FAILED || task.status == DownloadStatus.CANCELLED) {
            store.clearSchedule(id)
            store.resetForRetry(id)
            ensureForegroundSummary("Retrying…")
            notifyQueueChanged()
            scheduleNextAlarm()
            scheduleDrain()
        }
    }

    private fun cancelTask(requestedId: String?) {
        val id = requestedId ?: return
        val control = activeControls[id]
        if (control != null) {
            control.cancelled.set(true)
            control.pauseRequested.set(false)
            store.setStatus(id, DownloadStatus.CANCELLED, "Cancelling…")
        } else {
            val task = store.get(id) ?: return
            if (task.status != DownloadStatus.COMPLETED) {
                store.setStatus(id, DownloadStatus.CANCELLED, "Cancelled")
                deleteWorkspaceFor(task)
            }
        }
        NotificationManagerCompat.from(this).cancel(notificationId(id))
        notifyQueueChanged()
        scheduleNextAlarm()
        scheduleDrain()
    }

    private fun deleteWorkspaceFor(task: DownloadTask) {
        if (TorrentDownloadEngine.isTorrentSource(task.url)) {
            TorrentDownloadEngine(applicationContext).deleteWorkspace(task.id)
        } else {
            DownloadEngine(applicationContext).deleteWorkspace(task.id)
        }
    }

    private fun scheduleDrain() {
        if (!drainScheduled.compareAndSet(false, true)) return
        coordinator.execute {
            try {
                coordinateQueue()
            } finally {
                drainScheduled.set(false)
                val maxConcurrent = SettingsStore(applicationContext).maxConcurrentDownloads
                if (activeControls.size < maxConcurrent &&
                    store.nextRunnable() != null &&
                    (!SettingsStore(applicationContext).wifiOnlyDownloads || hasValidatedWifi())
                ) {
                    scheduleDrain()
                }
            }
        }
    }

    private fun coordinateQueue() {
        val settings = SettingsStore(applicationContext)
        val maxConcurrent = settings.maxConcurrentDownloads.coerceIn(1, MAX_SIMULTANEOUS_DOWNLOADS)

        while (activeControls.size < maxConcurrent) {
            val next = store.nextRunnable() ?: break

            if (settings.wifiOnlyDownloads && !hasValidatedWifi()) {
                ensureForegroundSummary("Waiting for Wi‑Fi • mobile data protected")
                scheduleWifiRecheck()
                scheduleNextAlarm()
                return
            }

            val control = TaskControl()
            if (activeControls.putIfAbsent(next.id, control) != null) continue

            val startLabel = buildStartLabel(settings, TorrentDownloadEngine.isTorrentSource(next.url))
            store.setStatus(next.id, DownloadStatus.DOWNLOADING, startLabel)
            notifyQueueChanged()
            ensurePerformanceLocks()
            ensureForegroundSummary(summaryText())

            downloadWorkers.execute {
                runTask(next, control)
            }
        }

        scheduleNextAlarm()
        val activeCount = activeControls.size
        if (activeCount > 0) {
            ensureForegroundSummary(summaryText())
            return
        }

        val runnable = store.nextRunnable()
        if (runnable != null && settings.wifiOnlyDownloads && !hasValidatedWifi()) {
            ensureForegroundSummary("Waiting for Wi‑Fi • mobile data protected")
            scheduleWifiRecheck()
            return
        }

        // Future-only schedules are handled by AlarmManager, so the foreground
        // service does not need to stay alive while nothing is actually running.
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun scheduleWifiRecheck() {
        if (!wifiRecheckScheduled.compareAndSet(false, true)) return
        delayedCoordinator.schedule({
            wifiRecheckScheduled.set(false)
            scheduleDrain()
        }, 1500L, TimeUnit.MILLISECONDS)
    }

    private fun runTask(task: DownloadTask, control: TaskControl) {
        val speedState = SpeedState(
            lastSpeedBytes = task.downloadedBytes,
            lastPublishedBytes = task.downloadedBytes
        )
        val settings = SettingsStore(applicationContext)
        val effectiveCombine = settings.combineWifiAndCellular && !settings.wifiOnlyDownloads
        val startLabel = buildStartLabel(settings, TorrentDownloadEngine.isTorrentSource(task.url))
        store.setStatus(task.id, DownloadStatus.DOWNLOADING, startLabel)
        notifyQueueChanged()
        updateTaskNotification(task.id, task.downloadedBytes, task.totalBytes, startLabel)
        ensureForegroundSummary(summaryText())

        try {
            val directEngine = DownloadEngine(applicationContext)
            val torrentEngine = TorrentDownloadEngine(applicationContext)
            val isTorrent = TorrentDownloadEngine.isTorrentSource(task.url)
            val maxAutoRetries = if (settings.autoRetryFailedDownloads) 2 else 0
            var autoRetryAttempt = 0
            var result: DownloadEngine.Result? = null

            while (result == null) {
                try {
                    val latest = store.get(task.id)
                    val probeCallback: (DownloadEngine.ProbeInfo) -> Unit = { probe ->
                        store.updateProbe(
                            id = task.id,
                            fileName = probe.fileName,
                            mimeType = probe.mimeType,
                            totalBytes = probe.totalBytes,
                            segmentCount = probe.segmentCount
                        )
                        notifyQueueChanged()
                    }
                    val progressCallback: (DownloadEngine.Progress) -> Unit = { progress ->
                        updateProgress(
                            taskId = task.id,
                            downloaded = progress.downloadedBytes,
                            total = progress.totalBytes,
                            message = progress.message,
                            speedState = speedState
                        )
                    }

                    result = if (isTorrent) {
                        torrentEngine.download(
                            taskId = task.id,
                            source = task.url,
                            speedLimitBytesPerSecond = settings.speedLimitBytesPerSecond,
                            duplicateSafeFileNames = settings.duplicateSafeFileNames,
                            pauseRequested = control.pauseRequested,
                            cancelled = control.cancelled,
                            onProbe = probeCallback,
                            onProgress = progressCallback
                        )
                    } else {
                        directEngine.download(
                            taskId = task.id,
                            rawUrl = task.url,
                            existingSegmentCount = if ((latest?.downloadedBytes ?: 0L) > 0L) {
                                latest?.segmentCount ?: task.segmentCount
                            } else {
                                0
                            },
                            turboMode = settings.turboMode,
                            combineWifiAndCellular = effectiveCombine,
                            turboConnections = settings.turboConnections,
                            autoOrganizeDownloads = settings.autoOrganizeDownloads,
                            duplicateSafeFileNames = settings.duplicateSafeFileNames,
                            requestedFileName = latest?.requestedFileName ?: task.requestedFileName,
                            outputTreeUri = latest?.outputTreeUri ?: task.outputTreeUri,
                            speedLimitBytesPerSecond = settings.speedLimitBytesPerSecond,
                            requestCookie = latest?.requestCookie ?: task.requestCookie,
                            requestReferer = latest?.requestReferer ?: task.requestReferer,
                            requestUserAgent = latest?.requestUserAgent ?: task.requestUserAgent,
                            expectedSha256 = latest?.expectedSha256 ?: task.expectedSha256,
                            pauseRequested = control.pauseRequested,
                            cancelled = control.cancelled,
                            onProbe = probeCallback,
                            onProgress = progressCallback
                        )
                    }
                } catch (t: Throwable) {
                    if (t is DownloadEngine.DownloadPausedException || t is DownloadEngine.DownloadCancelledException) {
                        throw t
                    }
                    if (autoRetryAttempt >= maxAutoRetries) throw t

                    if (settings.wifiOnlyDownloads && !hasValidatedWifi()) {
                        val canResume = waitForWifi(task.id, DownloadStatus.DOWNLOADING, control)
                        if (!canResume) {
                            if (control.cancelled.get()) throw DownloadEngine.DownloadCancelledException()
                            throw DownloadEngine.DownloadPausedException()
                        }
                    }

                    autoRetryAttempt++
                    val retryLabel = "Connection interrupted • auto retry $autoRetryAttempt/$maxAutoRetries"
                    store.setStatus(task.id, DownloadStatus.DOWNLOADING, retryLabel)
                    notifyQueueChanged()
                    updateTaskNotification(task.id, speedState.lastPublishedBytes, task.totalBytes, retryLabel)
                    ensureForegroundSummary(summaryText())

                    try {
                        Thread.sleep(1200L * autoRetryAttempt)
                    } catch (_: InterruptedException) {
                        Thread.currentThread().interrupt()
                        throw t
                    }

                    if (control.cancelled.get()) throw DownloadEngine.DownloadCancelledException()
                    if (control.pauseRequested.get()) throw DownloadEngine.DownloadPausedException()
                }
            }

            val completedResult = requireNotNull(result)
            store.markCompleted(
                task.id,
                completedResult.fileName,
                completedResult.totalBytes,
                completedResult.uri.toString(),
                completedResult.sha256
            )
            notifyQueueChanged()
            val completedTask = store.get(task.id)
            NotificationManagerCompat.from(this).notify(
                notificationId(task.id),
                completionNotification(
                    taskId = task.id,
                    fileName = completedResult.fileName,
                    uriString = completedResult.uri.toString(),
                    mimeType = completedTask?.mimeType
                )
            )
        } catch (_: DownloadEngine.DownloadPausedException) {
            val latest = store.get(task.id)
            when {
                latest?.status == DownloadStatus.PAUSED ->
                    store.setStatus(task.id, DownloadStatus.PAUSED, "Paused • progress saved")
                latest?.status == DownloadStatus.DOWNLOADING && !control.pauseRequested.get() ->
                    store.resetForRetry(task.id)
            }
            NotificationManagerCompat.from(this).cancel(notificationId(task.id))
            notifyQueueChanged()
        } catch (_: DownloadEngine.DownloadCancelledException) {
            store.setStatus(task.id, DownloadStatus.CANCELLED, "Cancelled")
            NotificationManagerCompat.from(this).cancel(notificationId(task.id))
            notifyQueueChanged()
        } catch (t: Throwable) {
            val message = rootMessage(t)
            store.setStatus(task.id, DownloadStatus.FAILED, message)
            notifyQueueChanged()
            NotificationManagerCompat.from(this).notify(
                notificationId(task.id),
                failureNotification(task.id, task.fileName ?: "Download", message)
            )
        } finally {
            activeControls.remove(task.id)
            if (activeControls.isEmpty()) releasePerformanceLocks()
            scheduleNextAlarm()
            ensureForegroundIfNeeded()
            scheduleDrain()
        }
    }

    private fun buildStartLabel(settings: SettingsStore, torrent: Boolean = false): String = buildString {
        if (torrent) {
            append("Starting • BitTorrent")
        } else {
            append("Starting")
            if (settings.turboMode) append(" • Turbo ${settings.turboConnections} conn")
        }
        if (settings.speedLimitBytesPerSecond > 0L) append(" • Limit ${formatSpeed(settings.speedLimitBytesPerSecond)}")
        if (settings.wifiOnlyDownloads) append(" • Wi‑Fi only")
        else if (!torrent && settings.combineWifiAndCellular) append(" • Multi-network")
    }

    private fun summaryText(): String {
        val count = activeControls.size
        val maxConcurrent = SettingsStore(applicationContext).maxConcurrentDownloads
        return when {
            count <= 0 -> "Preparing queue…"
            count == 1 -> "1 active download • up to $maxConcurrent simultaneous"
            else -> "$count active downloads • up to $maxConcurrent simultaneous"
        }
    }

    private fun ensureForegroundIfNeeded() {
        if (activeControls.isNotEmpty()) {
            ensureForegroundSummary(summaryText())
        }
    }

    private fun hasValidatedWifi(): Boolean {
        val connectivity = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        return connectivity.allNetworks.any { network ->
            val caps = connectivity.getNetworkCapabilities(network) ?: return@any false
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        }
    }

    private fun waitForWifi(taskId: String, waitingStatus: DownloadStatus, control: TaskControl): Boolean {
        while (true) {
            val settings = SettingsStore(applicationContext)
            if (!settings.wifiOnlyDownloads || hasValidatedWifi()) return true

            val latest = store.get(taskId) ?: return false
            if (latest.status == DownloadStatus.CANCELLED || latest.status == DownloadStatus.PAUSED) return false
            if (control.cancelled.get() || control.pauseRequested.get()) return false

            val label = "Waiting for Wi‑Fi • mobile data protected"
            store.setStatus(taskId, waitingStatus, label)
            notifyQueueChanged()
            updateTaskNotification(taskId, latest.downloadedBytes, latest.totalBytes, label)
            ensureForegroundSummary(summaryText())

            try {
                Thread.sleep(1_500L)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                return false
            }
        }
    }

    private fun updateProgress(
        taskId: String,
        downloaded: Long,
        total: Long,
        message: String,
        speedState: SpeedState
    ) {
        synchronized(speedState) {
            val now = System.currentTimeMillis()
            val safeDownloaded = max(downloaded, speedState.lastPublishedBytes)

            if (now - speedState.lastSpeedAt >= 1000) {
                val seconds = max(1.0, (now - speedState.lastSpeedAt) / 1000.0)
                val speedBytes = max(safeDownloaded, speedState.lastSpeedBytes)
                val instant = ((speedBytes - speedState.lastSpeedBytes) / seconds).toLong().coerceAtLeast(0L)
                speedState.currentSpeed = if (speedState.currentSpeed <= 0L) {
                    instant
                } else {
                    (speedState.currentSpeed * 0.55 + instant * 0.45).toLong().coerceAtLeast(0L)
                }
                speedState.lastSpeedAt = now
                speedState.lastSpeedBytes = speedBytes
            }

            val isTransferMessage = message.startsWith("Downloading") || message.startsWith("Resuming")
            val shouldPublish = !isTransferMessage || now - speedState.lastNotifyAt >= 500
            if (!shouldPublish) return

            speedState.lastNotifyAt = now
            speedState.lastPublishedBytes = max(speedState.lastPublishedBytes, safeDownloaded)
            val label = if (isTransferMessage && speedState.currentSpeed > 0) {
                "$message • ${formatSpeed(speedState.currentSpeed)}"
            } else message

            store.updateProgress(taskId, speedState.lastPublishedBytes, total, label)
            updateTaskNotification(taskId, speedState.lastPublishedBytes, total, label)
            notifyQueueChanged()
        }
    }

    private fun ensureForegroundSummary(text: String) {
        val notification = foregroundSummaryNotification(text)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(FOREGROUND_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(FOREGROUND_ID, notification)
        }
    }

    private fun foregroundSummaryNotification(text: String): android.app.Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("MultiFetch")
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setContentIntent(openAppPendingIntent())
            .setProgress(0, 0, true)
            .build()

    private fun updateTaskNotification(taskId: String, downloaded: Long, total: Long, text: String) {
        val percent = if (total > 0) ((downloaded * 100) / total).toInt().coerceIn(0, 100) else 0
        NotificationManagerCompat.from(this).notify(
            notificationId(taskId),
            taskProgressNotification(taskId, text, percent, 100, total <= 0)
        )
    }

    private fun taskProgressNotification(
        taskId: String,
        text: String,
        progress: Int,
        max: Int,
        indeterminate: Boolean
    ): android.app.Notification = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.stat_sys_download)
        .setContentTitle("MultiFetch download")
        .setContentText(text)
        .setOnlyAlertOnce(true)
        .setOngoing(true)
        .setContentIntent(openAppPendingIntent())
        .setProgress(max, progress, indeterminate)
        .addAction(0, "Pause", controlPendingIntent(ACTION_PAUSE, taskId, 10))
        .addAction(0, "Cancel", controlPendingIntent(ACTION_CANCEL, taskId, 11))
        .build()

    private fun completionNotification(
        taskId: String,
        fileName: String,
        uriString: String,
        mimeType: String?
    ): android.app.Notification {
        val openIntent = openDownloadedFilePendingIntent(taskId, uriString, mimeType)
        val shareIntent = shareDownloadedFilePendingIntent(taskId, uriString, mimeType)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Download complete")
            .setContentText(fileName)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$fileName • Tap to open"))
            .setAutoCancel(true)
            .setContentIntent(openIntent)
            .addAction(0, "Open", openIntent)
            .addAction(0, "Share", shareIntent)
            .build()
    }

    private fun failureNotification(taskId: String, fileName: String, message: String) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle("Download failed: $fileName")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .setContentIntent(openAppPendingIntent())
            .addAction(0, "Retry", controlPendingIntent(ACTION_RETRY, taskId, 12))
            .build()

    private fun openDownloadedFilePendingIntent(taskId: String, uriString: String, mimeType: String?): PendingIntent {
        val uri = android.net.Uri.parse(uriString)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType?.takeIf { it.isNotBlank() } ?: "*/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return PendingIntent.getActivity(
            this,
            stableRequestCode(taskId, 30),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun shareDownloadedFilePendingIntent(taskId: String, uriString: String, mimeType: String?): PendingIntent {
        val uri = android.net.Uri.parse(uriString)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mimeType?.takeIf { it.isNotBlank() } ?: "*/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(send, "Share downloaded file")
        return PendingIntent.getActivity(
            this,
            stableRequestCode(taskId, 31),
            chooser,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun openAppPendingIntent(): PendingIntent {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            this,
            1,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun controlPendingIntent(action: String, taskId: String, requestCode: Int): PendingIntent {
        val intent = Intent(this, DownloadService::class.java).apply {
            this.action = action
            putExtra(EXTRA_TASK_ID, taskId)
        }
        return PendingIntent.getService(
            this,
            stableRequestCode(taskId, requestCode),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun stableRequestCode(taskId: String, salt: Int): Int =
        ((taskId.hashCode() * 31) + salt) and 0x7FFFFFFF

    private fun ensurePerformanceLocks() {
        synchronized(performanceLockGuard) {
            if (wakeLock?.isHeld != true) {
                wakeLock = runCatching {
                    val power = getSystemService(POWER_SERVICE) as PowerManager
                    power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MultiFetch:Download").apply {
                        setReferenceCounted(false)
                        acquire(12 * 60 * 60 * 1000L)
                    }
                }.getOrNull()
            }
            if (wifiLock?.isHeld != true) {
                wifiLock = runCatching {
                    val wifi = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
                    @Suppress("DEPRECATION")
                    wifi.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "MultiFetch:HighPerf").apply {
                        setReferenceCounted(false)
                        acquire()
                    }
                }.getOrNull()
            }
        }
    }

    private fun releasePerformanceLocks() {
        synchronized(performanceLockGuard) {
            runCatching { if (wifiLock?.isHeld == true) wifiLock?.release() }
            runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
            wifiLock = null
            wakeLock = null
        }
    }

    private fun scheduleNextAlarm() {
        DownloadScheduleManager.scheduleNext(applicationContext, store.nextScheduledAt())
    }

    private fun notifyQueueChanged() {
        sendBroadcast(Intent(ACTION_QUEUE_CHANGED).apply { setPackage(packageName) })
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Downloads",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Active MultiFetch downloads"
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun formatSpeed(bytesPerSecond: Long): String = when {
        bytesPerSecond >= 1024L * 1024L -> String.format("%.1f MB/s", bytesPerSecond / 1024.0 / 1024.0)
        bytesPerSecond >= 1024L -> String.format("%.0f KB/s", bytesPerSecond / 1024.0)
        else -> "$bytesPerSecond B/s"
    }

    private fun rootMessage(t: Throwable): String {
        var root = t
        while (root.cause != null) root = root.cause!!
        return root.message?.takeIf { it.isNotBlank() } ?: "Download failed"
    }

    private fun notificationId(taskId: String): Int = 2000 + (taskId.hashCode() and 0x3FFF)

    override fun onDestroy() {
        activeControls.forEach { (id, control) ->
            control.pauseRequested.set(true)
            val task = store.get(id)
            if (task?.status == DownloadStatus.DOWNLOADING) {
                store.setStatus(id, DownloadStatus.QUEUED, "Interrupted • ready to resume")
            }
        }
        releasePerformanceLocks()
        scheduleNextAlarm()
        coordinator.shutdownNow()
        delayedCoordinator.shutdownNow()
        downloadWorkers.shutdownNow()
        store.close()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_ENQUEUE = "com.multifetch.app.action.ENQUEUE"
        const val ACTION_RECOVER = "com.multifetch.app.action.RECOVER"
        const val ACTION_PAUSE = "com.multifetch.app.action.PAUSE"
        const val ACTION_RESUME = "com.multifetch.app.action.RESUME"
        const val ACTION_CANCEL = "com.multifetch.app.action.CANCEL"
        const val ACTION_RETRY = "com.multifetch.app.action.RETRY"
        const val ACTION_QUEUE_CHANGED = "com.multifetch.app.action.QUEUE_CHANGED"

        const val EXTRA_TASK_ID = "task_id"

        private const val CHANNEL_ID = "downloads"
        private const val FOREGROUND_ID = 1001
        private const val MAX_SIMULTANEOUS_DOWNLOADS = 3
    }
}
