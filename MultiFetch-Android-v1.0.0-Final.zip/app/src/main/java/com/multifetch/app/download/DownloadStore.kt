package com.multifetch.app.download

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.UUID

class DownloadStore(context: Context) : SQLiteOpenHelper(
    context.applicationContext,
    DB_NAME,
    null,
    DB_VERSION
) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE downloads (
                id TEXT PRIMARY KEY,
                url TEXT NOT NULL,
                file_name TEXT,
                mime_type TEXT,
                total_bytes INTEGER NOT NULL DEFAULT -1,
                downloaded_bytes INTEGER NOT NULL DEFAULT 0,
                segment_count INTEGER NOT NULL DEFAULT 1,
                priority INTEGER NOT NULL DEFAULT 1,
                request_cookie TEXT,
                request_referer TEXT,
                request_user_agent TEXT,
                requested_file_name TEXT,
                output_tree_uri TEXT,
                scheduled_at INTEGER,
                expected_sha256 TEXT,
                actual_sha256 TEXT,
                status TEXT NOT NULL,
                message TEXT NOT NULL DEFAULT '',
                output_uri TEXT,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_downloads_status_created ON downloads(status, created_at)")
        db.execSQL("CREATE INDEX idx_downloads_url_created ON downloads(url, created_at)")
        db.execSQL("CREATE INDEX idx_downloads_priority_created ON downloads(priority, created_at)")
        db.execSQL("CREATE INDEX idx_downloads_schedule ON downloads(status, scheduled_at)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE downloads ADD COLUMN priority INTEGER NOT NULL DEFAULT 1")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_downloads_priority_created ON downloads(priority, created_at)")
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE downloads ADD COLUMN request_cookie TEXT")
            db.execSQL("ALTER TABLE downloads ADD COLUMN request_referer TEXT")
            db.execSQL("ALTER TABLE downloads ADD COLUMN request_user_agent TEXT")
        }
        if (oldVersion < 4) {
            db.execSQL("ALTER TABLE downloads ADD COLUMN requested_file_name TEXT")
            db.execSQL("ALTER TABLE downloads ADD COLUMN output_tree_uri TEXT")
        }
        if (oldVersion < 5) {
            db.execSQL("ALTER TABLE downloads ADD COLUMN scheduled_at INTEGER")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_downloads_schedule ON downloads(status, scheduled_at)")
        }
        if (oldVersion < 6) {
            db.execSQL("ALTER TABLE downloads ADD COLUMN expected_sha256 TEXT")
            db.execSQL("ALTER TABLE downloads ADD COLUMN actual_sha256 TEXT")
        }
    }

    @Synchronized
    fun enqueue(
        url: String,
        requestCookie: String? = null,
        requestReferer: String? = null,
        requestUserAgent: String? = null,
        requestedFileName: String? = null,
        outputTreeUri: String? = null,
        scheduledAt: Long? = null,
        expectedSha256: String? = null
    ): DownloadTask {
        val now = System.currentTimeMillis()
        val id = UUID.randomUUID().toString()
        val futureSchedule = scheduledAt?.takeIf { it > now + 1_000L }
        val values = ContentValues().apply {
            put("id", id)
            put("url", url)
            put("total_bytes", -1L)
            put("downloaded_bytes", 0L)
            put("segment_count", 1)
            put("priority", 1)
            requestCookie?.takeIf { it.isNotBlank() }?.let { put("request_cookie", it) }
            requestReferer?.takeIf { it.isNotBlank() }?.let { put("request_referer", it) }
            requestUserAgent?.takeIf { it.isNotBlank() }?.let { put("request_user_agent", it) }
            requestedFileName?.trim()?.takeIf { it.isNotBlank() }?.let { put("requested_file_name", it) }
            outputTreeUri?.trim()?.takeIf { it.isNotBlank() }?.let { put("output_tree_uri", it) }
            futureSchedule?.let { put("scheduled_at", it) }
            FileIntegrity.normalizeSha256(expectedSha256)?.let { put("expected_sha256", it) }
            put("status", DownloadStatus.QUEUED.name)
            put("message", if (futureSchedule != null) "Scheduled" else "Queued")
            put("created_at", now)
            put("updated_at", now)
        }
        writableDatabase.insertOrThrow("downloads", null, values)
        return get(id)!!
    }

    @Synchronized
    fun get(id: String): DownloadTask? = readableDatabase.query(
        "downloads",
        null,
        "id = ?",
        arrayOf(id),
        null,
        null,
        null,
        "1"
    ).use { cursor -> if (cursor.moveToFirst()) cursor.toTask() else null }

    @Synchronized
    fun findLatestByUrl(url: String): DownloadTask? = readableDatabase.query(
        "downloads",
        null,
        "url = ?",
        arrayOf(url),
        null,
        null,
        "created_at DESC",
        "1"
    ).use { cursor -> if (cursor.moveToFirst()) cursor.toTask() else null }

    @Synchronized
    fun getAll(limit: Int = 100): List<DownloadTask> = readableDatabase.query(
        "downloads",
        null,
        null,
        null,
        null,
        null,
        "created_at DESC",
        limit.toString()
    ).use { cursor ->
        buildList {
            while (cursor.moveToNext()) add(cursor.toTask())
        }
    }

    /** Highest-priority queued item whose schedule is due. */
    @Synchronized
    fun nextRunnable(now: Long = System.currentTimeMillis()): DownloadTask? = readableDatabase.query(
        "downloads",
        null,
        "status = ? AND (scheduled_at IS NULL OR scheduled_at <= ?)",
        arrayOf(DownloadStatus.QUEUED.name, now.toString()),
        null,
        null,
        "priority DESC, created_at ASC",
        "1"
    ).use { cursor -> if (cursor.moveToFirst()) cursor.toTask() else null }

    /** Earliest future queue time, used to arm the Android alarm scheduler. */
    @Synchronized
    fun nextScheduledAt(now: Long = System.currentTimeMillis()): Long? = readableDatabase.rawQuery(
        "SELECT MIN(scheduled_at) FROM downloads WHERE status = ? AND scheduled_at IS NOT NULL AND scheduled_at > ?",
        arrayOf(DownloadStatus.QUEUED.name, now.toString())
    ).use { cursor ->
        if (cursor.moveToFirst() && !cursor.isNull(0)) cursor.getLong(0) else null
    }

    @Synchronized
    fun hasQueued(): Boolean = readableDatabase.rawQuery(
        "SELECT 1 FROM downloads WHERE status = ? LIMIT 1",
        arrayOf(DownloadStatus.QUEUED.name)
    ).use { it.moveToFirst() }

    @Synchronized
    fun recoverInterrupted() {
        val values = ContentValues().apply {
            put("status", DownloadStatus.QUEUED.name)
            put("message", "Recovered after restart")
            put("updated_at", System.currentTimeMillis())
        }
        writableDatabase.update(
            "downloads",
            values,
            "status = ?",
            arrayOf(DownloadStatus.DOWNLOADING.name)
        )
    }

    @Synchronized
    fun updateProbe(
        id: String,
        fileName: String,
        mimeType: String,
        totalBytes: Long,
        segmentCount: Int
    ) {
        update(id, ContentValues().apply {
            put("file_name", fileName)
            put("mime_type", mimeType)
            put("total_bytes", totalBytes)
            put("segment_count", segmentCount)
            put("updated_at", System.currentTimeMillis())
        })
    }

    @Synchronized
    fun updateProgress(id: String, downloadedBytes: Long, totalBytes: Long, message: String) {
        update(id, ContentValues().apply {
            put("downloaded_bytes", downloadedBytes.coerceAtLeast(0L))
            if (totalBytes > 0) put("total_bytes", totalBytes)
            put("message", message)
            put("updated_at", System.currentTimeMillis())
        })
    }

    @Synchronized
    fun setStatus(id: String, status: DownloadStatus, message: String) {
        update(id, ContentValues().apply {
            put("status", status.name)
            put("message", message)
            if (status == DownloadStatus.FAILED || status == DownloadStatus.CANCELLED) {
                putNull("request_cookie")
                putNull("request_referer")
                putNull("request_user_agent")
            }
            put("updated_at", System.currentTimeMillis())
        })
    }

    @Synchronized
    fun markCompleted(id: String, fileName: String, totalBytes: Long, outputUri: String, actualSha256: String? = null) {
        update(id, ContentValues().apply {
            put("file_name", fileName)
            put("downloaded_bytes", totalBytes)
            put("total_bytes", totalBytes)
            put("status", DownloadStatus.COMPLETED.name)
            put("message", "Saved: $fileName")
            put("output_uri", outputUri)
            actualSha256?.takeIf { it.isNotBlank() }?.let { put("actual_sha256", it) }
            putNull("scheduled_at")
            putNull("request_cookie")
            putNull("request_referer")
            putNull("request_user_agent")
            put("updated_at", System.currentTimeMillis())
        })
    }

    @Synchronized
    fun resetForRetry(id: String) {
        update(id, ContentValues().apply {
            put("status", DownloadStatus.QUEUED.name)
            put("message", "Queued for retry")
            put("updated_at", System.currentTimeMillis())
        })
    }

    @Synchronized
    fun clearSchedule(id: String) {
        update(id, ContentValues().apply {
            putNull("scheduled_at")
            put("updated_at", System.currentTimeMillis())
        })
    }

    @Synchronized
    fun setPriority(id: String, priority: Int) {
        update(id, ContentValues().apply {
            put("priority", priority.coerceIn(0, 2))
            put("updated_at", System.currentTimeMillis())
        })
    }

    @Synchronized
    fun delete(id: String) {
        writableDatabase.delete("downloads", "id = ?", arrayOf(id))
    }

    @Synchronized
    fun clearCompleted() {
        writableDatabase.delete(
            "downloads",
            "status = ?",
            arrayOf(DownloadStatus.COMPLETED.name)
        )
    }

    private fun update(id: String, values: ContentValues) {
        writableDatabase.update("downloads", values, "id = ?", arrayOf(id))
    }

    private fun Cursor.toTask(): DownloadTask = DownloadTask(
        id = getString(getColumnIndexOrThrow("id")),
        url = getString(getColumnIndexOrThrow("url")),
        fileName = getNullableString("file_name"),
        mimeType = getNullableString("mime_type"),
        totalBytes = getLong(getColumnIndexOrThrow("total_bytes")),
        downloadedBytes = getLong(getColumnIndexOrThrow("downloaded_bytes")),
        segmentCount = getInt(getColumnIndexOrThrow("segment_count")),
        priority = getInt(getColumnIndexOrThrow("priority")),
        requestCookie = getNullableString("request_cookie"),
        requestReferer = getNullableString("request_referer"),
        requestUserAgent = getNullableString("request_user_agent"),
        requestedFileName = getNullableString("requested_file_name"),
        outputTreeUri = getNullableString("output_tree_uri"),
        scheduledAt = getNullableLong("scheduled_at"),
        expectedSha256 = getNullableString("expected_sha256"),
        actualSha256 = getNullableString("actual_sha256"),
        status = runCatching {
            DownloadStatus.valueOf(getString(getColumnIndexOrThrow("status")))
        }.getOrDefault(DownloadStatus.FAILED),
        message = getString(getColumnIndexOrThrow("message")),
        outputUri = getNullableString("output_uri"),
        createdAt = getLong(getColumnIndexOrThrow("created_at")),
        updatedAt = getLong(getColumnIndexOrThrow("updated_at"))
    )

    private fun Cursor.getNullableString(column: String): String? {
        val index = getColumnIndexOrThrow(column)
        return if (isNull(index)) null else getString(index)
    }

    private fun Cursor.getNullableLong(column: String): Long? {
        val index = getColumnIndexOrThrow(column)
        return if (isNull(index)) null else getLong(index)
    }

    companion object {
        private const val DB_NAME = "multifetch.db"
        private const val DB_VERSION = 6
    }
}
