package com.multifetch.app.download

enum class DownloadStatus {
    QUEUED,
    DOWNLOADING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class DownloadTask(
    val id: String,
    val url: String,
    val fileName: String?,
    val mimeType: String?,
    val totalBytes: Long,
    val downloadedBytes: Long,
    val segmentCount: Int,
    val priority: Int,
    val requestCookie: String?,
    val requestReferer: String?,
    val requestUserAgent: String?,
    val requestedFileName: String?,
    val outputTreeUri: String?,
    val scheduledAt: Long?,
    val expectedSha256: String?,
    val actualSha256: String?,
    val status: DownloadStatus,
    val message: String,
    val outputUri: String?,
    val createdAt: Long,
    val updatedAt: Long
)
