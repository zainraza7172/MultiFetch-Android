package com.multifetch.app.download

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.provider.DocumentsContract
import com.multifetch.app.network.NetworkRouter
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Alpha 0.6.2 HLS/VOD engine.
 *
 * It intentionally lives beside the normal range downloader so the existing direct-download
 * transport stays untouched. The engine supports standard HTTP HLS VOD playlists, master
 * playlist selection, EXT-X-MAP/fMP4, EXT-X-BYTERANGE, and AES-128 segment encryption.
 * SAMPLE-AES / DRM streams are rejected instead of pretending to download them.
 */
class HlsDownloadEngine(private val context: Context) {

    private data class RequestHeaders(
        val cookie: String?,
        val referer: String?,
        val userAgent: String?
    )

    private data class HlsKey(
        val url: URL,
        val iv: ByteArray?
    )

    private data class Resource(
        val url: URL,
        val rangeStart: Long? = null,
        val rangeEnd: Long? = null,
        val key: HlsKey? = null,
        val sequence: Long = 0L
    )

    private data class MediaPlaylist(
        val playlistUrl: URL,
        val initResource: Resource?,
        val segments: List<Resource>,
        val isFmp4: Boolean,
        val isLiveSnapshot: Boolean
    )

    fun download(
        taskId: String,
        rawUrl: String,
        turboMode: Boolean,
        combineWifiAndCellular: Boolean,
        turboConnections: Int,
        autoOrganizeDownloads: Boolean,
        duplicateSafeFileNames: Boolean,
        requestedFileName: String?,
        outputTreeUri: String?,
        speedLimitBytesPerSecond: Long,
        requestCookie: String?,
        requestReferer: String?,
        requestUserAgent: String?,
        expectedSha256: String?,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean,
        onProbe: (DownloadEngine.ProbeInfo) -> Unit,
        onProgress: (DownloadEngine.Progress) -> Unit
    ): DownloadEngine.Result {
        val startUrl = validateUrl(rawUrl)
        val headers = RequestHeaders(
            cookie = requestCookie?.takeIf { it.isNotBlank() },
            referer = requestReferer?.takeIf { it.isNotBlank() },
            userAgent = requestUserAgent?.takeIf { it.isNotBlank() }
        )
        val limiter = BandwidthLimiter(speedLimitBytesPerSecond)
        val router = NetworkRouter(context)
        val session = router.acquire(combineWifiAndCellular)
        val workDir = File(context.filesDir, "multifetch/$taskId").apply { mkdirs() }

        try {
            onProgress(DownloadEngine.Progress(0L, -1L, "Reading HLS playlist • ${session.label}"))
            val playlist = resolveMediaPlaylist(startUrl, session.routes, headers)
            require(playlist.segments.isNotEmpty()) { "HLS playlist contains no downloadable media segments." }

            val fileName = resolveRequestedFileName(requestedFileName, makeFileName(playlist.playlistUrl, playlist.isFmp4))
            val mimeType = if (playlist.isFmp4) "video/mp4" else "video/mp2t"
            onProbe(
                DownloadEngine.ProbeInfo(
                    totalBytes = -1L,
                    supportsRanges = false,
                    fileName = fileName,
                    mimeType = mimeType,
                    segmentCount = playlist.segments.size,
                    networkLabel = session.label
                )
            )

            val signature = playlistSignature(playlist)
            prepareWorkspace(workDir, signature)

            val keyCache = ConcurrentHashMap<String, ByteArray>()
            val downloadedBytes = AtomicLong(existingDownloadedBytes(workDir, playlist))
            val completedSegments = AtomicInteger(countCompletedSegments(workDir, playlist.segments.size))

            playlist.initResource?.let { init ->
                val initFile = File(workDir, HLS_INIT_FILE)
                if (!initFile.exists() || initFile.length() <= 0L) {
                    onProgress(
                        DownloadEngine.Progress(
                            downloadedBytes.get(),
                            -1L,
                            "Downloading HLS init • ${session.label}"
                        )
                    )
                    downloadResourceWithRetry(
                        resource = init,
                        output = initFile,
                        routes = session.routes,
                        headers = headers,
                        keyCache = keyCache,
                        initialRouteIndex = 0,
                        pauseRequested = pauseRequested,
                        cancelled = cancelled,
                        limiter = limiter,
                        onNetworkBytes = { delta ->
                            val total = downloadedBytes.addAndGet(delta)
                            onProgress(DownloadEngine.Progress(total, -1L, "Downloading HLS init • ${session.label}"))
                        }
                    )
                }
            }

            ensureRunning(pauseRequested, cancelled)
            val pending = ConcurrentLinkedQueue<Int>()
            playlist.segments.indices.forEach { index ->
                val output = segmentFile(workDir, index)
                if (!output.exists() || output.length() <= 0L) pending.add(index)
            }

            if (pending.isNotEmpty()) {
                val workerCount = chooseWorkerCount(pending.size, turboMode, turboConnections)
                val executor = Executors.newFixedThreadPool(workerCount)
                try {
                    val workers = (0 until workerCount).map { workerIndex ->
                        Runnable {
                            while (true) {
                                ensureRunning(pauseRequested, cancelled)
                                val index = pending.poll() ?: break
                                val output = segmentFile(workDir, index)
                                if (output.exists() && output.length() > 0L) continue
                                val resource = playlist.segments[index]
                                downloadResourceWithRetry(
                                    resource = resource,
                                    output = output,
                                    routes = session.routes,
                                    headers = headers,
                                    keyCache = keyCache,
                                    initialRouteIndex = preferredRouteIndex(workerIndex, session.routes),
                                    pauseRequested = pauseRequested,
                                    cancelled = cancelled,
                                    limiter = limiter,
                                    onNetworkBytes = { delta ->
                                        val total = downloadedBytes.addAndGet(delta)
                                        val done = completedSegments.get().coerceAtMost(playlist.segments.size)
                                        onProgress(
                                            DownloadEngine.Progress(
                                                total,
                                                -1L,
                                                hlsProgressLabel(done, playlist.segments.size, session.label, turboMode, playlist.isLiveSnapshot)
                                            )
                                        )
                                    }
                                )
                                val done = completedSegments.incrementAndGet()
                                onProgress(
                                    DownloadEngine.Progress(
                                        downloadedBytes.get(),
                                        -1L,
                                        hlsProgressLabel(done, playlist.segments.size, session.label, turboMode, playlist.isLiveSnapshot)
                                    )
                                )
                            }
                        }
                    }
                    val futures = workers.map(executor::submit)
                    futures.forEach { it.get() }
                } catch (t: Throwable) {
                    val root = unwrap(t)
                    when (root) {
                        is DownloadEngine.DownloadPausedException -> throw root
                        is DownloadEngine.DownloadCancelledException -> throw root
                        else -> throw root
                    }
                } finally {
                    executor.shutdownNow()
                }
            }

            ensureRunning(pauseRequested, cancelled)
            require(countCompletedSegments(workDir, playlist.segments.size) == playlist.segments.size) {
                "HLS download ended before every segment was complete."
            }

            val finalSize = finalOutputSize(workDir, playlist)
            val expectedHash = FileIntegrity.normalizeSha256(expectedSha256)
            val actualHash = if (expectedHash != null) {
                onProgress(DownloadEngine.Progress(finalSize, finalSize, "Verifying SHA-256…"))
                val orderedFiles = buildList {
                    playlist.initResource?.let { add(File(workDir, HLS_INIT_FILE)) }
                    playlist.segments.indices.forEach { index -> add(segmentFile(workDir, index)) }
                }
                val hash = FileIntegrity.sha256(orderedFiles)
                try {
                    FileIntegrity.requireMatch(expectedHash, hash)
                } catch (t: Throwable) {
                    workDir.deleteRecursively()
                    throw t
                }
                hash
            } else null
            onProgress(DownloadEngine.Progress(finalSize, finalSize, "Saving HLS video to Downloads…"))
            val published = publishToDownloads(
                workDir = workDir,
                playlist = playlist,
                fileName = fileName,
                mimeType = mimeType,
                autoOrganizeDownloads = autoOrganizeDownloads,
                duplicateSafeFileNames = duplicateSafeFileNames,
                outputTreeUri = outputTreeUri,
                cancelled = cancelled
            )
            workDir.deleteRecursively()
            onProgress(DownloadEngine.Progress(finalSize, finalSize, "Complete"))
            return DownloadEngine.Result(
                uri = published.first,
                fileName = published.second,
                totalBytes = finalSize,
                usedSegments = playlist.segments.size,
                sha256 = actualHash
            )
        } catch (t: Throwable) {
            if (t is DownloadEngine.DownloadCancelledException) workDir.deleteRecursively()
            throw t
        } finally {
            session.close()
        }
    }

    private fun resolveMediaPlaylist(
        startUrl: URL,
        routes: List<NetworkRouter.Route>,
        headers: RequestHeaders
    ): MediaPlaylist {
        var currentUrl = startUrl
        repeat(MAX_PLAYLIST_DEPTH) {
            val text = fetchText(currentUrl, routes, headers)
            require(text.trimStart().startsWith("#EXTM3U")) { "This link is not a valid HLS playlist." }

            val variants = parseMasterVariants(text, currentUrl)
            if (variants.isNotEmpty()) {
                currentUrl = variants.maxByOrNull { it.first }!!.second
                return@repeat
            }
            return parseMediaPlaylist(text, currentUrl)
        }
        error("HLS master playlist redirects through too many nested playlists.")
    }

    private fun parseMasterVariants(text: String, baseUrl: URL): List<Pair<Long, URL>> {
        val lines = text.lineSequence().map { it.trim() }.toList()
        val variants = mutableListOf<Pair<Long, URL>>()
        var index = 0
        while (index < lines.size) {
            val line = lines[index]
            if (line.startsWith("#EXT-X-STREAM-INF:", true)) {
                val attrs = parseAttributes(line.substringAfter(':'))
                val bandwidth = attrs["BANDWIDTH"]?.toLongOrNull()
                    ?: attrs["AVERAGE-BANDWIDTH"]?.toLongOrNull()
                    ?: 0L
                var next = index + 1
                while (next < lines.size && (lines[next].isBlank() || lines[next].startsWith('#'))) next++
                if (next < lines.size) {
                    variants += bandwidth to resolveUrl(baseUrl, lines[next])
                    index = next
                }
            }
            index++
        }
        return variants
    }

    private fun parseMediaPlaylist(text: String, playlistUrl: URL): MediaPlaylist {
        val lines = text.lineSequence().map { it.trim() }.toList()
        var mediaSequence = 0L
        var currentSequence = 0L
        var currentKey: HlsKey? = null
        var initResource: Resource? = null
        var pendingRange: Pair<Long, Long?>? = null
        var previousRangeEnd = -1L
        var previousRangeUrl: String? = null
        val segments = mutableListOf<Resource>()
        val hasEndList = lines.any { it.equals("#EXT-X-ENDLIST", true) }

        lines.forEach { line ->
            when {
                line.startsWith("#EXT-X-MEDIA-SEQUENCE:", true) -> {
                    mediaSequence = line.substringAfter(':').trim().toLongOrNull() ?: 0L
                    currentSequence = mediaSequence
                }

                line.startsWith("#EXT-X-KEY:", true) -> {
                    val attrs = parseAttributes(line.substringAfter(':'))
                    when (attrs["METHOD"]?.uppercase()) {
                        null, "NONE" -> currentKey = null
                        "AES-128" -> {
                            val keyUri = attrs["URI"]?.trim('"')
                                ?: error("AES-128 HLS key is missing its URI.")
                            currentKey = HlsKey(
                                url = resolveUrl(playlistUrl, keyUri),
                                iv = attrs["IV"]?.let(::parseIv)
                            )
                        }
                        else -> error("This HLS stream uses DRM/SAMPLE-AES, which MultiFetch does not bypass.")
                    }
                }

                line.startsWith("#EXT-X-MAP:", true) -> {
                    val attrs = parseAttributes(line.substringAfter(':'))
                    val uri = attrs["URI"]?.trim('"') ?: error("HLS init segment URI is missing.")
                    val mapRange = attrs["BYTERANGE"]?.trim('"')?.let(::parseByteRange)
                    val resolved = resolveUrl(playlistUrl, uri)
                    val range = mapRange?.let { rangeFrom(it.first, it.second, -1L) }
                    initResource = Resource(
                        url = resolved,
                        rangeStart = range?.first,
                        rangeEnd = range?.second,
                        key = currentKey,
                        sequence = currentSequence
                    )
                }

                line.startsWith("#EXT-X-BYTERANGE:", true) -> {
                    pendingRange = parseByteRange(line.substringAfter(':').trim())
                }

                line.isNotBlank() && !line.startsWith('#') -> {
                    val resolved = resolveUrl(playlistUrl, line)
                    val pending = pendingRange
                    val range = if (pending != null) {
                        val implicitBase = if (previousRangeUrl == resolved.toString()) previousRangeEnd else -1L
                        rangeFrom(pending.first, pending.second, implicitBase)
                    } else null
                    segments += Resource(
                        url = resolved,
                        rangeStart = range?.first,
                        rangeEnd = range?.second,
                        key = currentKey,
                        sequence = currentSequence
                    )
                    if (range != null) {
                        previousRangeEnd = range.second
                        previousRangeUrl = resolved.toString()
                    } else {
                        previousRangeEnd = -1L
                        previousRangeUrl = null
                    }
                    pendingRange = null
                    currentSequence++
                }
            }
        }

        if (segments.isEmpty()) error("HLS playlist has no media segments.")
        val isFmp4 = initResource != null || segments.any {
            val path = it.url.path.lowercase()
            path.endsWith(".m4s") || path.endsWith(".mp4") || path.endsWith(".cmfv") || path.endsWith(".cmfa")
        }
        return MediaPlaylist(
            playlistUrl = playlistUrl,
            initResource = initResource,
            segments = segments,
            isFmp4 = isFmp4,
            isLiveSnapshot = !hasEndList
        )
    }

    private fun parseAttributes(raw: String): Map<String, String> {
        val result = linkedMapOf<String, String>()
        val regex = Regex("([A-Za-z0-9-]+)=(\\\"[^\\\"]*\\\"|[^,]*)")
        regex.findAll(raw).forEach { match ->
            result[match.groupValues[1].uppercase()] = match.groupValues[2]
        }
        return result
    }

    private fun parseByteRange(raw: String): Pair<Long, Long?> {
        val clean = raw.trim().trim('"')
        val length = clean.substringBefore('@').toLongOrNull()
            ?: error("Invalid HLS byte range length.")
        val offset = clean.substringAfter('@', "").takeIf { it.isNotBlank() }?.toLongOrNull()
        return length to offset
    }

    private fun rangeFrom(length: Long, explicitOffset: Long?, previousEnd: Long): Pair<Long, Long> {
        require(length > 0L) { "Invalid HLS byte range." }
        val start = explicitOffset ?: (previousEnd + 1L).coerceAtLeast(0L)
        return start to (start + length - 1L)
    }

    private fun parseIv(raw: String): ByteArray {
        val clean = raw.trim().removePrefix("0x").removePrefix("0X").padStart(32, '0').takeLast(32)
        require(clean.length == 32 && clean.all { it in "0123456789abcdefABCDEF" }) { "Invalid HLS AES-128 IV." }
        return ByteArray(16) { index -> clean.substring(index * 2, index * 2 + 2).toInt(16).toByte() }
    }

    private fun fetchText(
        url: URL,
        routes: List<NetworkRouter.Route>,
        headers: RequestHeaders
    ): String {
        var lastError: Throwable? = null
        routes.forEach { route ->
            try {
                val connection = open(url, route, headers)
                try {
                    val code = connection.responseCode
                    if (code !in 200..299) error("HLS server returned HTTP $code")
                    if (connection.contentLengthLong > MAX_PLAYLIST_BYTES) error("HLS playlist is unexpectedly large.")
                    return connection.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                        val builder = StringBuilder()
                        val buffer = CharArray(16 * 1024)
                        while (true) {
                            val count = reader.read(buffer)
                            if (count < 0) break
                            builder.append(buffer, 0, count)
                            if (builder.length > MAX_PLAYLIST_BYTES) error("HLS playlist is unexpectedly large.")
                        }
                        builder.toString()
                    }
                } finally {
                    connection.disconnect()
                }
            } catch (t: Throwable) {
                lastError = t
            }
        }
        throw IllegalStateException("Could not read the HLS playlist.", lastError)
    }

    private fun downloadResourceWithRetry(
        resource: Resource,
        output: File,
        routes: List<NetworkRouter.Route>,
        headers: RequestHeaders,
        keyCache: ConcurrentHashMap<String, ByteArray>,
        initialRouteIndex: Int,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean,
        limiter: BandwidthLimiter,
        onNetworkBytes: (Long) -> Unit
    ) {
        if (output.exists() && output.length() > 0L) return
        var lastError: Throwable? = null
        repeat(MAX_RESOURCE_RETRIES) { attempt ->
            ensureRunning(pauseRequested, cancelled)
            val route = routes[(initialRouteIndex + attempt) % routes.size]
            try {
                downloadResource(
                    resource,
                    output,
                    route,
                    headers,
                    keyCache,
                    pauseRequested,
                    cancelled,
                    limiter,
                    onNetworkBytes
                )
                return
            } catch (t: Throwable) {
                if (t is DownloadEngine.DownloadPausedException || t is DownloadEngine.DownloadCancelledException) throw t
                lastError = t
                if (attempt + 1 < MAX_RESOURCE_RETRIES) Thread.sleep(350L * (attempt + 1))
            }
        }
        throw IllegalStateException("HLS segment failed after retries: ${resource.url.host}", lastError)
    }

    private fun downloadResource(
        resource: Resource,
        output: File,
        route: NetworkRouter.Route,
        headers: RequestHeaders,
        keyCache: ConcurrentHashMap<String, ByteArray>,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean,
        limiter: BandwidthLimiter,
        onNetworkBytes: (Long) -> Unit
    ) {
        output.parentFile?.mkdirs()
        val networkTmp = File(output.parentFile, output.name + ".network")
        val decodedTmp = File(output.parentFile, output.name + ".decoded")
        networkTmp.delete()
        decodedTmp.delete()

        val connection = open(resource.url, route, headers).apply {
            if (resource.rangeStart != null && resource.rangeEnd != null) {
                setRequestProperty("Range", "bytes=${resource.rangeStart}-${resource.rangeEnd}")
            }
        }
        try {
            val code = connection.responseCode
            if (code !in 200..299) error("HTTP $code")
            if (resource.rangeStart != null && resource.rangeEnd != null && code != HttpURLConnection.HTTP_PARTIAL) {
                error("HLS server ignored a required byte range.")
            }

            BufferedInputStream(connection.inputStream, BUFFER_SIZE).use { input ->
                BufferedOutputStream(FileOutputStream(networkTmp), BUFFER_SIZE).use { out ->
                    val buffer = ByteArray(BUFFER_SIZE)
                    var pending = 0L
                    var lastReport = System.nanoTime()
                    while (true) {
                        ensureRunning(pauseRequested, cancelled)
                        val read = input.read(buffer)
                        if (read < 0) break
                        limiter.throttle(read)
                        out.write(buffer, 0, read)
                        pending += read.toLong()
                        val now = System.nanoTime()
                        if (pending >= PROGRESS_BATCH_BYTES || now - lastReport >= PROGRESS_BATCH_NANOS) {
                            onNetworkBytes(pending)
                            pending = 0L
                            lastReport = now
                        }
                    }
                    if (pending > 0L) onNetworkBytes(pending)
                }
            }

            ensureRunning(pauseRequested, cancelled)
            val key = resource.key
            val completedFile = if (key != null) {
                val keyBytes = getKeyBytes(key.url, route, headers, keyCache)
                require(keyBytes.size == 16) { "HLS AES-128 key must be 16 bytes." }
                val iv = key.iv ?: sequenceIv(resource.sequence)
                val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
                cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(keyBytes, "AES"), IvParameterSpec(iv))
                CipherInputStream(BufferedInputStream(networkTmp.inputStream(), BUFFER_SIZE), cipher).use { input ->
                    BufferedOutputStream(FileOutputStream(decodedTmp), BUFFER_SIZE).use { out ->
                        input.copyTo(out, BUFFER_SIZE)
                    }
                }
                networkTmp.delete()
                decodedTmp
            } else {
                networkTmp
            }

            if (output.exists()) output.delete()
            if (!completedFile.renameTo(output)) {
                completedFile.inputStream().use { input ->
                    output.outputStream().use { out -> input.copyTo(out, BUFFER_SIZE) }
                }
                completedFile.delete()
            }
            require(output.exists() && output.length() > 0L) { "HLS segment produced no data." }
        } finally {
            connection.disconnect()
            if (!output.exists()) {
                networkTmp.delete()
                decodedTmp.delete()
            }
        }
    }

    private fun getKeyBytes(
        url: URL,
        preferredRoute: NetworkRouter.Route,
        headers: RequestHeaders,
        cache: ConcurrentHashMap<String, ByteArray>
    ): ByteArray {
        cache[url.toString()]?.let { return it }
        val connection = open(url, preferredRoute, headers)
        try {
            val code = connection.responseCode
            if (code !in 200..299) error("HLS key server returned HTTP $code")
            val bytes = connection.inputStream.use { it.readBytes() }
            require(bytes.size == 16) { "Invalid HLS AES-128 key length." }
            cache.putIfAbsent(url.toString(), bytes)
            return cache[url.toString()] ?: bytes
        } finally {
            connection.disconnect()
        }
    }

    private fun sequenceIv(sequence: Long): ByteArray {
        val iv = ByteArray(16)
        var value = sequence
        for (index in 15 downTo 0) {
            iv[index] = (value and 0xFFL).toByte()
            value = value ushr 8
        }
        return iv
    }

    private fun prepareWorkspace(workDir: File, signature: String) {
        val signatureFile = File(workDir, HLS_SIGNATURE_FILE)
        val existing = signatureFile.takeIf { it.exists() }?.readText()?.trim()
        if (existing != signature) {
            workDir.listFiles()?.forEach { file ->
                if (file.name.startsWith("hls_")) file.deleteRecursively()
            }
            signatureFile.writeText(signature)
        }
    }

    private fun playlistSignature(playlist: MediaPlaylist): String {
        val input = buildString {
            append(playlist.playlistUrl).append('\n')
            playlist.initResource?.let { append("INIT|").append(resourceSignature(it)).append('\n') }
            playlist.segments.forEach { append(resourceSignature(it)).append('\n') }
        }
        val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it.toInt() and 0xFF) }
    }

    private fun resourceSignature(resource: Resource): String = buildString {
        append(resource.url)
        append('|').append(resource.rangeStart ?: -1L)
        append('|').append(resource.rangeEnd ?: -1L)
        append('|').append(resource.key?.url ?: "")
        append('|').append(resource.sequence)
    }

    private fun existingDownloadedBytes(workDir: File, playlist: MediaPlaylist): Long {
        var total = 0L
        playlist.initResource?.let {
            val init = File(workDir, HLS_INIT_FILE)
            if (init.exists()) total += init.length()
        }
        playlist.segments.indices.forEach { index ->
            val file = segmentFile(workDir, index)
            if (file.exists()) total += file.length()
        }
        return total
    }

    private fun countCompletedSegments(workDir: File, count: Int): Int =
        (0 until count).count { index ->
            val file = segmentFile(workDir, index)
            file.exists() && file.length() > 0L
        }

    private fun finalOutputSize(workDir: File, playlist: MediaPlaylist): Long {
        var total = playlist.initResource?.let { File(workDir, HLS_INIT_FILE).length() } ?: 0L
        playlist.segments.indices.forEach { total += segmentFile(workDir, it).length() }
        return total
    }

    private fun segmentFile(workDir: File, index: Int): File =
        File(workDir, "hls_segment_${index.toString().padStart(6, '0')}.part")

    private fun resolveRequestedFileName(requested: String?, fallback: String): String {
        val raw = requested?.trim()?.takeIf { it.isNotBlank() } ?: return fallback
        val safe = raw.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(180).trim().ifBlank { return fallback }
        val fallbackDot = fallback.lastIndexOf('.')
        val fallbackExt = if (fallbackDot > 0 && fallbackDot < fallback.length - 1) fallback.substring(fallbackDot) else ""
        val requestedHasExt = safe.lastIndexOf('.').let { it > 0 && it < safe.length - 1 }
        return if (!requestedHasExt && fallbackExt.isNotBlank()) "$safe$fallbackExt" else safe
    }

    private fun customFolderNames(treeUri: Uri): Set<String> {
        val resolver = context.contentResolver
        val treeId = DocumentsContract.getTreeDocumentId(treeUri)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, treeId)
        val names = linkedSetOf<String>()
        resolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { cursor ->
            val index = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            while (cursor.moveToNext()) if (index >= 0) names += cursor.getString(index)
        }
        return names
    }

    private fun uniqueCustomName(treeUri: Uri, originalName: String): String {
        val existing = runCatching { customFolderNames(treeUri) }.getOrDefault(emptySet())
        if (originalName !in existing) return originalName
        val dot = originalName.lastIndexOf('.')
        val hasExtension = dot > 0 && dot < originalName.length - 1
        val base = if (hasExtension) originalName.substring(0, dot) else originalName
        val extension = if (hasExtension) originalName.substring(dot) else ""
        for (index in 1..9999) {
            val candidate = "$base ($index)$extension"
            if (candidate !in existing) return candidate
        }
        return "$base (${System.currentTimeMillis()})$extension"
    }

    private fun publishToCustomFolder(
        workDir: File,
        playlist: MediaPlaylist,
        fileName: String,
        mimeType: String,
        duplicateSafeFileNames: Boolean,
        outputTreeUri: String,
        cancelled: AtomicBoolean
    ): Pair<Uri, String> {
        val resolver = context.contentResolver
        val treeUri = Uri.parse(outputTreeUri)
        val treeId = DocumentsContract.getTreeDocumentId(treeUri)
        val parentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, treeId)
        val finalFileName = if (duplicateSafeFileNames) uniqueCustomName(treeUri, fileName) else fileName
        val uri = DocumentsContract.createDocument(resolver, parentUri, mimeType.ifBlank { "application/octet-stream" }, finalFileName)
            ?: error("Android could not create the HLS file in the selected folder.")
        try {
            resolver.openOutputStream(uri, "w")?.use { rawOut ->
                BufferedOutputStream(rawOut, BUFFER_SIZE).use { out ->
                    playlist.initResource?.let {
                        if (cancelled.get()) throw DownloadEngine.DownloadCancelledException()
                        val init = File(workDir, HLS_INIT_FILE)
                        require(init.exists()) { "Missing HLS init segment." }
                        init.inputStream().buffered(BUFFER_SIZE).use { input -> input.copyTo(out, BUFFER_SIZE) }
                    }
                    playlist.segments.indices.forEach { index ->
                        if (cancelled.get()) throw DownloadEngine.DownloadCancelledException()
                        val segment = segmentFile(workDir, index)
                        require(segment.exists()) { "Missing HLS segment $index" }
                        segment.inputStream().buffered(BUFFER_SIZE).use { input -> input.copyTo(out, BUFFER_SIZE) }
                    }
                }
            } ?: error("Unable to open the selected HLS output folder.")
            return uri to finalFileName
        } catch (t: Throwable) {
            runCatching { DocumentsContract.deleteDocument(resolver, uri) }
            throw t
        }
    }

    private fun publishToDownloads(
        workDir: File,
        playlist: MediaPlaylist,
        fileName: String,
        mimeType: String,
        autoOrganizeDownloads: Boolean,
        duplicateSafeFileNames: Boolean,
        outputTreeUri: String?,
        cancelled: AtomicBoolean
    ): Pair<Uri, String> {
        if (!outputTreeUri.isNullOrBlank()) {
            return publishToCustomFolder(workDir, playlist, fileName, mimeType, duplicateSafeFileNames, outputTreeUri, cancelled)
        }
        val resolver = context.contentResolver
        val basePath = Environment.DIRECTORY_DOWNLOADS + "/MultiFetch"
        val relativePath = if (autoOrganizeDownloads) "$basePath/Video" else basePath
        val finalFileName = if (duplicateSafeFileNames) uniqueDisplayName(fileName, relativePath) else fileName
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, finalFileName)
            put(MediaStore.Downloads.MIME_TYPE, mimeType)
            put(MediaStore.Downloads.RELATIVE_PATH, relativePath)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Android could not create the HLS output file.")
        try {
            resolver.openOutputStream(uri, "w")?.use { rawOut ->
                BufferedOutputStream(rawOut, BUFFER_SIZE).use { out ->
                    playlist.initResource?.let {
                        ensureRunning(AtomicBoolean(false), cancelled)
                        val init = File(workDir, HLS_INIT_FILE)
                        require(init.exists()) { "Missing HLS init segment." }
                        init.inputStream().buffered(BUFFER_SIZE).use { input -> input.copyTo(out, BUFFER_SIZE) }
                    }
                    playlist.segments.indices.forEach { index ->
                        if (cancelled.get()) throw DownloadEngine.DownloadCancelledException()
                        val segment = segmentFile(workDir, index)
                        require(segment.exists()) { "Missing HLS segment $index" }
                        segment.inputStream().buffered(BUFFER_SIZE).use { input -> input.copyTo(out, BUFFER_SIZE) }
                    }
                }
            } ?: error("Unable to open HLS output stream.")
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return uri to finalFileName
        } catch (t: Throwable) {
            resolver.delete(uri, null, null)
            throw t
        }
    }

    private fun uniqueDisplayName(originalName: String, relativePath: String): String {
        val resolver = context.contentResolver
        val dot = originalName.lastIndexOf('.')
        val hasExtension = dot > 0 && dot < originalName.length - 1
        val base = if (hasExtension) originalName.substring(0, dot) else originalName
        val extension = if (hasExtension) originalName.substring(dot) else ""

        fun exists(candidate: String): Boolean {
            val selection = "${MediaStore.Downloads.DISPLAY_NAME} = ? AND ${MediaStore.Downloads.RELATIVE_PATH} LIKE ?"
            val pathArg = relativePath.trimEnd('/') + "/%"
            return runCatching {
                resolver.query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    arrayOf(MediaStore.Downloads._ID),
                    selection,
                    arrayOf(candidate, pathArg),
                    null
                )?.use { it.moveToFirst() } ?: false
            }.getOrDefault(false)
        }

        if (!exists(originalName)) return originalName
        for (index in 1..9999) {
            val candidate = "$base ($index)$extension"
            if (!exists(candidate)) return candidate
        }
        return "$base (${System.currentTimeMillis()})$extension"
    }

    private fun makeFileName(url: URL, fmp4: Boolean): String {
        val raw = url.path.substringAfterLast('/').substringBefore('?').ifBlank { "stream.m3u8" }
        val base = raw.substringBeforeLast('.', raw).ifBlank { "stream_${System.currentTimeMillis()}" }
        val safe = base.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(150).ifBlank { "stream" }
        return "$safe.${if (fmp4) "mp4" else "ts"}"
    }

    private fun hlsProgressLabel(
        completed: Int,
        total: Int,
        networkLabel: String,
        turboMode: Boolean,
        liveSnapshot: Boolean
    ): String = buildString {
        append("Downloading HLS • ").append(completed.coerceIn(0, total)).append('/').append(total)
        append(" • ").append(networkLabel)
        if (turboMode) append(" • Turbo")
        if (liveSnapshot) append(" • live snapshot")
    }

    private fun chooseWorkerCount(pendingCount: Int, turboMode: Boolean, turboConnections: Int): Int {
        val target = if (turboMode) turboConnections.coerceIn(8, 16) else 4
        return target.coerceAtMost(pendingCount).coerceAtLeast(1)
    }

    private fun preferredRouteIndex(workerIndex: Int, routes: List<NetworkRouter.Route>): Int {
        if (routes.size <= 1) return 0
        val wifi = routes.indexOfFirst { it.label == "Wi‑Fi" }
        val mobile = routes.indexOfFirst { it.label == "Mobile" }
        if (wifi >= 0 && mobile >= 0) return if (workerIndex % 4 == 3) mobile else wifi
        return workerIndex % routes.size
    }

    private fun fetchUrlBytes(
        url: URL,
        route: NetworkRouter.Route,
        headers: RequestHeaders
    ): ByteArray {
        val connection = open(url, route, headers)
        try {
            val code = connection.responseCode
            if (code !in 200..299) error("HTTP $code")
            return connection.inputStream.use { it.readBytes() }
        } finally {
            connection.disconnect()
        }
    }

    private fun open(url: URL, route: NetworkRouter.Route, headers: RequestHeaders): HttpURLConnection =
        route.open(url).apply {
            connectTimeout = 15_000
            readTimeout = 30_000
            instanceFollowRedirects = true
            useCaches = false
            setRequestProperty("Accept-Encoding", "identity")
            setRequestProperty("Connection", "keep-alive")
            setRequestProperty("Accept", "*/*")
            setRequestProperty("User-Agent", headers.userAgent ?: "MultiFetch/0.6.3 Android Download Manager")
            headers.referer?.let { setRequestProperty("Referer", it) }
            headers.cookie?.let { setRequestProperty("Cookie", it) }
        }

    private fun resolveUrl(base: URL, ref: String): URL = URL(base, ref.trim())

    private fun validateUrl(raw: String): URL {
        val trimmed = raw.trim()
        require(trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true)) {
            "Only http:// and https:// HLS links are supported."
        }
        return URL(trimmed)
    }

    private fun ensureRunning(pauseRequested: AtomicBoolean, cancelled: AtomicBoolean) {
        if (cancelled.get()) throw DownloadEngine.DownloadCancelledException()
        if (pauseRequested.get()) throw DownloadEngine.DownloadPausedException()
        if (Thread.currentThread().isInterrupted) {
            if (cancelled.get()) throw DownloadEngine.DownloadCancelledException()
            if (pauseRequested.get()) throw DownloadEngine.DownloadPausedException()
        }
    }

    private fun unwrap(t: Throwable): Throwable {
        var current = t
        while (current.cause != null && current !is DownloadEngine.DownloadPausedException && current !is DownloadEngine.DownloadCancelledException) {
            current = current.cause!!
        }
        return current
    }

    companion object {
        fun looksLikeHlsUrl(rawUrl: String): Boolean {
            val value = rawUrl.trim().lowercase()
            if (!value.startsWith("http://") && !value.startsWith("https://")) return false
            return runCatching { URL(value).path.lowercase().endsWith(".m3u8") }.getOrDefault(false) ||
                value.contains(".m3u8?") || value.contains("format=m3u8") || value.contains("type=m3u8")
        }

        private const val BUFFER_SIZE = 256 * 1024
        private const val PROGRESS_BATCH_BYTES = 256 * 1024L
        private const val PROGRESS_BATCH_NANOS = 250_000_000L
        private const val MAX_PLAYLIST_DEPTH = 5
        private const val MAX_PLAYLIST_BYTES = 8 * 1024 * 1024
        private const val MAX_RESOURCE_RETRIES = 4
        private const val HLS_INIT_FILE = "hls_init.part"
        private const val HLS_SIGNATURE_FILE = "hls_playlist.sha256"
    }
}
