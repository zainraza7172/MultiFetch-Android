package com.multifetch.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.multifetch.app.download.DownloadStore

/**
 * Restores durable queue state after a device reboot or app package replacement.
 * It does not do network I/O inside the broadcast receiver; it only repairs state
 * and re-arms AlarmManager so Android can hand work back to DownloadService.
 */
class RestartRecoveryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return

        val appContext = context.applicationContext
        val store = DownloadStore(appContext)
        try {
            // A process can disappear without DownloadService.onDestroy(), so never
            // leave durable rows stuck in DOWNLOADING after a reboot/update.
            store.recoverInterrupted()

            // Future user schedules must be recreated because AlarmManager alarms
            // do not survive a reboot. Package replacement can also invalidate them.
            DownloadScheduleManager.scheduleNext(appContext, store.nextScheduledAt())

            if (SettingsStore(appContext).autoResumeAfterRestart && store.nextRunnable() != null) {
                // Avoid starting a data-sync foreground service directly from the
                // BOOT_COMPLETED callback. Re-enter through the app's existing alarm
                // receiver; Android/OEM battery policies may defer this wake-up.
                DownloadScheduleManager.scheduleRecovery(appContext)
            } else {
                DownloadScheduleManager.cancelRecovery(appContext)
            }
        } finally {
            store.close()
        }
    }
}
