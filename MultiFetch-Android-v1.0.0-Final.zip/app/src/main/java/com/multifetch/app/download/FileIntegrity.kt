package com.multifetch.app.download

import java.io.File
import java.security.MessageDigest
import java.util.Locale

object FileIntegrity {
    private val SHA256_REGEX = Regex("^[0-9a-fA-F]{64}$")

    fun normalizeSha256(value: String?): String? {
        val cleaned = value
            ?.trim()
            ?.replace(Regex("""^(?i:sha-?256)\s*:\s*"""), "")
            ?.replace(" ", "")
            ?.takeIf { it.isNotBlank() }
            ?: return null
        return cleaned.takeIf { SHA256_REGEX.matches(it) }?.lowercase(Locale.US)
    }

    fun isValidOrBlank(value: String): Boolean = value.isBlank() || normalizeSha256(value) != null

    fun sha256(filesInOrder: List<File>): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(1024 * 1024)
        filesInOrder.forEach { file ->
            require(file.isFile) { "Missing file while calculating SHA-256: ${file.name}" }
            file.inputStream().buffered(buffer.size).use { input ->
                while (true) {
                    val read = input.read(buffer)
                    if (read <= 0) break
                    digest.update(buffer, 0, read)
                }
            }
        }
        return digest.digest().joinToString("") { byte -> "%02x".format(byte.toInt() and 0xFF) }
    }

    fun requireMatch(expected: String?, actual: String) {
        val normalized = normalizeSha256(expected) ?: return
        require(normalized.equals(actual, ignoreCase = true)) {
            "SHA-256 mismatch. Expected ${shortHash(normalized)}, got ${shortHash(actual)}. Download was not published."
        }
    }

    private fun shortHash(value: String): String =
        if (value.length <= 20) value else value.take(10) + "…" + value.takeLast(10)
}
