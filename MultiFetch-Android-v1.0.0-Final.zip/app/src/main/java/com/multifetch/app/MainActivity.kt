package com.multifetch.app

import android.Manifest
import android.app.AlertDialog as PlatformAlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Message
import android.provider.OpenableColumns
import android.view.View
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.WebChromeClient
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.ValueCallback
import android.widget.EditText
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.multifetch.app.download.DownloadEngine
import com.multifetch.app.download.FileIntegrity
import com.multifetch.app.download.DownloadStatus
import com.multifetch.app.download.DownloadStore
import com.multifetch.app.download.DownloadTask
import com.multifetch.app.download.TorrentDownloadEngine
import java.io.File
import java.text.DateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

private var AppDarkModeState by mutableStateOf(false)

private val AppBlue: Color get() = if (AppDarkModeState) Color(0xFF5EA0FF) else Color(0xFF1677FF)
private val DeepNavy: Color get() = if (AppDarkModeState) Color(0xFFF4F7FF) else Color(0xFF101A3A)
private val SoftBlue: Color get() = if (AppDarkModeState) Color(0xFF17243D) else Color(0xFFEAF4FF)
private val AppBackground: Color get() = if (AppDarkModeState) Color(0xFF090E18) else Color(0xFFF5F7FB)
private val AppSurface: Color get() = if (AppDarkModeState) Color(0xFF111927) else Color.White
private val Muted: Color get() = if (AppDarkModeState) Color(0xFFA7B2C8) else Color(0xFF6E7890)
private val Border: Color get() = if (AppDarkModeState) Color(0xFF263247) else Color(0xFFE5EAF2)
private val Success: Color get() = if (AppDarkModeState) Color(0xFF57D77A) else Color(0xFF31C453)

class MainActivity : ComponentActivity() {

    private lateinit var store: DownloadStore
    private lateinit var settings: SettingsStore

    private var tasks by mutableStateOf<List<DownloadTask>>(emptyList())
    private var initialUrl by mutableStateOf("")
    private var inputMessage by mutableStateOf("")
    private var turboMode by mutableStateOf(true)
    private var combineNetworks by mutableStateOf(false)
    private var turboConnections by mutableStateOf(12)
    private var autoRetryFailedDownloads by mutableStateOf(true)
    private var autoResumeAfterRestart by mutableStateOf(true)
    private var wifiOnlyDownloads by mutableStateOf(false)
    private var autoOrganizeDownloads by mutableStateOf(true)
    private var duplicateSafeFileNames by mutableStateOf(true)
    private var speedLimitBytesPerSecond by mutableStateOf(0L)
    private var maxConcurrentDownloads by mutableStateOf(2)
    private var darkMode by mutableStateOf(false)
    private var themeTransitionTargetDark by mutableStateOf<Boolean?>(null)
    private var themeTransitionToken by mutableStateOf(0)

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    private val torrentPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) queueTorrentUri(uri)
    }

    private val queueReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == DownloadService.ACTION_QUEUE_CHANGED) refreshTasks()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = DownloadStore(applicationContext)
        settings = SettingsStore(applicationContext)
        turboMode = settings.turboMode
        combineNetworks = settings.combineWifiAndCellular
        turboConnections = settings.turboConnections
        autoRetryFailedDownloads = settings.autoRetryFailedDownloads
        autoResumeAfterRestart = settings.autoResumeAfterRestart
        wifiOnlyDownloads = settings.wifiOnlyDownloads
        autoOrganizeDownloads = settings.autoOrganizeDownloads
        duplicateSafeFileNames = settings.duplicateSafeFileNames
        speedLimitBytesPerSecond = settings.speedLimitBytesPerSecond
        maxConcurrentDownloads = settings.maxConcurrentDownloads
        darkMode = settings.darkMode
        AppDarkModeState = darkMode
        applySystemBars(darkMode)
        handleIncomingIntent(intent)
        requestNotificationPermissionIfNeeded()
        refreshTasks()
        recoverQueue()

        setContent {
            MaterialTheme(
                colorScheme = if (darkMode) {
                    darkColorScheme(
                        primary = AppBlue,
                        onPrimary = Color.White,
                        background = AppBackground,
                        surface = AppSurface,
                        onSurface = DeepNavy,
                        secondary = AppBlue,
                        outline = Border
                    )
                } else {
                    lightColorScheme(
                        primary = AppBlue,
                        onPrimary = Color.White,
                        background = AppBackground,
                        surface = AppSurface,
                        onSurface = DeepNavy,
                        secondary = AppBlue,
                        outline = Border
                    )
                }
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    MultiFetchApp(
                    tasks = tasks,
                    initialUrl = initialUrl,
                    inputMessage = inputMessage,
                    turboMode = turboMode,
                    combineNetworks = combineNetworks,
                    turboConnections = turboConnections,
                    autoRetryFailedDownloads = autoRetryFailedDownloads,
                    autoResumeAfterRestart = autoResumeAfterRestart,
                    wifiOnlyDownloads = wifiOnlyDownloads,
                    autoOrganizeDownloads = autoOrganizeDownloads,
                    duplicateSafeFileNames = duplicateSafeFileNames,
                    speedLimitBytesPerSecond = speedLimitBytesPerSecond,
                    maxConcurrentDownloads = maxConcurrentDownloads,
                    darkMode = darkMode,
                    onTurboModeChange = { enabled ->
                        turboMode = enabled
                        settings.turboMode = enabled
                    },
                    onCombineNetworksChange = { enabled ->
                        combineNetworks = enabled
                        settings.combineWifiAndCellular = enabled
                        if (enabled && wifiOnlyDownloads) {
                            wifiOnlyDownloads = false
                            settings.wifiOnlyDownloads = false
                        }
                    },
                    onTurboConnectionsChange = { count ->
                        turboConnections = count
                        settings.turboConnections = count
                    },
                    onAutoRetryChange = { enabled ->
                        autoRetryFailedDownloads = enabled
                        settings.autoRetryFailedDownloads = enabled
                    },
                    onAutoResumeAfterRestartChange = { enabled ->
                        autoResumeAfterRestart = enabled
                        settings.autoResumeAfterRestart = enabled
                        if (!enabled) DownloadScheduleManager.cancelRecovery(applicationContext)
                    },
                    onWifiOnlyChange = { enabled ->
                        wifiOnlyDownloads = enabled
                        settings.wifiOnlyDownloads = enabled
                        if (enabled && combineNetworks) {
                            combineNetworks = false
                            settings.combineWifiAndCellular = false
                        }
                    },
                    onAutoOrganizeChange = { enabled ->
                        autoOrganizeDownloads = enabled
                        settings.autoOrganizeDownloads = enabled
                    },
                    onDuplicateSafeNamesChange = { enabled ->
                        duplicateSafeFileNames = enabled
                        settings.duplicateSafeFileNames = enabled
                    },
                    onSpeedLimitChange = { bytesPerSecond ->
                        speedLimitBytesPerSecond = bytesPerSecond.coerceAtLeast(0L)
                        settings.speedLimitBytesPerSecond = speedLimitBytesPerSecond
                    },
                    onMaxConcurrentDownloadsChange = { count ->
                        maxConcurrentDownloads = count.coerceIn(1, 3)
                        settings.maxConcurrentDownloads = maxConcurrentDownloads
                        val serviceIntent = Intent(this, DownloadService::class.java).apply {
                            action = DownloadService.ACTION_ENQUEUE
                        }
                        if (tasks.any { it.status == DownloadStatus.QUEUED || it.status == DownloadStatus.DOWNLOADING }) {
                            ContextCompat.startForegroundService(this, serviceIntent)
                        }
                    },
                    onDarkModeChange = { enabled ->
                        if (enabled != darkMode && themeTransitionTargetDark != enabled) {
                            themeTransitionTargetDark = enabled
                            themeTransitionToken += 1
                        }
                    },
                    onQueue = { text, browserRequest, options -> queueDownload(text, browserRequest, options) },
                    onPause = { control(DownloadService.ACTION_PAUSE, it) },
                    onResume = { control(DownloadService.ACTION_RESUME, it) },
                    onCancel = { control(DownloadService.ACTION_CANCEL, it) },
                    onRetry = { control(DownloadService.ACTION_RETRY, it) },
                    onOpen = ::openCompletedFile,
                    onShare = ::shareCompletedFile,
                    onDelete = ::deleteTask,
                    onSetPriority = ::setTaskPriority,
                    onClearCompleted = ::clearCompleted,
                    onPickTorrent = { torrentPicker.launch(arrayOf("application/x-bittorrent", "application/octet-stream")) },
                    onMagnet = { showMagnetDialog() },
                    onPauseAll = ::pauseAll,
                    onResumeAll = ::resumeAll
                    )
                    themeTransitionTargetDark?.let { targetDark ->
                        ThemeTransitionOverlay(
                            targetDark = targetDark,
                            token = themeTransitionToken,
                            onMidpoint = {
                                if (darkMode != targetDark) {
                                    darkMode = targetDark
                                    settings.darkMode = targetDark
                                    AppDarkModeState = targetDark
                                    applySystemBars(targetDark)
                                }
                            },
                            onFinished = {
                                if (themeTransitionTargetDark == targetDark) {
                                    themeTransitionTargetDark = null
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(
            this,
            queueReceiver,
            IntentFilter(DownloadService.ACTION_QUEUE_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        refreshTasks()
    }

    override fun onStop() {
        runCatching { unregisterReceiver(queueReceiver) }
        super.onStop()
    }

    override fun onDestroy() {
        store.close()
        super.onDestroy()
    }

    private fun applySystemBars(dark: Boolean) {
        window.statusBarColor = if (dark) 0xFF090E18.toInt() else 0xFFF5F7FB.toInt()
        window.navigationBarColor = if (dark) 0xFF090E18.toInt() else 0xFFF5F7FB.toInt()
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = !dark
            isAppearanceLightNavigationBars = !dark
        }
    }

    private fun handleIncomingIntent(intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_SEND -> {
                if (intent.type == "application/x-bittorrent") {
                    @Suppress("DEPRECATION")
                    val stream = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                    if (stream != null) queueTorrentUri(stream)
                    else inputMessage = "Torrent file could not be opened."
                } else {
                    val text = intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
                    val magnet = text.trim().takeIf { it.startsWith("magnet:?", ignoreCase = true) }
                    if (magnet != null) {
                        queueMagnet(magnet)
                    } else {
                        val urls = extractHttpUrls(text)
                        if (urls.isNotEmpty()) {
                            initialUrl = urls.joinToString("\n")
                            inputMessage = if (urls.size == 1) {
                                "Link received from another app."
                            } else {
                                "${urls.size} links received from another app."
                            }
                        }
                    }
                }
            }

            Intent.ACTION_VIEW -> {
                val data = intent.dataString.orEmpty()
                when {
                    data.startsWith("http://") || data.startsWith("https://") -> {
                        initialUrl = data
                        inputMessage = "Browser link captured."
                    }
                    data.startsWith("magnet:", ignoreCase = true) -> {
                        queueMagnet(data)
                    }
                    intent.type == "application/x-bittorrent" ||
                        runCatching { intent.data?.let(contentResolver::getType) == "application/x-bittorrent" }.getOrDefault(false) ||
                        data.substringBefore('?').endsWith(".torrent", ignoreCase = true) -> {
                        intent.data?.let(::queueTorrentUri)
                            ?: run { inputMessage = "Torrent file could not be opened." }
                    }
                }
            }
        }
    }

    private fun showMagnetDialog(initialValue: String = "") {
        val input = EditText(this).apply {
            hint = "magnet:?xt=urn:btih:..."
            setSingleLine(false)
            minLines = 3
            setText(initialValue)
            setSelection(text.length)
        }
        val dialogStyle = if (AppDarkModeState) android.R.style.Theme_Material_Dialog_Alert else android.R.style.Theme_Material_Light_Dialog_Alert
        val dialog = PlatformAlertDialog.Builder(this, dialogStyle)
            .setTitle("Add magnet link")
            .setMessage("Paste a BitTorrent magnet URI. Use torrents only for content you are allowed to download.")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Add", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(PlatformAlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val value = input.text?.toString().orEmpty().trim()
                if (!value.startsWith("magnet:?", ignoreCase = true)) {
                    input.error = "Enter a valid magnet link"
                } else {
                    queueMagnet(value)
                    dialog.dismiss()
                }
            }
        }
        dialog.show()
    }

    private fun queueMagnet(raw: String) {
        val value = raw.trim()
        if (!value.startsWith("magnet:?", ignoreCase = true)) {
            inputMessage = "Invalid magnet link."
            return
        }
        queueSpecialDownload(value, "Magnet")
    }

    private fun queueTorrentUri(uri: Uri) {
        try {
            val displayName = contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            } ?: "download.torrent"

            val safeBase = displayName
                .replace(Regex("[\\/:*?\"<>|]"), "_")
                .trim()
                .ifBlank { "download.torrent" }
                .let { if (it.endsWith(".torrent", ignoreCase = true)) it else "$it.torrent" }
            val metainfoDir = File(filesDir, TorrentDownloadEngine.METAINFO_DIR).apply { mkdirs() }
            val target = File(metainfoDir, "${UUID.randomUUID()}-$safeBase")
            contentResolver.openInputStream(uri)?.use { input ->
                target.outputStream().buffered().use { output -> input.copyTo(output, 256 * 1024) }
            } ?: throw IllegalStateException("Unable to read torrent file")
            if (target.length() <= 0L) {
                target.delete()
                throw IllegalArgumentException("Torrent file is empty")
            }
            queueSpecialDownload(TorrentDownloadEngine.makeFileSource(target.absolutePath), ".torrent")
        } catch (t: Throwable) {
            inputMessage = t.message?.takeIf { it.isNotBlank() } ?: "Unable to add torrent file."
        }
    }

    private fun queueSpecialDownload(source: String, label: String) {
        val duplicate = store.findLatestByUrl(source)
        if (duplicate != null && duplicate.status !in setOf(DownloadStatus.CANCELLED, DownloadStatus.FAILED)) {
            inputMessage = "$label already exists in the queue/history."
            return
        }
        store.enqueue(url = source)
        inputMessage = "$label added to BitTorrent queue."
        refreshTasks()
        ContextCompat.startForegroundService(
            this,
            Intent(this, DownloadService::class.java).apply { action = DownloadService.ACTION_ENQUEUE }
        )
    }

    private fun queueDownload(
        rawText: String,
        browserRequest: BrowserDownloadRequest? = null,
        options: DownloadRequestOptions = DownloadRequestOptions()
    ) {
        val urls = extractHttpUrls(rawText)
        if (urls.isEmpty()) {
            inputMessage = "Enter at least one valid http/https download link."
            return
        }

        var added = 0
        var skipped = 0
        urls.forEach { clean ->
            val duplicate = store.findLatestByUrl(clean)
            if (duplicate != null && duplicate.status !in setOf(DownloadStatus.CANCELLED, DownloadStatus.FAILED)) {
                skipped++
            } else {
                val session = browserRequest?.takeIf { urls.size == 1 && it.url == clean }
                store.enqueue(
                    url = clean,
                    requestCookie = session?.cookie,
                    requestReferer = session?.referer,
                    requestUserAgent = session?.userAgent,
                    requestedFileName = options.requestedFileName?.takeIf { urls.size == 1 },
                    outputTreeUri = options.outputTreeUri,
                    scheduledAt = options.scheduledAt,
                    expectedSha256 = options.expectedSha256?.takeIf { urls.size == 1 }
                )
                added++
            }
        }

        if (added == 0) {
            inputMessage = if (skipped > 0) {
                "All ${urls.size} link${if (urls.size == 1) "" else "s"} already exist in history/queue."
            } else {
                "No new download links were added."
            }
            return
        }

        inputMessage = buildString {
            append("Added $added link${if (added == 1) "" else "s"} to queue")
            if (skipped > 0) append(" • skipped $skipped duplicate${if (skipped == 1) "" else "s"}")
            options.scheduledAt?.takeIf { it > System.currentTimeMillis() }?.let {
                append(" • scheduled ${formatScheduledTime(it)}")
            }
            if (!options.expectedSha256.isNullOrBlank() && urls.size == 1) append(" • SHA-256 verify ON")
            append(" • Turbo ${if (turboMode) "ON" else "OFF"}")
        }
        initialUrl = ""
        refreshTasks()

        val serviceIntent = Intent(this, DownloadService::class.java).apply {
            action = DownloadService.ACTION_ENQUEUE
        }
        ContextCompat.startForegroundService(this, serviceIntent)
    }

    private fun extractHttpUrls(text: String): List<String> =
        Regex("https?://[^\\s<>\"']+", RegexOption.IGNORE_CASE)
            .findAll(text)
            .map { match ->
                match.value.trimEnd('.', ',', ';', ':', ')', ']', '}', '>')
            }
            .filter { it.startsWith("http://", ignoreCase = true) || it.startsWith("https://", ignoreCase = true) }
            .distinct()
            .toList()

    private fun recoverQueue() {
        if (tasks.none { it.status == DownloadStatus.QUEUED || it.status == DownloadStatus.DOWNLOADING }) return
        val serviceIntent = Intent(this, DownloadService::class.java).apply {
            action = DownloadService.ACTION_RECOVER
        }
        ContextCompat.startForegroundService(this, serviceIntent)
    }

    private fun control(action: String, taskId: String) {
        val serviceIntent = Intent(this, DownloadService::class.java).apply {
            this.action = action
            putExtra(DownloadService.EXTRA_TASK_ID, taskId)
        }
        if (action == DownloadService.ACTION_RESUME || action == DownloadService.ACTION_RETRY) {
            ContextCompat.startForegroundService(this, serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    private fun pauseAll() {
        tasks.filter { it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.QUEUED }
            .forEach { control(DownloadService.ACTION_PAUSE, it.id) }
    }

    private fun resumeAll() {
        tasks.filter { it.status == DownloadStatus.PAUSED }.forEach {
            control(DownloadService.ACTION_RESUME, it.id)
        }
        tasks.filter { it.status == DownloadStatus.FAILED }.forEach {
            control(DownloadService.ACTION_RETRY, it.id)
        }
    }

    private fun refreshTasks() {
        tasks = runCatching { store.getAll() }.getOrDefault(emptyList())
    }

    private fun openCompletedFile(task: DownloadTask) {
        val uri = task.outputUri?.let(Uri::parse) ?: return
        val viewIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, task.mimeType ?: "application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { startActivity(Intent.createChooser(viewIntent, "Open with")) }
    }

    private fun shareCompletedFile(task: DownloadTask) {
        val uri = task.outputUri?.let(Uri::parse) ?: return
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = task.mimeType ?: "application/octet-stream"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { startActivity(Intent.createChooser(shareIntent, "Share download")) }
    }

    private fun deleteTask(task: DownloadTask) {
        when (task.status) {
            DownloadStatus.COMPLETED -> {
                task.outputUri?.let { raw ->
                    runCatching { contentResolver.delete(Uri.parse(raw), null, null) }
                }
            }
            DownloadStatus.DOWNLOADING, DownloadStatus.QUEUED, DownloadStatus.PAUSED -> {
                control(DownloadService.ACTION_CANCEL, task.id)
                deleteTaskWorkspace(task)
            }
            DownloadStatus.FAILED, DownloadStatus.CANCELLED -> {
                deleteTaskWorkspace(task)
            }
        }
        store.delete(task.id)
        refreshTasks()
    }

    private fun deleteTaskWorkspace(task: DownloadTask) {
        if (TorrentDownloadEngine.isTorrentSource(task.url)) {
            TorrentDownloadEngine(applicationContext).deleteWorkspace(task.id)
            if (task.url.startsWith(TorrentDownloadEngine.TORRENT_FILE_PREFIX, ignoreCase = true)) {
                runCatching { TorrentDownloadEngine.sourceFile(task.url).delete() }
            }
        } else {
            DownloadEngine(applicationContext).deleteWorkspace(task.id)
        }
    }

    private fun setTaskPriority(taskId: String, priority: Int) {
        store.setPriority(taskId, priority)
        inputMessage = "Queue priority set to ${priorityLabel(priority)}."
        refreshTasks()
    }

    private fun clearCompleted() {
        store.clearCompleted()
        inputMessage = "Completed items cleared from history. Files remain in Downloads/MultiFetch."
        refreshTasks()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}

@Composable
private fun ThemeTransitionOverlay(
    targetDark: Boolean,
    token: Int,
    onMidpoint: () -> Unit,
    onFinished: () -> Unit
) {
    val progress = remember(token) { Animatable(0f) }
    val density = LocalDensity.current
    val startPx = with(density) { (-130).dp.toPx() }
    val travelPx = with(density) { 390.dp.toPx() }

    LaunchedEffect(token) {
        progress.snapTo(0f)
        progress.animateTo(0.48f, animationSpec = tween(durationMillis = 380, easing = FastOutSlowInEasing))
        onMidpoint()
        progress.animateTo(1f, animationSpec = tween(durationMillis = 520, easing = FastOutSlowInEasing))
        onFinished()
    }

    val p = progress.value.coerceIn(0f, 1f)
    val veilAlpha = if (p < 0.55f) (p / 0.55f) * 0.24f else ((1f - p) / 0.45f) * 0.24f
    val iconAlpha = if (p < 0.85f) 1f else ((1f - p) / 0.15f).coerceIn(0f, 1f)
    val veil = if (targetDark) Color(0xFF02040A) else Color(0xFFFFF6D8)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(veil.copy(alpha = veilAlpha.coerceIn(0f, 0.24f))),
        contentAlignment = Alignment.TopCenter
    ) {
        Canvas(
            modifier = Modifier
                .padding(top = 18.dp)
                .size(112.dp)
                .graphicsLayer {
                    translationY = startPx + (travelPx * p)
                    alpha = iconAlpha
                    scaleX = 0.82f + 0.18f * p
                    scaleY = scaleX
                }
        ) {
            if (targetDark) drawFallingMoon() else drawFallingSun()
        }
    }
}

private fun DrawScope.drawFallingSun() {
    val center = this.center
    val radius = size.minDimension * 0.22f
    repeat(8) { index ->
        rotate(index * 45f, pivot = center) {
            drawLine(
                color = Color(0xFFFFC43D),
                start = androidx.compose.ui.geometry.Offset(center.x, center.y - radius * 1.55f),
                end = androidx.compose.ui.geometry.Offset(center.x, center.y - radius * 2.05f),
                strokeWidth = size.minDimension * 0.045f,
                cap = StrokeCap.Round
            )
        }
    }
    drawCircle(color = Color(0xFFFFD65A), radius = radius, center = center)
    drawCircle(color = Color(0xFFFFB300).copy(alpha = 0.22f), radius = radius * 1.45f, center = center)
}

private fun DrawScope.drawFallingMoon() {
    val center = this.center
    val radius = size.minDimension * 0.28f
    drawCircle(color = Color(0xFFF2F5FF), radius = radius, center = center)
    drawCircle(
        color = Color(0xFF111927),
        radius = radius * 0.92f,
        center = androidx.compose.ui.geometry.Offset(center.x + radius * 0.42f, center.y - radius * 0.18f)
    )
    drawCircle(color = Color(0xFFB9C8FF).copy(alpha = 0.15f), radius = radius * 1.5f, center = center)
}

private enum class AppTab(val label: String, val symbol: String) {
    HOME("Home", "⌂"),
    BROWSER("Browser", "◎"),
    QUEUE("Queue", "☷"),
    CONNECTIONS("Connections", "⌘"),
    SETTINGS("Settings", "⚙")
}

private enum class QueueFilter(val label: String) {
    ALL("All"),
    ACTIVE("Active"),
    COMPLETED("Done"),
    ISSUES("Issues")
}

@Composable
private fun MultiFetchApp(
    tasks: List<DownloadTask>,
    initialUrl: String,
    inputMessage: String,
    turboMode: Boolean,
    combineNetworks: Boolean,
    turboConnections: Int,
    autoRetryFailedDownloads: Boolean,
    autoResumeAfterRestart: Boolean,
    wifiOnlyDownloads: Boolean,
    autoOrganizeDownloads: Boolean,
    duplicateSafeFileNames: Boolean,
    speedLimitBytesPerSecond: Long,
    maxConcurrentDownloads: Int,
    darkMode: Boolean,
    onTurboModeChange: (Boolean) -> Unit,
    onCombineNetworksChange: (Boolean) -> Unit,
    onTurboConnectionsChange: (Int) -> Unit,
    onAutoRetryChange: (Boolean) -> Unit,
    onAutoResumeAfterRestartChange: (Boolean) -> Unit,
    onWifiOnlyChange: (Boolean) -> Unit,
    onAutoOrganizeChange: (Boolean) -> Unit,
    onDuplicateSafeNamesChange: (Boolean) -> Unit,
    onSpeedLimitChange: (Long) -> Unit,
    onMaxConcurrentDownloadsChange: (Int) -> Unit,
    onDarkModeChange: (Boolean) -> Unit,
    onQueue: (String, BrowserDownloadRequest?, DownloadRequestOptions) -> Unit,
    onPause: (String) -> Unit,
    onResume: (String) -> Unit,
    onCancel: (String) -> Unit,
    onRetry: (String) -> Unit,
    onOpen: (DownloadTask) -> Unit,
    onShare: (DownloadTask) -> Unit,
    onDelete: (DownloadTask) -> Unit,
    onSetPriority: (String, Int) -> Unit,
    onClearCompleted: () -> Unit,
    onPickTorrent: () -> Unit,
    onMagnet: () -> Unit,
    onPauseAll: () -> Unit,
    onResumeAll: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(AppTab.HOME) }
    var showAddDialog by remember { mutableStateOf(false) }
    var showSearchDialog by remember { mutableStateOf(false) }
    var showQuickMenu by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var searchDraft by remember { mutableStateOf("") }
    var dialogUrl by remember { mutableStateOf(initialUrl) }
    var dialogBrowserRequest by remember { mutableStateOf<BrowserDownloadRequest?>(null) }
    var dialogFileName by remember { mutableStateOf("") }
    var dialogOutputTreeUri by remember { mutableStateOf<String?>(null) }
    var dialogOutputFolderLabel by remember { mutableStateOf("Default • Downloads/MultiFetch") }
    var dialogScheduledAt by remember { mutableStateOf<Long?>(null) }
    var dialogSha256 by remember { mutableStateOf("") }
    val context = androidx.compose.ui.platform.LocalContext.current
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            runCatching { context.contentResolver.takePersistableUriPermission(uri, flags) }
            dialogOutputTreeUri = uri.toString()
            dialogOutputFolderLabel = folderLabel(uri)
        }
    }

    LaunchedEffect(initialUrl) {
        if (initialUrl.isNotBlank()) {
            dialogUrl = initialUrl
            dialogBrowserRequest = null
            dialogFileName = ""
            dialogOutputTreeUri = null
            dialogOutputFolderLabel = "Default • Downloads/MultiFetch"
            dialogScheduledAt = null
            dialogSha256 = ""
            showAddDialog = true
            selectedTab = AppTab.HOME
        }
    }

    Scaffold(
        containerColor = AppBackground,
        bottomBar = {
            NavigationBar(containerColor = AppSurface) {
                AppTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = {
                            Text(
                                tab.symbol,
                                fontSize = 22.sp,
                                color = if (selectedTab == tab) AppBlue else Muted
                            )
                        },
                        label = { Text(tab.label, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { padding ->
        when (selectedTab) {
            AppTab.HOME -> DashboardHome(
                modifier = Modifier.padding(padding),
                tasks = tasks,
                inputMessage = inputMessage,
                turboMode = turboMode,
                combineNetworks = combineNetworks,
                speedLimitBytesPerSecond = speedLimitBytesPerSecond,
                onAddUrl = {
                    dialogBrowserRequest = null
                    dialogFileName = ""
                    dialogOutputTreeUri = null
                    dialogOutputFolderLabel = "Default • Downloads/MultiFetch"
                    dialogScheduledAt = null
                    dialogSha256 = ""
                    showAddDialog = true
                },
                onOpenBrowser = { selectedTab = AppTab.BROWSER },
                onMagnet = onMagnet,
                onPickTorrent = onPickTorrent,
                onOpenQueue = { selectedTab = AppTab.QUEUE },
                onOpenConnections = { selectedTab = AppTab.CONNECTIONS },
                onOpenSettings = { selectedTab = AppTab.SETTINGS },
                onClearCompleted = onClearCompleted,
                onSearch = {
                    searchDraft = searchQuery
                    showSearchDialog = true
                },
                onQuickMenu = { showQuickMenu = true }
            )

            AppTab.BROWSER -> BrowserScreen(
                modifier = Modifier.padding(padding),
                onDownloadRequest = { request ->
                    dialogUrl = request.url
                    dialogBrowserRequest = request
                    dialogFileName = ""
                    dialogOutputTreeUri = null
                    dialogOutputFolderLabel = "Default • Downloads/MultiFetch"
                    dialogScheduledAt = null
                    dialogSha256 = ""
                    showAddDialog = true
                }
            )

            AppTab.QUEUE -> QueueScreen(
                modifier = Modifier.padding(padding),
                tasks = tasks,
                onPause = onPause,
                onResume = onResume,
                onCancel = onCancel,
                onRetry = onRetry,
                onOpen = onOpen,
                onShare = onShare,
                onDelete = onDelete,
                onSetPriority = onSetPriority,
                onPauseAll = onPauseAll,
                onResumeAll = onResumeAll,
                onClearCompleted = onClearCompleted,
                searchQuery = searchQuery,
                onClearSearch = { searchQuery = "" }
            )

            AppTab.CONNECTIONS -> ConnectionsScreen(
                modifier = Modifier.padding(padding),
                tasks = tasks,
                combineNetworks = combineNetworks,
                turboMode = turboMode,
                turboConnections = turboConnections,
                onCombineNetworksChange = onCombineNetworksChange
            )

            AppTab.SETTINGS -> SettingsScreen(
                modifier = Modifier.padding(padding),
                turboMode = turboMode,
                combineNetworks = combineNetworks,
                turboConnections = turboConnections,
                autoRetryFailedDownloads = autoRetryFailedDownloads,
                autoResumeAfterRestart = autoResumeAfterRestart,
                wifiOnlyDownloads = wifiOnlyDownloads,
                autoOrganizeDownloads = autoOrganizeDownloads,
                duplicateSafeFileNames = duplicateSafeFileNames,
                speedLimitBytesPerSecond = speedLimitBytesPerSecond,
                maxConcurrentDownloads = maxConcurrentDownloads,
                darkMode = darkMode,
                onTurboModeChange = onTurboModeChange,
                onCombineNetworksChange = onCombineNetworksChange,
                onTurboConnectionsChange = onTurboConnectionsChange,
                onAutoRetryChange = onAutoRetryChange,
                onAutoResumeAfterRestartChange = onAutoResumeAfterRestartChange,
                onWifiOnlyChange = onWifiOnlyChange,
                onAutoOrganizeChange = onAutoOrganizeChange,
                onDuplicateSafeNamesChange = onDuplicateSafeNamesChange,
                onSpeedLimitChange = onSpeedLimitChange,
                onMaxConcurrentDownloadsChange = onMaxConcurrentDownloadsChange,
                onDarkModeChange = onDarkModeChange
            )
        }
    }

    if (showSearchDialog) {
        AlertDialog(
            onDismissRequest = { showSearchDialog = false },
            title = { Text("Search downloads", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = searchDraft,
                    onValueChange = { searchDraft = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("File name or URL") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    searchQuery = searchDraft.trim()
                    showSearchDialog = false
                    selectedTab = AppTab.QUEUE
                }) { Text("Search") }
            },
            dismissButton = {
                TextButton(onClick = {
                    searchDraft = ""
                    searchQuery = ""
                    showSearchDialog = false
                }) { Text("Clear") }
            }
        )
    }

    if (showQuickMenu) {
        AlertDialog(
            onDismissRequest = { showQuickMenu = false },
            title = { Text("Quick actions", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = {
                        showQuickMenu = false
                        dialogBrowserRequest = null
                        dialogFileName = ""
                        dialogOutputTreeUri = null
                        dialogOutputFolderLabel = "Default • Downloads/MultiFetch"
                        dialogScheduledAt = null
                        dialogSha256 = ""
                        showAddDialog = true
                    }) { Text("Add download(s)") }
                    TextButton(onClick = {
                        showQuickMenu = false
                        selectedTab = AppTab.BROWSER
                    }) { Text("Open browser") }
                    TextButton(onClick = {
                        showQuickMenu = false
                        selectedTab = AppTab.QUEUE
                    }) { Text("Open queue") }
                    TextButton(onClick = {
                        showQuickMenu = false
                        selectedTab = AppTab.CONNECTIONS
                    }) { Text("Connections") }
                    TextButton(onClick = {
                        showQuickMenu = false
                        selectedTab = AppTab.SETTINGS
                    }) { Text("Settings") }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQuickMenu = false }) { Text("Close") }
            }
        )
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = {
                showAddDialog = false
                dialogBrowserRequest = null
                dialogFileName = ""
                dialogOutputTreeUri = null
                dialogOutputFolderLabel = "Default • Downloads/MultiFetch"
                dialogScheduledAt = null
                dialogSha256 = ""
            },
            title = {
                Text(
                    if (dialogBrowserRequest != null) "Add browser download" else "Add download(s)",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        if (dialogBrowserRequest != null) {
                            "This link was captured from the browser. MultiFetch will carry the current browser session for login-protected downloads."
                        } else {
                            "Paste one direct HTTP/HTTPS link, or paste many links together. MultiFetch will extract unique links and queue them in order."
                        },
                        color = Muted
                    )
                    OutlinedTextField(
                        value = dialogUrl,
                        onValueChange = { dialogUrl = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Download URL(s)") },
                        placeholder = { Text("https://example.com/file1.zip\nhttps://example.com/file2.mp4") },
                        minLines = 4
                    )
                    val singleLink = extractHttpUrls(dialogUrl).size <= 1
                    OutlinedTextField(
                        value = dialogFileName,
                        onValueChange = { dialogFileName = it },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = singleLink,
                        singleLine = true,
                        label = { Text("File name (optional)") },
                        placeholder = { Text("Keep server file name") }
                    )
                    if (!singleLink) {
                        Text("Custom rename and SHA-256 verification are available for a single link. The selected folder can still be used for the whole batch.", color = Muted, fontSize = 11.sp)
                    }
                    val checksumValid = dialogSha256.isBlank() || FileIntegrity.isValidOrBlank(dialogSha256)
                    OutlinedTextField(
                        value = dialogSha256,
                        onValueChange = { dialogSha256 = it },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = singleLink,
                        singleLine = true,
                        isError = !checksumValid,
                        label = { Text("Expected SHA-256 (optional)") },
                        placeholder = { Text("64 hex • SHA256: prefix also accepted") }
                    )
                    Text(
                        if (checksumValid) "If provided, MultiFetch verifies the complete file before publishing it." else "SHA-256 must contain 64 hexadecimal characters (optional SHA256: prefix is accepted).",
                        color = if (checksumValid) Muted else Color(0xFFE05252),
                        fontSize = 10.sp
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { folderPicker.launch(null) }) { Text("Choose folder") }
                        if (dialogOutputTreeUri != null) {
                            TextButton(onClick = {
                                dialogOutputTreeUri = null
                                dialogOutputFolderLabel = "Default • Downloads/MultiFetch"
                            }) { Text("Use default") }
                        }
                    }
                    Text(dialogOutputFolderLabel, color = Muted, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    HorizontalDivider(color = Border)
                    Text("Download scheduler", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(
                        dialogScheduledAt?.let { "Starts around ${formatScheduledTime(it)}" }
                            ?: "Start as soon as a download slot is available",
                        color = Muted,
                        fontSize = 11.sp
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            showSchedulePicker(context, dialogScheduledAt) { selected ->
                                dialogScheduledAt = selected
                            }
                        }) { Text(if (dialogScheduledAt == null) "Schedule" else "Change time") }
                        if (dialogScheduledAt != null) {
                            TextButton(onClick = { dialogScheduledAt = null }) { Text("Start now") }
                        }
                    }
                }
            },
            confirmButton = {
                val singleLink = extractHttpUrls(dialogUrl).size <= 1
                val checksumValid = dialogSha256.isBlank() || FileIntegrity.isValidOrBlank(dialogSha256)
                Button(
                    enabled = !singleLink || checksumValid,
                    onClick = {
                    val session = dialogBrowserRequest?.takeIf { dialogUrl.trim() == it.url }
                    onQueue(
                        dialogUrl,
                        session,
                        DownloadRequestOptions(
                            requestedFileName = dialogFileName.trim().takeIf { it.isNotBlank() },
                            outputTreeUri = dialogOutputTreeUri,
                            scheduledAt = dialogScheduledAt,
                            expectedSha256 = FileIntegrity.normalizeSha256(dialogSha256)
                        )
                    )
                    showAddDialog = false
                    dialogUrl = ""
                    dialogFileName = ""
                    dialogOutputTreeUri = null
                    dialogOutputFolderLabel = "Default • Downloads/MultiFetch"
                    dialogScheduledAt = null
                    dialogSha256 = ""
                    dialogBrowserRequest = null
                }) { Text("Queue link(s)") }
            },
            dismissButton = {
                TextButton(onClick = {
                    showAddDialog = false
                    dialogBrowserRequest = null
                    dialogFileName = ""
                    dialogOutputTreeUri = null
                    dialogOutputFolderLabel = "Default • Downloads/MultiFetch"
                    dialogScheduledAt = null
                    dialogSha256 = ""
                }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun DashboardHome(
    modifier: Modifier,
    tasks: List<DownloadTask>,
    inputMessage: String,
    turboMode: Boolean,
    combineNetworks: Boolean,
    speedLimitBytesPerSecond: Long,
    onAddUrl: () -> Unit,
    onOpenBrowser: () -> Unit,
    onMagnet: () -> Unit,
    onPickTorrent: () -> Unit,
    onOpenQueue: () -> Unit,
    onOpenConnections: () -> Unit,
    onOpenSettings: () -> Unit,
    onClearCompleted: () -> Unit,
    onSearch: () -> Unit,
    onQuickMenu: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val network = remember(tasks, combineNetworks) { networkSnapshot(context) }
    val activeDownloads = tasks.filter { it.status == DownloadStatus.DOWNLOADING }
    val active = activeDownloads.firstOrNull()
        ?: tasks.firstOrNull { it.status == DownloadStatus.PAUSED }
    val totalSpeed = activeDownloads.sumOf { parseSpeedBytesPerSecond(it.message) }
    val combinedActive = activeDownloads.any { it.message.contains("Wi‑Fi + Mobile", ignoreCase = true) }
    val turboActive = activeDownloads.any { it.message.contains("Turbo", ignoreCase = true) && it.segmentCount > 1 }
    val liveConnectionCount = activeDownloads.sumOf { parseConnectionCount(it.message) }
    val totalChunks = activeDownloads.sumOf { it.segmentCount }
    val (wifiSharePct, mobileSharePct) = aggregateNetworkShares(activeDownloads, network)

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { BrandHeader(onSearch, onQuickMenu) }
        item {
            SpeedSummaryCard(
                totalSpeed,
                network,
                combineNetworks,
                combinedActive,
                turboActive,
                totalChunks,
                liveConnectionCount,
                activeDownloads.size,
                wifiSharePct,
                mobileSharePct
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1.7f)) {
                    ActiveDownloadCard(active, active?.let { parseSpeedBytesPerSecond(it.message) } ?: 0L, Modifier.fillMaxWidth())
                }
                Box(Modifier.weight(1f)) {
                    NetworkShareCard(totalSpeed, wifiSharePct, mobileSharePct, Modifier.fillMaxWidth())
                }
            }
        }
        item { ActiveConnectionsCard(network, combinedActive, onOpenConnections) }
        item { AddDownloadCard(onOpenBrowser, onAddUrl, onMagnet, onPickTorrent) }
        if (inputMessage.isNotBlank()) {
            item {
                Surface(
                    color = SoftBlue,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(inputMessage, modifier = Modifier.padding(14.dp), color = DeepNavy, fontSize = 13.sp)
                }
            }
        }
        item { QueuePreviewCard(tasks, onOpenQueue, onClearCompleted) }
        item { LimitsCard(turboMode, combineNetworks, speedLimitBytesPerSecond, onOpenSettings) }
    }
}

@Composable
private fun BrandHeader(onSearch: () -> Unit, onQuickMenu: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = painterResource(R.drawable.multifetch_logo),
            contentDescription = "MultiFetch logo",
            modifier = Modifier.size(54.dp).clip(RoundedCornerShape(16.dp)),
            contentScale = ContentScale.Crop
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("MultiFetch", fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, color = DeepNavy)
            Text("FASTER DOWNLOADS • MULTI-NETWORK", fontSize = 10.sp, color = Muted, letterSpacing = 1.1.sp)
        }
        Text(
            "⌕",
            fontSize = 28.sp,
            color = DeepNavy,
            modifier = Modifier.clickable(onClick = onSearch).padding(6.dp)
        )
        Spacer(Modifier.width(6.dp))
        Text(
            "⋮",
            fontSize = 28.sp,
            color = DeepNavy,
            modifier = Modifier.clickable(onClick = onQuickMenu).padding(6.dp)
        )
    }
}

@Composable
private fun SpeedSummaryCard(
    totalSpeed: Long,
    network: NetworkSnapshot,
    combineConfigured: Boolean,
    combinedActive: Boolean,
    turboActive: Boolean,
    segmentCount: Int,
    liveConnectionCount: Int,
    activeDownloadCount: Int,
    wifiSharePct: Int,
    mobileSharePct: Int
) {
    val wifiUsing = combinedActive || network.activeTransport == "Wi‑Fi"
    val mobileUsing = combinedActive || network.activeTransport == "Mobile"
    val wifiSpeed = speedShare(totalSpeed, wifiSharePct / 100.0)
    val mobileSpeed = speedShare(totalSpeed, mobileSharePct / 100.0)

    PremiumCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1.05f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MiniNetworkPill(
                    "≋",
                    "Wi‑Fi",
                    wifiSpeed,
                    when {
                        wifiUsing -> "In use"
                        network.wifi -> "Available"
                        else -> "Offline"
                    },
                    wifiUsing
                )
                MiniNetworkPill(
                    "▥",
                    "Mobile Data",
                    mobileSpeed,
                    when {
                        mobileUsing -> if (combinedActive) "Combined" else "In use"
                        network.cellular -> if (combineConfigured) "Ready" else "Available"
                        else -> "Offline"
                    },
                    mobileUsing
                )
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1.35f)) {
                Text("Total Download Speed", color = Muted, fontSize = 13.sp)
                Text(formatSpeed(totalSpeed), color = DeepNavy, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                val liveConnections = liveConnectionCount.takeIf { it > 0 }
                    ?: minOf(segmentCount, if (combinedActive) 16 else 12)
                val filePrefix = if (activeDownloadCount > 1) "$activeDownloadCount files • " else ""
                val modeText = when {
                    activeDownloadCount > 1 && combinedActive && turboActive -> "${filePrefix}Stable Turbo • $liveConnections connections • $segmentCount chunks"
                    activeDownloadCount > 1 && turboActive -> "${filePrefix}Stable Turbo • $liveConnections connections • $segmentCount chunks"
                    activeDownloadCount > 1 -> "${filePrefix}simultaneous downloads"
                    combinedActive && turboActive -> "Stable Turbo • $liveConnections connections • $segmentCount chunks"
                    combinedActive -> "Wi‑Fi + Mobile ACTIVE"
                    turboActive -> "Stable Turbo • $liveConnections connections • $segmentCount chunks"
                    combineConfigured -> "Combine ready • waiting for both routes"
                    else -> "Single-network mode"
                }
                Text(modeText, color = if (totalSpeed > 0) Success else Muted, fontSize = 11.sp)
            }
            SpeedBars(active = totalSpeed > 0)
        }
    }
}

@Composable
private fun MiniNetworkPill(
    symbol: String,
    name: String,
    speed: Long,
    status: String,
    inUse: Boolean
) {
    Surface(color = SoftBlue, shape = RoundedCornerShape(14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(symbol, color = AppBlue, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp))
            Column {
                Text(name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    if (inUse) "${formatSpeed(speed)} • $status" else status,
                    fontSize = 11.sp,
                    color = if (inUse) DeepNavy else Muted
                )
            }
        }
    }
}

@Composable
private fun SpeedBars(active: Boolean) {
    Row(
        modifier = Modifier.width(52.dp).height(76.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        val heights = listOf(24, 38, 30, 52, 42, 62, 48)
        heights.forEach { h ->
            Box(
                Modifier.weight(1f).height(h.dp).clip(RoundedCornerShape(4.dp))
                    .background(if (active) AppBlue.copy(alpha = 0.75f) else AppBlue.copy(alpha = 0.18f))
            )
        }
    }
}

@Composable
private fun ActiveDownloadCard(task: DownloadTask?, speed: Long, modifier: Modifier = Modifier) {
    PremiumCard(modifier) {
        SectionTitle("Active Download", null)
        Spacer(Modifier.height(12.dp))
        if (task == null) {
            Text("No active download", fontWeight = FontWeight.SemiBold)
            Text("Add a URL to start downloading.", color = Muted, fontSize = 12.sp)
        } else {
            val progress = progressOf(task)
            Row(verticalAlignment = Alignment.CenterVertically) {
                FileBadge(categoryFor(task))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(task.fileName ?: shortUrl(task.url), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("${formatBytes(task.downloadedBytes)} / ${formatBytes(task.totalBytes)}", color = Muted, fontSize = 12.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("${(progress * 100).toInt()}%", color = AppBlue, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    Text(statusLabel(task.status), color = Muted, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(9.dp).clip(CircleShape),
                color = AppBlue,
                trackColor = Border
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("≋ ${formatSpeed(speed)}", color = Muted, fontSize = 12.sp)
                Text("⇶ ${task.segmentCount} chunks", color = Muted, fontSize = 12.sp)
            }
            val eta = etaFor(task, speed)
            if (eta != null) {
                Spacer(Modifier.height(6.dp))
                Text("ETA $eta", color = AppBlue, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun NetworkShareCard(
    speed: Long,
    wifiSharePct: Int,
    mobileSharePct: Int,
    modifier: Modifier = Modifier
) {
    PremiumCard(modifier) {
        Text("Network Share", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(8.dp))
        val wifiPct = wifiSharePct.toFloat().coerceIn(0f, 100f)
        val cellPct = mobileSharePct.toFloat().coerceIn(0f, 100f)
        Box(modifier = Modifier.fillMaxWidth().height(118.dp), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.size(92.dp)) {
                val stroke = Stroke(width = 14.dp.toPx(), cap = StrokeCap.Butt)
                drawArc(Border, -90f, 360f, false, style = stroke)
                if (wifiPct > 0f) drawArc(AppBlue, -90f, 360f * wifiPct / 100f, false, style = stroke)
                if (cellPct > 0f) drawArc(
                    Color(0xFF67B7FF),
                    -90f + 360f * wifiPct / 100f,
                    360f * cellPct / 100f,
                    false,
                    style = stroke
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(shortSpeed(speed), fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                Text("total", color = Muted, fontSize = 10.sp)
            }
        }
        LegendDot(AppBlue, "Wi‑Fi", wifiPct.toInt())
        LegendDot(Color(0xFF67B7FF), "Mobile", cellPct.toInt())
    }
}

@Composable
private fun LegendDot(color: Color, label: String, pct: Int) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(label, modifier = Modifier.weight(1f), color = Muted, fontSize = 11.sp)
        Text("$pct%", fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
    }
}

@Composable
private fun ActiveConnectionsCard(
    network: NetworkSnapshot,
    combinedActive: Boolean,
    onSeeAll: () -> Unit
) {
    PremiumCard {
        SectionTitle("Active Connections", "See All", onSeeAll)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ConnectionTile(
                "≋",
                "Wi‑Fi",
                connectionStatus(network.wifi, network.activeTransport == "Wi‑Fi", combinedActive && network.wifi),
                Modifier.weight(1f)
            )
            ConnectionTile(
                "▥",
                "Mobile",
                connectionStatus(network.cellular, network.activeTransport == "Mobile", combinedActive && network.cellular),
                Modifier.weight(1f)
            )
            ConnectionTile(
                "USB",
                "Ethernet",
                connectionStatus(network.ethernet, network.activeTransport == "Ethernet", false),
                Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun ConnectionTile(symbol: String, name: String, status: String, modifier: Modifier) {
    val active = status == "Connected" || status == "Combined"
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = AppSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, Border)
    ) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(symbol, color = AppBlue, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(name, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(7.dp).clip(CircleShape)
                        .background(if (active) Success else Color(0xFFB7BECC))
                )
                Spacer(Modifier.width(5.dp))
                Text(status, color = Muted, fontSize = 10.sp)
            }
        }
    }
}

private fun connectionStatus(available: Boolean, defaultActive: Boolean, combinedActive: Boolean): String = when {
    combinedActive -> "Combined"
    defaultActive -> "Connected"
    available -> "Available"
    else -> "Offline"
}

@Composable
private fun AddDownloadCard(
    onBrowser: () -> Unit,
    onUrl: () -> Unit,
    onMagnet: () -> Unit,
    onTorrent: () -> Unit
) {
    PremiumCard {
        SectionTitle("Add Download", "⌃")
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AddDownloadTile("◎", "Browser", "Browse & capture", true, onBrowser, Modifier.weight(1f))
            AddDownloadTile("🔗", "URL / Batch", "One or many links", true, onUrl, Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AddDownloadTile("∪", "Magnet", "Paste magnet", true, onMagnet, Modifier.weight(1f))
            AddDownloadTile("▣", ".Torrent", "Open torrent file", true, onTorrent, Modifier.weight(1f))
        }
    }
}

@Composable
private fun AddDownloadTile(symbol: String, title: String, subtitle: String, active: Boolean, onClick: () -> Unit, modifier: Modifier) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        color = if (active) SoftBlue else AppSurface,
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (active) AppBlue.copy(alpha = 0.25f) else Border)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(symbol, fontSize = 22.sp, color = AppBlue)
            Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(subtitle, color = Muted, fontSize = 9.sp, maxLines = 1)
        }
    }
}

@Composable
private fun QueuePreviewCard(tasks: List<DownloadTask>, onOpenQueue: () -> Unit, onClearCompleted: () -> Unit) {
    PremiumCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("☷", color = DeepNavy, fontSize = 20.sp)
            Spacer(Modifier.width(8.dp))
            Text("Download Queue", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            val activeCount = tasks.count { it.status != DownloadStatus.COMPLETED && it.status != DownloadStatus.CANCELLED }
            Surface(color = SoftBlue, shape = CircleShape) {
                Text(activeCount.toString(), color = AppBlue, modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp), fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(8.dp))
            Text("Clear Completed", color = AppBlue, fontSize = 11.sp, modifier = Modifier.clickable(onClick = onClearCompleted))
        }
        Spacer(Modifier.height(10.dp))
        val preview = tasks.take(3)
        if (preview.isEmpty()) {
            Text("Queue is empty", color = Muted, fontSize = 13.sp)
        } else {
            preview.forEachIndexed { index, task ->
                CompactQueueRow(task)
                if (index != preview.lastIndex) HorizontalDivider(color = Border)
            }
        }
        TextButton(onClick = onOpenQueue, modifier = Modifier.align(Alignment.End)) { Text("Open full queue") }
    }
}

@Composable
private fun CompactQueueRow(task: DownloadTask) {
    val progress = progressOf(task)
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FileBadge(categoryFor(task), 38)
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)) {
            Text(task.fileName ?: shortUrl(task.url), fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${formatBytes(task.downloadedBytes)} / ${formatBytes(task.totalBytes)}", color = Muted, fontSize = 10.sp)
        }
        Column(Modifier.width(120.dp)) {
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                color = AppBlue,
                trackColor = Border
            )
            Spacer(Modifier.height(3.dp))
            Text(statusLabel(task.status), color = Muted, fontSize = 9.sp)
        }
        Spacer(Modifier.width(8.dp))
        Text("${(progress * 100).toInt()}%", color = AppBlue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
private fun LimitsCard(turboMode: Boolean, combineNetworks: Boolean, speedLimitBytesPerSecond: Long, onManage: () -> Unit) {
    val limitLabel = if (speedLimitBytesPerSecond <= 0L) "Unlimited" else formatSpeed(speedLimitBytesPerSecond)
    PremiumCard {
        SectionTitle("Speed Limits", "Manage", onManage)
        Spacer(Modifier.height(6.dp))
        LimitRow("≋", "Download cap", limitLabel, if (speedLimitBytesPerSecond <= 0L) "Using available speed" else "Per-active-file limit")
        HorizontalDivider(color = Border)
        LimitRow("▥", "Mobile Data", if (combineNetworks) "Combined" else "Standby", if (combineNetworks) "Can contribute to downloads" else "Enable in Settings")
    }
}

@Composable
private fun LimitRow(symbol: String, label: String, value: String, subtitle: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(color = SoftBlue, shape = RoundedCornerShape(10.dp)) {
            Text(symbol, modifier = Modifier.padding(9.dp), color = AppBlue, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Text(label, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Column(horizontalAlignment = Alignment.End) {
            Text(value, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(subtitle, color = Muted, fontSize = 9.sp)
        }
        Spacer(Modifier.width(8.dp))
        Text("›", fontSize = 24.sp, color = Muted)
    }
}

private data class DownloadRequestOptions(
    val requestedFileName: String? = null,
    val outputTreeUri: String? = null,
    val scheduledAt: Long? = null,
    val expectedSha256: String? = null
)

private fun formatScheduledTime(millis: Long): String =
    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(millis))

private fun showSchedulePicker(context: Context, current: Long?, onSelected: (Long) -> Unit) {
    val seed = Calendar.getInstance().apply {
        timeInMillis = current ?: (System.currentTimeMillis() + 60L * 60L * 1000L)
    }
    val dialogTheme = if (AppDarkModeState) android.R.style.Theme_Material_Dialog_Alert else android.R.style.Theme_Material_Light_Dialog_Alert
    val dateDialog = DatePickerDialog(
        context,
        dialogTheme,
        { _, year, month, dayOfMonth ->
            val timeDialog = TimePickerDialog(
                context,
                dialogTheme,
                { _, hourOfDay, minute ->
                    val selected = Calendar.getInstance().apply {
                        set(Calendar.YEAR, year)
                        set(Calendar.MONTH, month)
                        set(Calendar.DAY_OF_MONTH, dayOfMonth)
                        set(Calendar.HOUR_OF_DAY, hourOfDay)
                        set(Calendar.MINUTE, minute)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }.timeInMillis
                    onSelected(selected.coerceAtLeast(System.currentTimeMillis() + 60_000L))
                },
                seed.get(Calendar.HOUR_OF_DAY),
                seed.get(Calendar.MINUTE),
                false
            )
            timeDialog.show()
        },
        seed.get(Calendar.YEAR),
        seed.get(Calendar.MONTH),
        seed.get(Calendar.DAY_OF_MONTH)
    )
    dateDialog.datePicker.minDate = System.currentTimeMillis() - 1_000L
    dateDialog.show()
}

private fun folderLabel(uri: Uri): String {
    val raw = runCatching { android.provider.DocumentsContract.getTreeDocumentId(uri) }.getOrNull().orEmpty()
    val path = raw.substringAfter(':', raw).replace("/", " › ").ifBlank { "Selected folder" }
    return "Custom • $path"
}

private data class BrowserDownloadRequest(
    val url: String,
    val cookie: String?,
    val referer: String?,
    val userAgent: String?
)

private data class BrowserGeoPermissionPrompt(
    val origin: String,
    val callback: GeolocationPermissions.Callback
)

private fun androidPermissionForWebResource(resource: String): String? = when (resource) {
    PermissionRequest.RESOURCE_VIDEO_CAPTURE -> Manifest.permission.CAMERA
    PermissionRequest.RESOURCE_AUDIO_CAPTURE -> Manifest.permission.RECORD_AUDIO
    else -> null
}

private fun supportedWebResources(resources: Array<String>): Array<String> =
    resources.filter { androidPermissionForWebResource(it) != null }.toTypedArray()

private fun webPermissionSummary(resources: Array<String>): String {
    val labels = resources.mapNotNull {
        when (it) {
            PermissionRequest.RESOURCE_VIDEO_CAPTURE -> "camera"
            PermissionRequest.RESOURCE_AUDIO_CAPTURE -> "microphone"
            else -> null
        }
    }.distinct()
    return labels.joinToString(" and ").ifBlank { "site permissions" }
}

private data class BrowserSavedPage(
    val title: String,
    val url: String,
    val savedAt: Long
)

private data class BrowserMediaItem(
    val url: String,
    val kind: String,
    val label: String,
    val detectedAt: Long = System.currentTimeMillis()
)

private class BrowserTabState(
    val id: Long,
    val webView: WebView,
    initialUrl: String,
    val isPrivate: Boolean = false
) {
    var address by mutableStateOf(initialUrl)
    var currentUrl by mutableStateOf(initialUrl)
    var pageTitle by mutableStateOf("New tab")
    var canGoBack by mutableStateOf(false)
    var canGoForward by mutableStateOf(false)
    var isLoading by mutableStateOf(false)
    var pageProgress by mutableStateOf(0)
    var detectedMedia by mutableStateOf<List<BrowserMediaItem>>(emptyList())
    var blockedAds by mutableStateOf(0)
    var blockedTrackers by mutableStateOf(0)
    @Volatile var shieldSiteHost: String = browserSiteHost(initialUrl)

    val blockedRequests: Int get() = blockedAds + blockedTrackers

    fun markBlocked(reason: BrowserBlockReason) {
        when (reason) {
            BrowserBlockReason.AD -> blockedAds += 1
            BrowserBlockReason.TRACKER -> blockedTrackers += 1
        }
    }

    fun resetShieldCounters() {
        blockedAds = 0
        blockedTrackers = 0
    }

    fun addDetectedMedia(item: BrowserMediaItem) {
        if (detectedMedia.any { it.url == item.url }) return
        detectedMedia = (listOf(item) + detectedMedia).take(40)
    }

    fun clearDetectedMedia() {
        detectedMedia = emptyList()
    }
}

private fun detectBrowserMediaCandidate(rawUrl: String): BrowserMediaItem? {
    val url = rawUrl.trim()
    if (!url.startsWith("http://", true) && !url.startsWith("https://", true)) return null
    val lower = url.lowercase(Locale.US)
    val path = runCatching { Uri.parse(url).path.orEmpty().lowercase(Locale.US) }.getOrDefault("")
    val host = browserDisplayHost(url)
    val tail = runCatching { Uri.parse(url).lastPathSegment.orEmpty() }.getOrDefault("")
    val label = tail.takeIf { it.isNotBlank() } ?: host.ifBlank { "Media" }

    return when {
        path.endsWith(".m3u8") || lower.contains(".m3u8?") || lower.contains("format=m3u8") || lower.contains("type=m3u8") ->
            BrowserMediaItem(url = url, kind = "HLS", label = label)
        listOf(".mp4", ".webm", ".m4v", ".mov", ".mkv").any(path::endsWith) ->
            BrowserMediaItem(url = url, kind = "Video", label = label)
        listOf(".mp3", ".m4a", ".aac", ".flac", ".wav", ".ogg", ".opus").any(path::endsWith) ->
            BrowserMediaItem(url = url, kind = "Audio", label = label)
        else -> null
    }
}

private fun scanBrowserPageMedia(webView: WebView, tab: BrowserTabState) {
    val script = """
        (function() {
          const out = [];
          const add = (value) => {
            try {
              if (!value || typeof value !== 'string' || value.startsWith('blob:')) return;
              const absolute = new URL(value, document.baseURI).href;
              if (!out.includes(absolute)) out.push(absolute);
            } catch (e) {}
          };
          document.querySelectorAll('video,audio,source').forEach((node) => {
            add(node.currentSrc);
            add(node.src);
          });
          try {
            performance.getEntriesByType('resource').forEach((entry) => {
              const value = entry && entry.name ? entry.name : '';
              if (/\.m3u8(?:[?#]|$)|\.(?:mp4|webm|m4v|mov|mkv|mp3|m4a|aac|flac|wav|ogg|opus)(?:[?#]|$)/i.test(value)) add(value);
            });
          } catch (e) {}
          return out.slice(-40);
        })();
    """.trimIndent()

    runCatching {
        webView.evaluateJavascript(script) { result ->
            runCatching {
                val array = org.json.JSONArray(result)
                for (index in 0 until array.length()) {
                    val item = detectBrowserMediaCandidate(array.optString(index)) ?: continue
                    tab.addDetectedMedia(item)
                }
            }
        }
    }
}

private fun loadBrowserSavedPages(
    prefs: android.content.SharedPreferences,
    key: String
): List<BrowserSavedPage> = runCatching {
    val raw = prefs.getString(key, "[]") ?: "[]"
    val array = org.json.JSONArray(raw)
    buildList {
        for (index in 0 until array.length()) {
            val item = array.optJSONObject(index) ?: continue
            val url = item.optString("url")
            if (url.isBlank()) continue
            add(
                BrowserSavedPage(
                    title = item.optString("title").ifBlank { browserDisplayHost(url) },
                    url = url,
                    savedAt = item.optLong("savedAt", 0L)
                )
            )
        }
    }
}.getOrDefault(emptyList())

private fun saveBrowserSavedPages(
    prefs: android.content.SharedPreferences,
    key: String,
    pages: List<BrowserSavedPage>
) {
    runCatching {
        val array = org.json.JSONArray()
        pages.forEach { page ->
            array.put(
                org.json.JSONObject().apply {
                    put("title", page.title)
                    put("url", page.url)
                    put("savedAt", page.savedAt)
                }
            )
        }
        prefs.edit().putString(key, array.toString()).apply()
    }
}

private const val BROWSER_TEXT_ZOOM_KEY = "browser_text_zoom"

private fun browserTextZoom(prefs: android.content.SharedPreferences): Int =
    prefs.getInt(BROWSER_TEXT_ZOOM_KEY, 100).coerceIn(75, 150)

private fun openSafeExternalBrowserTarget(context: Context, target: String, webView: WebView): Boolean {
    val raw = target.trim()
    if (raw.isBlank()) return false
    val lower = raw.lowercase(Locale.US)
    if (lower.startsWith("http://") || lower.startsWith("https://")) return false

    // Keep browser-owned and script/data URLs inside WebView. blob: is handled by the page itself.
    if (lower.startsWith("about:") || lower.startsWith("javascript:") ||
        lower.startsWith("data:") || lower.startsWith("blob:") || lower.startsWith("file:")) {
        return false
    }

    if (lower.startsWith("intent://")) {
        val parsed = runCatching { Intent.parseUri(raw, Intent.URI_INTENT_SCHEME) }.getOrNull()
            ?: return true
        val fallback = parsed.getStringExtra("browser_fallback_url")
        parsed.addCategory(Intent.CATEGORY_BROWSABLE)
        parsed.component = null
        parsed.selector = null
        parsed.removeExtra("browser_fallback_url")
        val canOpen = parsed.resolveActivity(context.packageManager) != null
        if (canOpen) {
            runCatching { context.startActivity(parsed) }
        } else if (!fallback.isNullOrBlank() &&
            (fallback.startsWith("https://", true) || fallback.startsWith("http://", true))) {
            webView.loadUrl(fallback)
        }
        return true
    }

    val uri = runCatching { Uri.parse(raw) }.getOrNull() ?: return true
    val scheme = uri.scheme?.lowercase(Locale.US).orEmpty()
    val externalIntent = when (scheme) {
        "tel" -> Intent(Intent.ACTION_DIAL, uri)
        "mailto", "sms", "smsto", "mms", "mmsto" -> Intent(Intent.ACTION_SENDTO, uri)
        else -> Intent(Intent.ACTION_VIEW, uri)
    }.apply {
        addCategory(Intent.CATEGORY_BROWSABLE)
        component = null
        selector = null
    }
    if (externalIntent.resolveActivity(context.packageManager) != null) {
        runCatching {
            context.startActivity(Intent.createChooser(externalIntent, "Open with"))
        }
    }
    // Consume non-web schemes even if no compatible app is installed so WebView does not show ERR_UNKNOWN_URL_SCHEME.
    return true
}

private fun showBrowserLongPressMenu(
    context: Context,
    tab: BrowserTabState,
    target: String,
    onOpenNewTab: (String, Boolean) -> Unit,
    onDownloadRequest: (BrowserDownloadRequest) -> Unit
) {
    if (!target.startsWith("http://", true) && !target.startsWith("https://", true)) return

    val primaryOpenLabel = if (tab.isPrivate) "Open in private tab" else "Open in new tab"
    val labels = buildList {
        add(primaryOpenLabel)
        if (!tab.isPrivate) add("Open in private tab")
        add("Copy link")
        add("Share link")
        add("Download link")
    }
    val dialogStyle = if (AppDarkModeState) android.R.style.Theme_Material_Dialog_Alert else android.R.style.Theme_Material_Light_Dialog_Alert
    PlatformAlertDialog.Builder(context, dialogStyle)
        .setTitle(browserDisplayHost(target).ifBlank { "Link actions" })
        .setItems(labels.toTypedArray()) { _, index ->
            var cursor = 0
            if (index == cursor++) {
                onOpenNewTab(target, tab.isPrivate)
                return@setItems
            }
            if (!tab.isPrivate) {
                if (index == cursor++) {
                    onOpenNewTab(target, true)
                    return@setItems
                }
            }
            if (index == cursor++) {
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("MultiFetch link", target))
                return@setItems
            }
            if (index == cursor++) {
                shareBrowserUrl(context, target)
                return@setItems
            }
            if (index == cursor) {
                val referer = tab.currentUrl.takeIf {
                    it.startsWith("http://", true) || it.startsWith("https://", true)
                }
                onDownloadRequest(
                    BrowserDownloadRequest(
                        url = target,
                        cookie = runCatching { CookieManager.getInstance().getCookie(target) }.getOrNull(),
                        referer = referer,
                        userAgent = tab.webView.settings.userAgentString
                    )
                )
            }
        }
        .show()
}

@SuppressLint("SetJavaScriptEnabled")
private fun createBrowserTab(
    context: Context,
    id: Long,
    startUrl: String,
    desktopMode: Boolean,
    isPrivate: Boolean = false,
    browserPrefs: android.content.SharedPreferences,
    onDownloadRequest: (BrowserDownloadRequest) -> Unit,
    onHistoryVisit: (String, String) -> Unit,
    onOpenNewTab: (String, Boolean) -> Unit,
    onShowFileChooser: (ValueCallback<Array<Uri>>, WebChromeClient.FileChooserParams) -> Boolean,
    onWebPermissionRequest: (PermissionRequest) -> Unit,
    onGeolocationPermissionRequest: (String, GeolocationPermissions.Callback) -> Unit,
    onShowFullscreen: (View, WebChromeClient.CustomViewCallback) -> Unit,
    onHideFullscreen: () -> Unit
): BrowserTabState {
    lateinit var tab: BrowserTabState
    val webView = WebView(context)
    tab = BrowserTabState(id, webView, startUrl, isPrivate)

    fun browserDownloadRequest(target: String, userAgentOverride: String? = null): BrowserDownloadRequest {
        val referer = tab.currentUrl.takeIf {
            it.startsWith("http://", true) || it.startsWith("https://", true)
        }
        return BrowserDownloadRequest(
            url = target,
            cookie = runCatching { CookieManager.getInstance().getCookie(target) }.getOrNull(),
            referer = referer,
            userAgent = userAgentOverride?.takeIf { it.isNotBlank() } ?: webView.settings.userAgentString
        )
    }

    webView.apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.geolocationEnabled = true
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.setSupportMultipleWindows(true)
        settings.javaScriptCanOpenWindowsAutomatically = true
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.textZoom = browserTextZoom(browserPrefs)
        if (isPrivate) {
            settings.cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
            settings.saveFormData = false
        }
        settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
        settings.safeBrowsingEnabled = true
        settings.userAgentString = if (desktopMode) desktopUserAgent() else android.webkit.WebSettings.getDefaultUserAgent(context)
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, false)

        setOnLongClickListener {
            val result = hitTestResult ?: return@setOnLongClickListener false
            val supported = result.type == WebView.HitTestResult.SRC_ANCHOR_TYPE ||
                result.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE ||
                result.type == WebView.HitTestResult.IMAGE_TYPE
            val target = result.extra?.trim().orEmpty()
            if (!supported || (!target.startsWith("http://", true) && !target.startsWith("https://", true))) {
                return@setOnLongClickListener false
            }
            showBrowserLongPressMenu(
                context = context,
                tab = tab,
                target = target,
                onOpenNewTab = onOpenNewTab,
                onDownloadRequest = onDownloadRequest
            )
            true
        }

        webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                tab.pageProgress = newProgress.coerceIn(0, 100)
                tab.isLoading = newProgress < 100
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                tab.pageTitle = title?.takeIf { it.isNotBlank() } ?: browserDisplayHost(tab.currentUrl)
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                val callback = filePathCallback ?: return false
                val params = fileChooserParams ?: return false
                return onShowFileChooser(callback, params)
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                val pending = request ?: return
                onWebPermissionRequest(pending)
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                if (origin.isNullOrBlank() || callback == null) {
                    callback?.invoke(origin.orEmpty(), false, false)
                    return
                }
                onGeolocationPermissionRequest(origin, callback)
            }

            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean {
                if (!isUserGesture || resultMsg == null) return false
                val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
                val popupCapture = WebView(context).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    webViewClient = object : WebViewClient() {
                        private var handedOff = false

                        private fun handOff(sourceView: WebView?, target: String?) {
                            if (handedOff) return
                            val url = target.orEmpty()
                            if (!url.startsWith("http://", true) && !url.startsWith("https://", true)) return
                            handedOff = true
                            onOpenNewTab(url, tab.isPrivate)
                            sourceView?.stopLoading()
                            sourceView?.post { sourceView.destroy() }
                        }

                        override fun shouldOverrideUrlLoading(
                            view: WebView?,
                            request: WebResourceRequest?
                        ): Boolean {
                            handOff(view, request?.url?.toString())
                            return handedOff
                        }

                        override fun onPageStarted(
                            view: WebView?,
                            url: String?,
                            favicon: android.graphics.Bitmap?
                        ) {
                            handOff(view, url)
                        }
                    }
                }
                transport.webView = popupCapture
                resultMsg.sendToTarget()
                return true
            }

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (view == null || callback == null) {
                    callback?.onCustomViewHidden()
                    return
                }
                onShowFullscreen(view, callback)
            }

            override fun onHideCustomView() {
                onHideFullscreen()
            }
        }

        webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): android.webkit.WebResourceResponse? {
                val target = request?.url?.toString().orEmpty()
                detectBrowserMediaCandidate(target)?.let { media ->
                    webView.post { tab.addDetectedMedia(media) }
                }
                val blockReason = BrowserShield.blockReason(
                    requestUrl = target,
                    topLevelHost = tab.shieldSiteHost,
                    isMainFrame = request?.isForMainFrame == true,
                    prefs = browserPrefs
                )
                if (blockReason != null) {
                    webView.post { tab.markBlocked(blockReason) }
                    return blockedBrowserResponse()
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val target = request?.url?.toString().orEmpty()
                if (request?.isForMainFrame == true) {
                    if (openSafeExternalBrowserTarget(context, target, webView)) return true
                    if (request?.hasGesture() == true && looksLikeDirectDownload(target)) {
                        onDownloadRequest(browserDownloadRequest(target))
                        return true
                    }
                }
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                tab.isLoading = true
                tab.resetShieldCounters()
                url?.let {
                    if (it != tab.currentUrl) tab.clearDetectedMedia()
                    tab.currentUrl = it
                    tab.address = it
                    tab.shieldSiteHost = browserSiteHost(it)
                    if (!tab.isPrivate) browserPrefs.edit().putString("last_url", it).apply()
                }
                tab.canGoBack = canGoBack()
                tab.canGoForward = canGoForward()
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                tab.isLoading = false
                tab.pageProgress = 100
                url?.let {
                    tab.currentUrl = it
                    tab.address = it
                    if (!tab.isPrivate) {
                        browserPrefs.edit().putString("last_url", it).apply()
                        if (it.startsWith("http://", true) || it.startsWith("https://", true)) {
                            onHistoryVisit(tab.pageTitle.ifBlank { browserDisplayHost(it) }, it)
                        }
                    }
                }
                tab.canGoBack = canGoBack()
                tab.canGoForward = canGoForward()
                BrowserShield.cosmeticScript(browserPrefs, tab.shieldSiteHost)?.let { script ->
                    view?.evaluateJavascript(script, null)
                }
                view?.postDelayed({ scanBrowserPageMedia(webView, tab) }, 350L)
                view?.postDelayed({ scanBrowserPageMedia(webView, tab) }, 1_500L)
            }
        }

        setDownloadListener { url, userAgent, _, _, _ ->
            if (!url.isNullOrBlank()) {
                detectBrowserMediaCandidate(url)?.let(tab::addDetectedMedia)
                onDownloadRequest(browserDownloadRequest(url, userAgent))
            }
        }

        loadUrl(startUrl)
    }
    return tab
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun BrowserScreen(
    modifier: Modifier,
    onDownloadRequest: (BrowserDownloadRequest) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val browserPrefs = remember { context.getSharedPreferences("multifetch_browser", Context.MODE_PRIVATE) }
    var searchEngine by remember {
        mutableStateOf(BrowserSearchEngine.fromStored(browserPrefs.getString(BrowserShield.KEY_SEARCH_ENGINE, null)))
    }
    val homeUrl = searchEngine.homeUrl
    var desktopMode by remember { mutableStateOf(browserPrefs.getBoolean("desktop_mode", false)) }
    var adBlockEnabled by remember { mutableStateOf(BrowserShield.adBlockEnabled(browserPrefs)) }
    var trackerBlockEnabled by remember { mutableStateOf(BrowserShield.trackerBlockEnabled(browserPrefs)) }
    var textZoom by remember { mutableStateOf(browserTextZoom(browserPrefs)) }
    var shieldRevision by remember { mutableStateOf(0) }
    var pendingFileChooser by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    var fullscreenView by remember { mutableStateOf<View?>(null) }
    var fullscreenCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }
    var openNewTabHandler: (String, Boolean) -> Unit = { _, _ -> }
    var pendingWebPermissionPrompt by remember { mutableStateOf<PermissionRequest?>(null) }
    var pendingWebRuntimeRequest by remember { mutableStateOf<PermissionRequest?>(null) }
    var pendingGeoPermissionPrompt by remember { mutableStateOf<BrowserGeoPermissionPrompt?>(null) }
    var pendingGeoRuntimeRequest by remember { mutableStateOf<BrowserGeoPermissionPrompt?>(null) }

    val webPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val request = pendingWebRuntimeRequest
        pendingWebRuntimeRequest = null
        if (request != null) {
            val allowed = supportedWebResources(request.resources).filter { resource ->
                val permission = androidPermissionForWebResource(resource) ?: return@filter false
                grants[permission] == true ||
                    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
            }.toTypedArray()
            runCatching {
                if (allowed.isNotEmpty()) request.grant(allowed) else request.deny()
            }
        }
    }

    val geolocationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val prompt = pendingGeoRuntimeRequest
        pendingGeoRuntimeRequest = null
        if (prompt != null) {
            val allowed = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            runCatching { prompt.callback.invoke(prompt.origin, allowed, false) }
        }
    }

    fun requestWebsitePermission(request: PermissionRequest) {
        if (supportedWebResources(request.resources).isEmpty()) {
            runCatching { request.deny() }
            return
        }
        pendingWebPermissionPrompt?.let { runCatching { it.deny() } }
        pendingWebPermissionPrompt = request
    }

    fun requestWebsiteGeolocation(origin: String, callback: GeolocationPermissions.Callback) {
        pendingGeoPermissionPrompt?.let { old ->
            runCatching { old.callback.invoke(old.origin, false, false) }
        }
        pendingGeoPermissionPrompt = BrowserGeoPermissionPrompt(origin, callback)
    }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        val callback = pendingFileChooser
        pendingFileChooser = null
        callback?.onReceiveValue(uris.takeIf { it.isNotEmpty() }?.toTypedArray())
    }

    fun launchBrowserFileChooser(
        callback: ValueCallback<Array<Uri>>,
        params: WebChromeClient.FileChooserParams
    ): Boolean {
        pendingFileChooser?.onReceiveValue(null)
        pendingFileChooser = callback
        val mimeTypes = params.acceptTypes
            .flatMap { it.split(',') }
            .map { it.trim() }
            .filter { it.isNotBlank() && it.contains('/') }
            .distinct()
            .ifEmpty { listOf("*/*") }
            .toTypedArray()
        return runCatching {
            filePicker.launch(mimeTypes)
            true
        }.getOrElse {
            pendingFileChooser = null
            callback.onReceiveValue(null)
            false
        }
    }

    fun showBrowserFullscreen(view: View, callback: WebChromeClient.CustomViewCallback) {
        fullscreenCallback?.onCustomViewHidden()
        fullscreenView = view
        fullscreenCallback = callback
    }

    fun hideBrowserFullscreen() {
        fullscreenView = null
        fullscreenCallback = null
    }
    val bookmarks = remember {
        mutableStateListOf<BrowserSavedPage>().apply {
            addAll(loadBrowserSavedPages(browserPrefs, "bookmarks"))
        }
    }
    val history = remember {
        mutableStateListOf<BrowserSavedPage>().apply {
            addAll(loadBrowserSavedPages(browserPrefs, "history"))
        }
    }

    fun recordHistory(title: String, url: String) {
        history.removeAll { it.url == url }
        history.add(0, BrowserSavedPage(title.ifBlank { browserDisplayHost(url) }, url, System.currentTimeMillis()))
        while (history.size > 100) history.removeAt(history.lastIndex)
        saveBrowserSavedPages(browserPrefs, "history", history)
    }

    val restoredUrls = remember {
        runCatching {
            val raw = browserPrefs.getString("open_tabs", null)
            if (raw.isNullOrBlank()) emptyList() else {
                val array = org.json.JSONArray(raw)
                buildList {
                    for (index in 0 until array.length()) {
                        val url = array.optString(index)
                        if (url.startsWith("http://", true) || url.startsWith("https://", true)) add(url)
                    }
                }
            }
        }.getOrDefault(emptyList()).take(12)
    }
    val startupUrls = restoredUrls.ifEmpty { listOf(browserPrefs.getString("last_url", homeUrl) ?: homeUrl) }
    val tabs = remember {
        mutableStateListOf<BrowserTabState>().apply {
            startupUrls.forEachIndexed { index, url ->
                add(
                    createBrowserTab(
                        context = context,
                        id = (index + 1).toLong(),
                        startUrl = url,
                        desktopMode = desktopMode,
                        isPrivate = false,
                        browserPrefs = browserPrefs,
                        onDownloadRequest = onDownloadRequest,
                        onHistoryVisit = ::recordHistory,
                        onOpenNewTab = { url, privateMode -> openNewTabHandler(url, privateMode) },
                        onShowFileChooser = ::launchBrowserFileChooser,
                        onWebPermissionRequest = ::requestWebsitePermission,
                        onGeolocationPermissionRequest = ::requestWebsiteGeolocation,
                        onShowFullscreen = ::showBrowserFullscreen,
                        onHideFullscreen = ::hideBrowserFullscreen
                    )
                )
            }
        }
    }
    val restoredSelected = browserPrefs.getInt("selected_tab_index", 0).coerceIn(0, tabs.lastIndex)
    var selectedTabId by remember { mutableStateOf(tabs[restoredSelected].id) }
    var nextTabId by remember { mutableStateOf((tabs.maxOfOrNull { it.id } ?: 0L) + 1L) }
    var showMenu by remember { mutableStateOf(false) }
    var showFindDialog by remember { mutableStateOf(false) }
    var findQuery by remember { mutableStateOf("") }
    var showTabsDialog by remember { mutableStateOf(false) }
    var showBookmarksDialog by remember { mutableStateOf(false) }
    var showHistoryDialog by remember { mutableStateOf(false) }
    var showMediaDialog by remember { mutableStateOf(false) }
    var showClearBrowsingDataDialog by remember { mutableStateOf(false) }
    var showShieldDialog by remember { mutableStateOf(false) }
    var showSearchEngineDialog by remember { mutableStateOf(false) }
    var showPageControlsDialog by remember { mutableStateOf(false) }

    val tab = tabs.firstOrNull { it.id == selectedTabId } ?: tabs.first()
    val webView = tab.webView
    val currentUrl = tab.currentUrl
    val bookmarked = bookmarks.any { it.url == currentUrl }
    val currentSiteHost = browserSiteHost(currentUrl)
    val shieldAllowedForSite = remember(currentSiteHost, shieldRevision) {
        currentSiteHost.isNotBlank() && BrowserShield.isSiteAllowlisted(browserPrefs, currentSiteHost)
    }

    fun currentDownloadRequest(url: String): BrowserDownloadRequest = BrowserDownloadRequest(
        url = url,
        cookie = runCatching { CookieManager.getInstance().getCookie(url) }.getOrNull(),
        referer = currentUrl.takeIf { it.startsWith("http://", true) || it.startsWith("https://", true) },
        userAgent = webView.settings.userAgentString
    )

    fun openInCurrentTab(url: String) {
        val target = normalizeBrowserInput(url, searchEngine)
        tab.address = target
        webView.loadUrl(target)
    }

    fun createNewTab(url: String = homeUrl, isPrivate: Boolean = false) {
        if (tabs.size >= 12) return
        val id = nextTabId++
        val newTab = createBrowserTab(
            context = context,
            id = id,
            startUrl = url,
            desktopMode = desktopMode,
            isPrivate = isPrivate,
            browserPrefs = browserPrefs,
            onDownloadRequest = onDownloadRequest,
            onHistoryVisit = ::recordHistory,
            onOpenNewTab = { target, privateMode -> openNewTabHandler(target, privateMode) },
            onShowFileChooser = ::launchBrowserFileChooser,
            onWebPermissionRequest = ::requestWebsitePermission,
            onGeolocationPermissionRequest = ::requestWebsiteGeolocation,
            onShowFullscreen = ::showBrowserFullscreen,
            onHideFullscreen = ::hideBrowserFullscreen
        )
        tabs.add(newTab)
        selectedTabId = id
    }

    openNewTabHandler = { url, privateMode -> createNewTab(url, privateMode) }

    fun closeTab(tabId: Long) {
        if (tabs.size <= 1) {
            val only = tabs.first()
            if (only.isPrivate) {
                only.webView.stopLoading()
                only.webView.clearHistory()
                only.webView.clearFormData()
                only.webView.destroy()
                tabs.clear()
                createNewTab(homeUrl, isPrivate = false)
            } else {
                only.webView.clearHistory()
                only.webView.loadUrl(homeUrl)
            }
            return
        }
        val index = tabs.indexOfFirst { it.id == tabId }
        if (index < 0) return
        val closing = tabs[index]
        val wasSelected = selectedTabId == tabId
        tabs.removeAt(index)
        closing.webView.stopLoading()
        closing.webView.destroy()
        if (wasSelected) {
            selectedTabId = tabs.getOrNull(index)?.id ?: tabs.last().id
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            runCatching {
                val persistentTabs = tabs.filterNot { it.isPrivate }
                val session = org.json.JSONArray()
                persistentTabs.forEach { item -> session.put(item.currentUrl.ifBlank { homeUrl }) }
                val selectedIndex = persistentTabs.indexOfFirst { it.id == selectedTabId }.coerceAtLeast(0)
                browserPrefs.edit()
                    .putString("open_tabs", session.toString())
                    .putInt("selected_tab_index", selectedIndex)
                    .apply()
            }
            tabs.forEach {
                it.webView.stopLoading()
                if (it.isPrivate) {
                    it.webView.clearHistory()
                    it.webView.clearFormData()
                }
                it.webView.destroy()
            }
        }
    }

    BackHandler(enabled = fullscreenView != null) {
        fullscreenCallback?.onCustomViewHidden()
        hideBrowserFullscreen()
    }
    BackHandler(enabled = fullscreenView == null && tab.canGoBack) { webView.goBack() }

    pendingWebPermissionPrompt?.let { request ->
        val resources = supportedWebResources(request.resources)
        AlertDialog(
            onDismissRequest = {
                runCatching { request.deny() }
                pendingWebPermissionPrompt = null
            },
            title = { Text("Website permission") },
            text = {
                Text(
                    "${browserDisplayHost(request.origin?.toString().orEmpty())} wants to use your ${webPermissionSummary(resources)}. MultiFetch will ask Android for permission and will not remember this choice.",
                    color = Muted,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(onClick = {
                    pendingWebPermissionPrompt = null
                    val permissions = resources.mapNotNull(::androidPermissionForWebResource).distinct()
                    val alreadyGranted = permissions.all { permission ->
                        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
                    }
                    if (alreadyGranted) {
                        runCatching { request.grant(resources) }
                    } else {
                        pendingWebRuntimeRequest = request
                        runCatching { webPermissionLauncher.launch(permissions.toTypedArray()) }
                            .onFailure {
                                pendingWebRuntimeRequest = null
                                runCatching { request.deny() }
                            }
                    }
                }) { Text("Allow") }
            },
            dismissButton = {
                TextButton(onClick = {
                    runCatching { request.deny() }
                    pendingWebPermissionPrompt = null
                }) { Text("Block") }
            }
        )
    }

    pendingGeoPermissionPrompt?.let { prompt ->
        AlertDialog(
            onDismissRequest = {
                runCatching { prompt.callback.invoke(prompt.origin, false, false) }
                pendingGeoPermissionPrompt = null
            },
            title = { Text("Location permission") },
            text = {
                Text(
                    "${browserDisplayHost(prompt.origin)} wants your location. Android may let you choose approximate or precise location. MultiFetch will not remember this choice.",
                    color = Muted,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(onClick = {
                    pendingGeoPermissionPrompt = null
                    val alreadyGranted =
                        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    if (alreadyGranted) {
                        runCatching { prompt.callback.invoke(prompt.origin, true, false) }
                    } else {
                        pendingGeoRuntimeRequest = prompt
                        runCatching {
                            geolocationPermissionLauncher.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_COARSE_LOCATION,
                                    Manifest.permission.ACCESS_FINE_LOCATION
                                )
                            )
                        }.onFailure {
                            pendingGeoRuntimeRequest = null
                            runCatching { prompt.callback.invoke(prompt.origin, false, false) }
                        }
                    }
                }) { Text("Allow") }
            },
            dismissButton = {
                TextButton(onClick = {
                    runCatching { prompt.callback.invoke(prompt.origin, false, false) }
                    pendingGeoPermissionPrompt = null
                }) { Text("Block") }
            }
        )
    }

    if (showTabsDialog) {
        AlertDialog(
            onDismissRequest = { showTabsDialog = false },
            title = {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Tabs (${tabs.size})", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    TextButton(enabled = tabs.size < 12, onClick = {
                        createNewTab(isPrivate = true)
                        showTabsDialog = false
                    }) { Text("Private") }
                    Button(enabled = tabs.size < 12, onClick = {
                        createNewTab()
                        showTabsDialog = false
                    }) { Text("+ New") }
                }
            },
            text = {
                LazyColumn(modifier = Modifier.fillMaxWidth().height(320.dp)) {
                    items(tabs, key = { it.id }) { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (item.id == selectedTabId) SoftBlue else Color.Transparent)
                                .clickable {
                                    selectedTabId = item.id
                                    showTabsDialog = false
                                }
                                .padding(horizontal = 10.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    item.pageTitle.ifBlank { "New tab" },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    (if (item.isPrivate) "PRIVATE • " else "") + browserDisplayHost(item.currentUrl),
                                    color = if (item.isPrivate) DeepNavy else Muted,
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            TextButton(onClick = { closeTab(item.id) }) { Text("×", fontSize = 20.sp) }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showTabsDialog = false }) { Text("Close") } }
        )
    }

    if (showBookmarksDialog) {
        AlertDialog(
            onDismissRequest = { showBookmarksDialog = false },
            title = { Text("Bookmarks") },
            text = {
                if (bookmarks.isEmpty()) {
                    Text("No bookmarks yet.", color = Muted)
                } else {
                    LazyColumn(modifier = Modifier.fillMaxWidth().height(320.dp)) {
                        items(bookmarks, key = { it.url }) { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable {
                                        openInCurrentTab(item.url)
                                        showBookmarksDialog = false
                                    }
                                    .padding(vertical = 9.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(browserDisplayHost(item.url), color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                TextButton(onClick = {
                                    bookmarks.removeAll { it.url == item.url }
                                    saveBrowserSavedPages(browserPrefs, "bookmarks", bookmarks)
                                }) { Text("Remove", fontSize = 10.sp) }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showBookmarksDialog = false }) { Text("Close") } }
        )
    }

    if (showHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showHistoryDialog = false },
            title = {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("History", modifier = Modifier.weight(1f))
                    if (history.isNotEmpty()) {
                        TextButton(onClick = {
                            history.clear()
                            saveBrowserSavedPages(browserPrefs, "history", history)
                        }) { Text("Clear") }
                    }
                }
            },
            text = {
                if (history.isEmpty()) {
                    Text("No browsing history yet.", color = Muted)
                } else {
                    LazyColumn(modifier = Modifier.fillMaxWidth().height(340.dp)) {
                        items(history, key = { "${it.savedAt}-${it.url}" }) { item ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable {
                                        openInCurrentTab(item.url)
                                        showHistoryDialog = false
                                    }
                                    .padding(vertical = 9.dp, horizontal = 8.dp)
                            ) {
                                Text(item.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(item.url, color = Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showHistoryDialog = false }) { Text("Close") } }
        )
    }

    if (showMediaDialog) {
        AlertDialog(
            onDismissRequest = { showMediaDialog = false },
            title = { Text("Detected media") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        if (tab.detectedMedia.isEmpty()) {
                            "No downloadable media has been detected on this tab yet. Start playback or reload the page, then check again."
                        } else {
                            "MultiFetch detected ${tab.detectedMedia.size} media link${if (tab.detectedMedia.size == 1) "" else "s"}. HLS manifests and direct audio/video links can be sent to the download queue."
                        },
                        color = Muted,
                        fontSize = 12.sp
                    )
                    if (tab.detectedMedia.isNotEmpty()) {
                        LazyColumn(modifier = Modifier.fillMaxWidth().height(340.dp)) {
                            items(tab.detectedMedia, key = { it.url }) { media ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = AppBackground),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                                        verticalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                if (media.kind == "HLS") "▶ HLS" else "▶ ${media.kind}",
                                                color = AppBlue,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                            Spacer(Modifier.width(8.dp))
                                            Text(
                                                media.label,
                                                modifier = Modifier.weight(1f),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        Text(
                                            media.url,
                                            color = Muted,
                                            fontSize = 9.sp,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End
                                        ) {
                                            TextButton(onClick = {
                                                onDownloadRequest(currentDownloadRequest(media.url))
                                                showMediaDialog = false
                                            }) {
                                                Text(if (media.kind == "HLS") "Download HLS" else "Download")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    scanBrowserPageMedia(webView, tab)
                    if (tab.detectedMedia.isEmpty()) {
                        // Keep dialog open so late-loading media can appear without reopening the menu.
                    }
                }) { Text("Scan again") }
            },
            dismissButton = {
                Row {
                    if (tab.detectedMedia.isNotEmpty()) {
                        TextButton(onClick = { tab.clearDetectedMedia() }) { Text("Clear") }
                    }
                    TextButton(onClick = { showMediaDialog = false }) { Text("Close") }
                }
            }
        )
    }

    if (showShieldDialog) {
        AlertDialog(
            onDismissRequest = { showShieldDialog = false },
            title = { Text("Browser Shield") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Blocked on this page: ${tab.blockedAds} ad request${if (tab.blockedAds == 1) "" else "s"} • ${tab.blockedTrackers} tracker request${if (tab.blockedTrackers == 1) "" else "s"}",
                        color = AppBlue,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Text(
                        "MultiFetch blocks known third-party ad/tracker hosts and removes common ad containers after page load. Main pages are never blocked, and you can disable the shield for a site if something breaks.",
                        color = Muted,
                        fontSize = 11.sp
                    )
                    HorizontalDivider(color = Border)
                    SettingToggle(
                        "Block web ads",
                        "Blocks known third-party advertising hosts and removes common ad containers after page load.",
                        adBlockEnabled
                    ) { enabled ->
                        adBlockEnabled = enabled
                        browserPrefs.edit().putBoolean(BrowserShield.KEY_AD_BLOCK, enabled).apply()
                        tab.resetShieldCounters()
                        webView.reload()
                    }
                    HorizontalDivider(color = Border)
                    SettingToggle(
                        "Tracker protection",
                        "Blocks common analytics and tracking hosts while keeping first-party site resources untouched.",
                        trackerBlockEnabled
                    ) { enabled ->
                        trackerBlockEnabled = enabled
                        browserPrefs.edit().putBoolean(BrowserShield.KEY_TRACKER_BLOCK, enabled).apply()
                        tab.resetShieldCounters()
                        webView.reload()
                    }
                    if (currentSiteHost.isNotBlank()) {
                        HorizontalDivider(color = Border)
                        OutlinedButton(
                            onClick = {
                                BrowserShield.setSiteAllowlisted(
                                    browserPrefs,
                                    currentSiteHost,
                                    allowed = !shieldAllowedForSite
                                )
                                shieldRevision += 1
                                tab.resetShieldCounters()
                                webView.reload()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                if (shieldAllowedForSite) {
                                    "Enable shield for $currentSiteHost"
                                } else {
                                    "Disable shield for $currentSiteHost"
                                },
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Text(
                        "Shield also performs best-effort cosmetic cleanup and presses supported video skip-ad controls when they appear. Player-integrated ads can still change and are not claimed to be 100% blockable.",
                        color = Muted,
                        fontSize = 10.sp
                    )
                }
            },
            confirmButton = { TextButton(onClick = { showShieldDialog = false }) { Text("Done") } }
        )
    }

    if (showPageControlsDialog) {
        AlertDialog(
            onDismissRequest = { showPageControlsDialog = false },
            title = { Text("Page controls") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Text size changes page text without changing MultiFetch's app UI. Pinch-to-zoom remains available on supported pages.",
                        color = Muted,
                        fontSize = 12.sp
                    )
                    listOf(80, 100, 120, 140).forEach { value ->
                        if (value == textZoom) {
                            Button(
                                onClick = {
                                    textZoom = value
                                    browserPrefs.edit().putInt(BROWSER_TEXT_ZOOM_KEY, value).apply()
                                    tabs.forEach { it.webView.settings.textZoom = value }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("✓ ${value}% text") }
                        } else {
                            OutlinedButton(
                                onClick = {
                                    textZoom = value
                                    browserPrefs.edit().putInt(BROWSER_TEXT_ZOOM_KEY, value).apply()
                                    tabs.forEach { it.webView.settings.textZoom = value }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("${value}% text") }
                        }
                    }
                    HorizontalDivider(color = Border)
                    Text(
                        "Tip: long-press a web link or image URL for Open in tab, Private tab, Copy, Share and Download actions.",
                        color = Muted,
                        fontSize = 10.sp
                    )
                }
            },
            confirmButton = { TextButton(onClick = { showPageControlsDialog = false }) { Text("Done") } }
        )
    }

    if (showSearchEngineDialog) {
        AlertDialog(
            onDismissRequest = { showSearchEngineDialog = false },
            title = { Text("Search engine") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Choose what MultiFetch uses when text in the address bar is not a URL.",
                        color = Muted,
                        fontSize = 12.sp
                    )
                    BrowserSearchEngine.entries.forEach { engine ->
                        if (engine == searchEngine) {
                            Button(
                                onClick = {
                                    searchEngine = engine
                                    browserPrefs.edit().putString(BrowserShield.KEY_SEARCH_ENGINE, engine.name).apply()
                                    showSearchEngineDialog = false
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("✓ ${engine.label}") }
                        } else {
                            OutlinedButton(
                                onClick = {
                                    searchEngine = engine
                                    browserPrefs.edit().putString(BrowserShield.KEY_SEARCH_ENGINE, engine.name).apply()
                                    showSearchEngineDialog = false
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(engine.label) }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showSearchEngineDialog = false }) { Text("Close") } }
        )
    }

    if (showClearBrowsingDataDialog) {
        AlertDialog(
            onDismissRequest = { showClearBrowsingDataDialog = false },
            title = { Text("Clear browsing data?") },
            text = {
                Text(
                    "This clears browser history, cookies, site storage, form data and WebView cache. Bookmarks and downloads are kept.",
                    color = Muted,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(onClick = {
                    history.clear()
                    saveBrowserSavedPages(browserPrefs, "history", history)
                    browserPrefs.edit()
                        .remove("last_url")
                        .remove("open_tabs")
                        .remove("selected_tab_index")
                        .apply()
                    tabs.forEach { item ->
                        item.webView.clearHistory()
                        item.webView.clearCache(true)
                        item.webView.clearFormData()
                    }
                    CookieManager.getInstance().removeAllCookies(null)
                    CookieManager.getInstance().flush()
                    android.webkit.WebStorage.getInstance().deleteAllData()
                    showClearBrowsingDataDialog = false
                }) { Text("Clear data") }
            },
            dismissButton = { TextButton(onClick = { showClearBrowsingDataDialog = false }) { Text("Cancel") } }
        )
    }

    if (showFindDialog) {
        AlertDialog(
            onDismissRequest = {
                webView.clearMatches()
                showFindDialog = false
            },
            title = { Text("Find on page") },
            text = {
                OutlinedTextField(
                    value = findQuery,
                    onValueChange = {
                        findQuery = it
                        if (it.isBlank()) webView.clearMatches() else webView.findAllAsync(it)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Search text") }
                )
            },
            confirmButton = {
                TextButton(enabled = findQuery.isNotBlank(), onClick = { webView.findNext(true) }) { Text("Next") }
            },
            dismissButton = {
                TextButton(onClick = {
                    webView.clearMatches()
                    showFindDialog = false
                }) { Text("Close") }
            }
        )
    }

    if (showMenu) {
        AlertDialog(
            onDismissRequest = { showMenu = false },
            title = { Text("Browser menu") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    BrowserMenuAction("◐", "New private tab") {
                        showMenu = false
                        createNewTab(isPrivate = true)
                    }
                    BrowserMenuAction("⌫", "Clear browsing data") {
                        showMenu = false
                        showClearBrowsingDataDialog = true
                    }
                    BrowserMenuAction(
                        "🛡",
                        "Browser Shield • ${tab.blockedRequests} blocked"
                    ) {
                        showMenu = false
                        showShieldDialog = true
                    }
                    BrowserMenuAction("⌕", "Search engine • ${searchEngine.label}") {
                        showMenu = false
                        showSearchEngineDialog = true
                    }
                    BrowserMenuAction("Aa", "Page controls • ${textZoom}% text") {
                        showMenu = false
                        showPageControlsDialog = true
                    }
                    BrowserMenuAction("★", if (bookmarked) "Remove bookmark" else "Add bookmark") {
                        if (bookmarked) {
                            bookmarks.removeAll { it.url == currentUrl }
                        } else if (currentUrl.isNotBlank()) {
                            bookmarks.add(0, BrowserSavedPage(tab.pageTitle.ifBlank { browserDisplayHost(currentUrl) }, currentUrl, System.currentTimeMillis()))
                        }
                        saveBrowserSavedPages(browserPrefs, "bookmarks", bookmarks)
                        showMenu = false
                    }
                    BrowserMenuAction("▤", "Bookmarks") {
                        showMenu = false
                        showBookmarksDialog = true
                    }
                    BrowserMenuAction("◷", "History") {
                        showMenu = false
                        showHistoryDialog = true
                    }
                    BrowserMenuAction("▶", "Media detector (${tab.detectedMedia.size})") {
                        showMenu = false
                        scanBrowserPageMedia(webView, tab)
                        showMediaDialog = true
                    }
                    BrowserMenuAction("⬇", "Download this URL") {
                        showMenu = false
                        if (currentUrl.isNotBlank()) onDownloadRequest(currentDownloadRequest(currentUrl))
                    }
                    BrowserMenuAction("⌕", "Find on page") {
                        showMenu = false
                        showFindDialog = true
                    }
                    BrowserMenuAction("▣", if (desktopMode) "Use mobile site" else "Desktop site") {
                        desktopMode = !desktopMode
                        browserPrefs.edit().putBoolean("desktop_mode", desktopMode).apply()
                        tabs.forEach { item ->
                            item.webView.settings.userAgentString = if (desktopMode) desktopUserAgent() else android.webkit.WebSettings.getDefaultUserAgent(context)
                        }
                        showMenu = false
                        webView.reload()
                    }
                    BrowserMenuAction("⧉", "Copy link") {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("MultiFetch URL", currentUrl))
                        showMenu = false
                    }
                    BrowserMenuAction("↗", "Share page") {
                        shareBrowserUrl(context, currentUrl)
                        showMenu = false
                    }
                    BrowserMenuAction("◉", "Open in another browser") {
                        openBrowserExternally(context, currentUrl)
                        showMenu = false
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showMenu = false }) { Text("Close") } }
        )
    }

    val activeFullscreenView = fullscreenView
    if (activeFullscreenView != null) {
        Surface(modifier = modifier.fillMaxSize(), color = Color.Black) {
            AndroidView(
                factory = { activeFullscreenView },
                modifier = Modifier.fillMaxSize()
            )
        }
        return
    }

    Column(
        modifier = modifier.fillMaxSize().background(AppBackground),
        verticalArrangement = Arrangement.spacedBy(0.dp)
    ) {
        Surface(modifier = Modifier.fillMaxWidth(), color = AppSurface, shadowElevation = 2.dp) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            tab.pageTitle.ifBlank { "Browser" },
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = DeepNavy,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                when {
                                    tab.isPrivate -> "◐ Private"
                                    currentUrl.startsWith("https://", true) -> "● Secure"
                                    else -> "○ Web"
                                },
                                color = when {
                                    tab.isPrivate -> DeepNavy
                                    currentUrl.startsWith("https://", true) -> Success
                                    else -> Muted
                                },
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "  ${browserDisplayHost(currentUrl)}${if (desktopMode) "  • Desktop" else ""}",
                                color = Muted,
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    TextButton(onClick = { showShieldDialog = true }) {
                        Text(
                            "🛡 ${tab.blockedRequests}",
                            fontSize = 12.sp,
                            color = if (shieldAllowedForSite) Muted else AppBlue,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (tab.detectedMedia.isNotEmpty()) {
                        TextButton(onClick = { showMediaDialog = true }) {
                            Text("▶ ${tab.detectedMedia.size}", fontSize = 13.sp, color = AppBlue, fontWeight = FontWeight.Bold)
                        }
                    }
                    TextButton(onClick = { showTabsDialog = true }) {
                        Text("▢ ${tabs.size}", fontSize = 15.sp, color = DeepNavy, fontWeight = FontWeight.Bold)
                    }
                    TextButton(onClick = { showMenu = true }) { Text("⋮", fontSize = 26.sp, color = DeepNavy) }
                }

                Spacer(Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(AppBackground)
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (tab.isPrivate) "◐" else if (currentUrl.startsWith("https://", true)) "🔒" else "🌐",
                        modifier = Modifier.padding(start = 6.dp, end = 2.dp),
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = tab.address,
                        onValueChange = { tab.address = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        placeholder = { Text("Search with ${searchEngine.label} or enter address") }
                    )
                    Button(
                        modifier = Modifier.padding(horizontal = 4.dp),
                        onClick = { openInCurrentTab(tab.address) }
                    ) { Text("Go") }
                }
            }
        }

        if (tab.isLoading || tab.pageProgress in 1..99) {
            LinearProgressIndicator(
                progress = { tab.pageProgress.coerceIn(0, 100) / 100f },
                modifier = Modifier.fillMaxWidth().height(3.dp),
                color = AppBlue,
                trackColor = SoftBlue
            )
        } else {
            Spacer(Modifier.height(3.dp))
        }

        Surface(modifier = Modifier.fillMaxWidth().weight(1f), color = AppSurface) {
            androidx.compose.runtime.key(selectedTabId) {
                AndroidView(factory = { webView }, modifier = Modifier.fillMaxSize())
            }
        }

        Surface(modifier = Modifier.fillMaxWidth(), color = AppSurface, shadowElevation = 5.dp) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                BrowserToolbarButton("‹", "Back", tab.canGoBack) { webView.goBack() }
                BrowserToolbarButton("›", "Forward", tab.canGoForward) { webView.goForward() }
                BrowserToolbarButton("+", "New tab", tabs.size < 12) { createNewTab() }
                BrowserToolbarButton(if (tab.isLoading) "×" else "↻", if (tab.isLoading) "Stop" else "Reload", true) {
                    if (tab.isLoading) webView.stopLoading() else webView.reload()
                }
                BrowserToolbarButton("▢", "Tabs", true) { showTabsDialog = true }
            }
        }
    }
}

@Composable
private fun BrowserToolbarButton(
    symbol: String,
    label: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    TextButton(enabled = enabled, onClick = onClick) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(symbol, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text(label, fontSize = 8.sp)
        }
    }
}

@Composable
private fun BrowserMenuAction(symbol: String, label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(color = SoftBlue, shape = RoundedCornerShape(10.dp)) {
            Text(symbol, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp), color = AppBlue, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DeepNavy)
    }
}

private fun desktopUserAgent(): String =
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"

private fun browserDisplayHost(url: String): String {
    return runCatching {
        Uri.parse(url).host?.removePrefix("www.")?.takeIf { it.isNotBlank() }
    }.getOrNull() ?: "multifetch browser"
}

private fun shareBrowserUrl(context: Context, url: String) {
    if (url.isBlank()) return
    runCatching {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, url)
        }
        context.startActivity(Intent.createChooser(intent, "Share page"))
    }
}

private fun openBrowserExternally(context: Context, url: String) {
    if (url.isBlank()) return
    runCatching {
        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW, Uri.parse(url)), "Open page with"))
    }
}

private fun looksLikeDirectDownload(url: String): Boolean {
    if (!url.startsWith("http://", true) && !url.startsWith("https://", true)) return false
    val path = runCatching { Uri.parse(url).lastPathSegment.orEmpty().lowercase() }.getOrDefault("")
    val extensions = listOf(
        ".apk", ".zip", ".rar", ".7z", ".tar", ".gz", ".iso",
        ".mp4", ".mkv", ".webm", ".m3u8", ".mp3", ".m4a", ".flac",
        ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
        ".exe", ".msi", ".dmg", ".torrent"
    )
    return extensions.any(path::endsWith)
}

private fun normalizeBrowserInput(raw: String, searchEngine: BrowserSearchEngine): String {
    val value = raw.trim()
    if (value.isBlank()) return searchEngine.homeUrl
    if (value.startsWith("http://", ignoreCase = true) || value.startsWith("https://", ignoreCase = true)) {
        return value
    }
    return if (!value.contains(' ') && value.contains('.')) {
        "https://$value"
    } else {
        searchEngine.searchPrefix + Uri.encode(value)
    }
}

@Composable
private fun QueueScreen(
    modifier: Modifier,
    tasks: List<DownloadTask>,
    onPause: (String) -> Unit,
    onResume: (String) -> Unit,
    onCancel: (String) -> Unit,
    onRetry: (String) -> Unit,
    onOpen: (DownloadTask) -> Unit,
    onShare: (DownloadTask) -> Unit,
    onDelete: (DownloadTask) -> Unit,
    onSetPriority: (String, Int) -> Unit,
    onPauseAll: () -> Unit,
    onResumeAll: () -> Unit,
    onClearCompleted: () -> Unit,
    searchQuery: String,
    onClearSearch: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var queueFilter by remember { mutableStateOf(QueueFilter.ALL) }
    var selectedTask by remember { mutableStateOf<DownloadTask?>(null) }

    val searchedTasks = if (searchQuery.isBlank()) {
        tasks
    } else {
        tasks.filter { task ->
            task.fileName.orEmpty().contains(searchQuery, ignoreCase = true) ||
                task.url.contains(searchQuery, ignoreCase = true) ||
                task.status.name.contains(searchQuery, ignoreCase = true)
        }
    }
    val visibleTasks = searchedTasks.filter { task ->
        when (queueFilter) {
            QueueFilter.ALL -> true
            QueueFilter.ACTIVE -> task.status in setOf(
                DownloadStatus.QUEUED,
                DownloadStatus.DOWNLOADING,
                DownloadStatus.PAUSED
            )
            QueueFilter.COMPLETED -> task.status == DownloadStatus.COMPLETED
            QueueFilter.ISSUES -> task.status == DownloadStatus.FAILED || task.status == DownloadStatus.CANCELLED
        }
    }.sortedWith(
        compareByDescending<DownloadTask> {
            if (it.status == DownloadStatus.QUEUED) it.priority else -1
        }.thenByDescending { it.createdAt }
    )

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 30.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            BrandSubHeader("Queue", "Persistent downloads, resume & history")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = onPauseAll, modifier = Modifier.weight(1f)) { Text("Pause all") }
                FilledTonalButton(onClick = onResumeAll, modifier = Modifier.weight(1f)) { Text("Resume all") }
                TextButton(onClick = onClearCompleted) { Text("Clear") }
            }
            if (tasks.any { it.status == DownloadStatus.FAILED || it.status == DownloadStatus.CANCELLED }) {
                TextButton(onClick = {
                    tasks.filter { it.status == DownloadStatus.FAILED || it.status == DownloadStatus.CANCELLED }
                        .forEach { onRetry(it.id) }
                }) { Text("Retry all issues") }
            }
        }
        item {
            PremiumCard {
                val activeCount = tasks.count { it.status in setOf(DownloadStatus.QUEUED, DownloadStatus.DOWNLOADING, DownloadStatus.PAUSED) }
                val doneCount = tasks.count { it.status == DownloadStatus.COMPLETED }
                val issueCount = tasks.count { it.status == DownloadStatus.FAILED || it.status == DownloadStatus.CANCELLED }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${tasks.size} total", color = DeepNavy, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("$activeCount active", color = AppBlue, fontSize = 11.sp)
                    Text("$doneCount done", color = Success, fontSize = 11.sp)
                    Text("$issueCount issues", color = Muted, fontSize = 11.sp)
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    QueueFilter.entries.forEach { option ->
                        if (queueFilter == option) {
                            FilledTonalButton(
                                onClick = { queueFilter = option },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                            ) { Text(option.label, fontSize = 10.sp) }
                        } else {
                            OutlinedButton(
                                onClick = { queueFilter = option },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                            ) { Text(option.label, fontSize = 10.sp) }
                        }
                    }
                }
            }
        }
        if (searchQuery.isNotBlank()) {
            item {
                Surface(color = SoftBlue, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Search: $searchQuery", modifier = Modifier.weight(1f), fontSize = 12.sp)
                        TextButton(onClick = onClearSearch) { Text("Clear") }
                    }
                }
            }
        }
        if (visibleTasks.isEmpty()) {
            item {
                PremiumCard {
                    Text(
                        when {
                            searchQuery.isNotBlank() -> "No downloads match your search/filter."
                            queueFilter != QueueFilter.ALL -> "No downloads in ${queueFilter.label.lowercase(Locale.US)}."
                            else -> "No downloads yet."
                        },
                        color = Muted
                    )
                }
            }
        } else {
            items(visibleTasks, key = { it.id }) { task ->
                FullQueueCard(
                    task = task,
                    onPause = onPause,
                    onResume = onResume,
                    onCancel = onCancel,
                    onRetry = onRetry,
                    onOpen = onOpen,
                    onShare = onShare,
                    onDelete = onDelete,
                    onSetPriority = onSetPriority,
                    onDetails = { selectedTask = it }
                )
            }
        }
    }

    selectedTask?.let { task ->
        val speed = parseSpeedBytesPerSecond(task.message)
        AlertDialog(
            onDismissRequest = { selectedTask = null },
            title = { Text("Download details", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(task.fileName ?: shortUrl(task.url), fontWeight = FontWeight.Bold, color = DeepNavy)
                    DiagnosticRow("Status", statusLabel(task.status))
                    DiagnosticRow("Priority", priorityLabel(task.priority))
                    task.scheduledAt?.let { DiagnosticRow("Scheduled", formatScheduledTime(it)) }
                    task.requestedFileName?.takeIf { it.isNotBlank() }?.let { DiagnosticRow("Requested name", it) }
                    DiagnosticRow(
                        "Save folder",
                        if (TorrentDownloadEngine.isTorrentSource(task.url)) "Downloads/MultiFetch/Torrents"
                        else if (task.outputTreeUri.isNullOrBlank()) "Downloads/MultiFetch" else "Custom folder"
                    )
                    task.expectedSha256?.let { DiagnosticRow("SHA-256 expected", shortSha256(it)) }
                    task.actualSha256?.let { DiagnosticRow("SHA-256 verified", shortSha256(it)) }
                    if (TorrentDownloadEngine.isTorrentSource(task.url) && task.status == DownloadStatus.COMPLETED) {
                        DiagnosticRow("Integrity", "BitTorrent piece hashes verified")
                    }
                    DiagnosticRow("Server", serverHost(task.url))
                    DiagnosticRow("Downloaded", "${formatBytes(task.downloadedBytes)} / ${formatBytes(task.totalBytes)}")
                    DiagnosticRow("Progress", "${(progressOf(task) * 100).toInt()}%")
                    DiagnosticRow("Chunks", task.segmentCount.toString())
                    if (speed > 0L) DiagnosticRow("Current speed", formatSpeed(speed))
                    etaFor(task, speed)?.let { DiagnosticRow("ETA", it) }
                    Spacer(Modifier.height(4.dp))
                    Text(if (TorrentDownloadEngine.isTorrentSource(task.url)) "Source" else "URL", color = Muted, fontSize = 10.sp)
                    Text(displayDownloadSource(task.url), color = DeepNavy, fontSize = 11.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)
                    if (task.outputUri != null) {
                        Text(if (task.outputTreeUri.isNullOrBlank()) "Saved file is linked to Android Downloads/MultiFetch." else "Saved file is linked to the custom folder selected when it was queued.", color = Muted, fontSize = 10.sp)
                    }
                }
            },
            confirmButton = {
                Row {
                    task.actualSha256?.let { hash ->
                        TextButton(onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("SHA-256", hash))
                        }) { Text("Copy SHA") }
                    }
                    if (!task.url.startsWith(TorrentDownloadEngine.TORRENT_FILE_PREFIX, ignoreCase = true)) {
                        TextButton(onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("MultiFetch download source", task.url))
                        }) { Text(if (task.url.startsWith("magnet:", ignoreCase = true)) "Copy Magnet" else "Copy URL") }
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedTask = null }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun FullQueueCard(
    task: DownloadTask,
    onPause: (String) -> Unit,
    onResume: (String) -> Unit,
    onCancel: (String) -> Unit,
    onRetry: (String) -> Unit,
    onOpen: (DownloadTask) -> Unit,
    onShare: (DownloadTask) -> Unit,
    onDelete: (DownloadTask) -> Unit,
    onSetPriority: (String, Int) -> Unit,
    onDetails: (DownloadTask) -> Unit
) {
    PremiumCard(modifier = Modifier.clickable { onDetails(task) }) {
        val progress = progressOf(task)
        Row(verticalAlignment = Alignment.CenterVertically) {
            FileBadge(categoryFor(task), 46)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(task.fileName ?: shortUrl(task.url), fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${formatBytes(task.downloadedBytes)} / ${formatBytes(task.totalBytes)} • ${task.segmentCount} chunks", color = Muted, fontSize = 11.sp)
                if (task.status == DownloadStatus.QUEUED) {
                    Text("Priority: ${priorityLabel(task.priority)}", color = priorityColor(task.priority), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    task.scheduledAt?.takeIf { it > System.currentTimeMillis() }?.let {
                        Text("Scheduled: ${formatScheduledTime(it)}", color = AppBlue, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Text("${(progress * 100).toInt()}%", color = AppBlue, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
        }
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
            color = AppBlue,
            trackColor = Border
        )
        Spacer(Modifier.height(8.dp))
        Text(task.message.ifBlank { statusLabel(task.status) }, color = Muted, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (task.status == DownloadStatus.DOWNLOADING) {
            val liveSpeed = parseSpeedBytesPerSecond(task.message)
            val eta = etaFor(task, liveSpeed)
            if (liveSpeed > 0L || eta != null) {
                Spacer(Modifier.height(5.dp))
                Text(
                    buildString {
                        if (liveSpeed > 0L) append(formatSpeed(liveSpeed))
                        if (eta != null) {
                            if (isNotEmpty()) append(" • ")
                            append("ETA $eta")
                        }
                    },
                    color = AppBlue,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            when (task.status) {
                DownloadStatus.DOWNLOADING -> {
                    SmallAction("Pause") { onPause(task.id) }
                    SmallAction("Cancel", tonal = false) { onCancel(task.id) }
                }
                DownloadStatus.QUEUED -> {
                    SmallAction("P: ${priorityLabel(task.priority)}") {
                        onSetPriority(task.id, (task.priority + 1) % 3)
                    }
                    SmallAction("Cancel", tonal = false) { onCancel(task.id) }
                }
                DownloadStatus.PAUSED -> {
                    SmallAction("Resume") { onResume(task.id) }
                    SmallAction("Cancel", tonal = false) { onCancel(task.id) }
                }
                DownloadStatus.FAILED, DownloadStatus.CANCELLED -> {
                    SmallAction("Retry") { onRetry(task.id) }
                    SmallAction("Delete", tonal = false) { onDelete(task) }
                }
                DownloadStatus.COMPLETED -> {
                    SmallAction("Open") { onOpen(task) }
                    SmallAction("Share", tonal = false) { onShare(task) }
                    SmallAction("Delete", tonal = false) { onDelete(task) }
                }
            }
        }
    }
}

@Composable
private fun SmallAction(label: String, tonal: Boolean = true, onClick: () -> Unit) {
    if (tonal) {
        FilledTonalButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) { Text(label, fontSize = 11.sp) }
    } else {
        OutlinedButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) { Text(label, fontSize = 11.sp) }
    }
}

@Composable
private fun ConnectionsScreen(
    modifier: Modifier,
    tasks: List<DownloadTask>,
    combineNetworks: Boolean,
    turboMode: Boolean,
    turboConnections: Int,
    onCombineNetworksChange: (Boolean) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val network = remember(tasks, combineNetworks) { networkSnapshot(context) }
    val activeDownloads = tasks.filter { it.status == DownloadStatus.DOWNLOADING }
    val active = activeDownloads.firstOrNull()
    val combinedActive = activeDownloads.any { it.message.contains("Wi‑Fi + Mobile", ignoreCase = true) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 30.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { BrandSubHeader("Connections", "Actual network state & routing") }
        item {
            PremiumCard {
                ConnectionDetail(
                    "Wi‑Fi",
                    connectionStatus(network.wifi, network.activeTransport == "Wi‑Fi", combinedActive && network.wifi),
                    when {
                        combinedActive && network.wifi -> "Actively carrying download segments"
                        network.activeTransport == "Wi‑Fi" -> "Android default internet route"
                        network.wifi -> "Available but not currently used"
                        else -> "No validated Wi‑Fi internet route"
                    }
                )
                HorizontalDivider(color = Border)
                ConnectionDetail(
                    "Mobile Data",
                    connectionStatus(network.cellular, network.activeTransport == "Mobile", combinedActive && network.cellular),
                    when {
                        combinedActive && network.cellular -> "Actively carrying download segments"
                        network.activeTransport == "Mobile" -> "Android default internet route"
                        network.cellular && combineNetworks -> "Available; combine mode is armed"
                        network.cellular -> "Available, combine mode is off"
                        else -> "No validated mobile-data internet route"
                    }
                )
                HorizontalDivider(color = Border)
                ConnectionDetail(
                    "Ethernet / USB",
                    connectionStatus(network.ethernet, network.activeTransport == "Ethernet", false),
                    if (network.ethernet) "Validated Android Ethernet route" else "No Android Ethernet route"
                )
            }
        }
        item {
            val speed = activeDownloads.sumOf { parseSpeedBytesPerSecond(it.message) }
            val parsedConnections = activeDownloads.sumOf { parseConnectionCount(it.message) }
            val liveConnections = parsedConnections.takeIf { it > 0 }
                ?: if (activeDownloads.isNotEmpty()) activeDownloads.size * (if (turboMode) turboConnections else 6) else 0
            val shares = aggregateNetworkShares(activeDownloads, network)
            PremiumCard {
                SectionTitle("Speed Diagnostics", null)
                Spacer(Modifier.height(10.dp))
                if (active == null) {
                    Text("Start a download to see live diagnostics.", color = Muted, fontSize = 12.sp)
                } else {
                    DiagnosticRow("Active files", activeDownloads.size.toString())
                    DiagnosticRow("Server", if (activeDownloads.size == 1) serverHost(active.url) else "${activeDownloads.size} separate servers/tasks")
                    DiagnosticRow("Current speed", formatSpeed(speed))
                    if (activeDownloads.size == 1) DiagnosticRow("ETA", etaFor(active, parseSpeedBytesPerSecond(active.message)) ?: "Calculating…")
                    DiagnosticRow("Connections", "$liveConnections total")
                    DiagnosticRow("Chunks", activeDownloads.sumOf { it.segmentCount }.toString())
                    DiagnosticRow("Network share", "Wi‑Fi ${shares.first}% • Mobile ${shares.second}%")
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Diagnostics are read-only: MultiFetch will not tear down healthy connections while this transfer is running.",
                        color = Muted,
                        fontSize = 10.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    SmallAction("Copy diagnostics") {
                        val report = buildString {
                            appendLine("MultiFetch diagnostics")
                            appendLine("Active files: ${activeDownloads.size}")
                            appendLine("Server: ${if (activeDownloads.size == 1) serverHost(active.url) else "multiple"}")
                            appendLine("Speed: ${formatSpeed(speed)}")
                            if (activeDownloads.size == 1) appendLine("ETA: ${etaFor(active, parseSpeedBytesPerSecond(active.message)) ?: "Calculating"}")
                            appendLine("Connections: $liveConnections")
                            appendLine("Chunks: ${activeDownloads.sumOf { it.segmentCount }}")
                            append("Wi-Fi: ${shares.first}% • Mobile: ${shares.second}%")
                        }
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("MultiFetch diagnostics", report))
                    }
                }
            }
        }
        item {
            PremiumCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Combine Wi‑Fi + Mobile Data", fontWeight = FontWeight.Bold)
                        Text(
                            "When both validated routes are available, different file segments are bound to separate Android Network objects.",
                            color = Muted,
                            fontSize = 12.sp
                        )
                    }
                    Switch(checked = combineNetworks, onCheckedChange = onCombineNetworksChange)
                }
                Spacer(Modifier.height(8.dp))
                val combineState = when {
                    combinedActive -> "ACTIVE now • this download is using Wi‑Fi + Mobile Data"
                    combineNetworks && network.wifi && network.cellular -> "READY • both routes are available; next fresh download can combine them"
                    combineNetworks -> "ARMED • waiting for both validated Wi‑Fi and mobile-data routes"
                    else -> "OFF"
                }
                Text(
                    combineState,
                    color = if (combinedActive) Success else if (combineNetworks) AppBlue else Muted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(4.dp))
                Text("Mobile data may be consumed quickly in Turbo Mode.", color = Color(0xFFE08A00), fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun DiagnosticRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
        Text(value, color = DeepNavy, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ConnectionDetail(name: String, status: String, note: String) {
    val active = status == "Connected" || status == "Combined"
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(10.dp).clip(CircleShape)
                .background(if (active) Success else Color(0xFFB7BECC))
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(name, fontWeight = FontWeight.Bold)
            Text(note, color = Muted, fontSize = 11.sp)
        }
        Text(
            status,
            color = if (active) Success else Muted,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun SettingsScreen(
    modifier: Modifier,
    turboMode: Boolean,
    combineNetworks: Boolean,
    turboConnections: Int,
    autoRetryFailedDownloads: Boolean,
    autoResumeAfterRestart: Boolean,
    wifiOnlyDownloads: Boolean,
    autoOrganizeDownloads: Boolean,
    duplicateSafeFileNames: Boolean,
    speedLimitBytesPerSecond: Long,
    maxConcurrentDownloads: Int,
    darkMode: Boolean,
    onTurboModeChange: (Boolean) -> Unit,
    onCombineNetworksChange: (Boolean) -> Unit,
    onTurboConnectionsChange: (Int) -> Unit,
    onAutoRetryChange: (Boolean) -> Unit,
    onAutoResumeAfterRestartChange: (Boolean) -> Unit,
    onWifiOnlyChange: (Boolean) -> Unit,
    onAutoOrganizeChange: (Boolean) -> Unit,
    onDuplicateSafeNamesChange: (Boolean) -> Unit,
    onSpeedLimitChange: (Long) -> Unit,
    onMaxConcurrentDownloadsChange: (Int) -> Unit,
    onDarkModeChange: (Boolean) -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 30.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { BrandSubHeader("Settings", "Performance & network behavior") }
        item {
            PremiumCard {
                Text("Appearance", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    if (darkMode) "Dark mode • Moon transition" else "Light mode • Sun transition",
                    color = Muted,
                    fontSize = 11.sp
                )
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!darkMode) {
                        Button(onClick = { onDarkModeChange(false) }, modifier = Modifier.weight(1f)) { Text("☀  Light") }
                    } else {
                        OutlinedButton(onClick = { onDarkModeChange(false) }, modifier = Modifier.weight(1f)) { Text("☀  Light") }
                    }
                    if (darkMode) {
                        Button(onClick = { onDarkModeChange(true) }, modifier = Modifier.weight(1f)) { Text("☾  Dark") }
                    } else {
                        OutlinedButton(onClick = { onDarkModeChange(true) }, modifier = Modifier.weight(1f)) { Text("☾  Dark") }
                    }
                }
                Text(
                    "Switching to Light drops a sun from the top; switching to Dark drops a moon while the full MultiFetch UI changes palette.",
                    color = Muted,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
        item {
            PremiumCard {
                SettingToggle(
                    "Turbo Mode",
                    "Stable Turbo keeps the selected parallel connection count fixed for the whole active download. Change the profile below before starting a new download. Server/ISP speed limits still apply.",
                    turboMode,
                    onTurboModeChange
                )
                HorizontalDivider(color = Border)
                Text("Turbo connections", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                Text("Choose a fixed profile. 12 is recommended; 16 is the aggressive maximum for servers that benefit from more parallel ranges.", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(8, 12, 16).forEach { count ->
                        if (turboConnections == count) {
                            Button(onClick = { onTurboConnectionsChange(count) }, modifier = Modifier.weight(1f)) { Text("$count") }
                        } else {
                            OutlinedButton(onClick = { onTurboConnectionsChange(count) }, modifier = Modifier.weight(1f)) { Text("$count") }
                        }
                    }
                }
                HorizontalDivider(color = Border, modifier = Modifier.padding(top = 12.dp))
                Text("Simultaneous files", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                Text("Choose how many separate files can download at the same time. Each active file keeps its own Turbo connection profile.", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1, 2, 3).forEach { count ->
                        if (maxConcurrentDownloads == count) {
                            Button(onClick = { onMaxConcurrentDownloadsChange(count) }, modifier = Modifier.weight(1f)) { Text("$count") }
                        } else {
                            OutlinedButton(onClick = { onMaxConcurrentDownloadsChange(count) }, modifier = Modifier.weight(1f)) { Text("$count") }
                        }
                    }
                }
                HorizontalDivider(color = Border, modifier = Modifier.padding(top = 12.dp))
                Text("Speed limiter", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                Text("Caps each active file independently. With 2 simultaneous files, a 1 MiB/s cap can allow up to about 2 MiB/s total.", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))
                val limits = listOf(
                    0L to "Unlimited",
                    512L * 1024L to "512K",
                    1L * 1024L * 1024L to "1M",
                    2L * 1024L * 1024L to "2M",
                    5L * 1024L * 1024L to "5M"
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    limits.forEach { (value, label) ->
                        if (speedLimitBytesPerSecond == value) {
                            Button(onClick = { onSpeedLimitChange(value) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) { Text(label, fontSize = 11.sp) }
                        } else {
                            OutlinedButton(onClick = { onSpeedLimitChange(value) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) { Text(label, fontSize = 11.sp) }
                        }
                    }
                }
                HorizontalDivider(color = Border, modifier = Modifier.padding(top = 12.dp))
                SettingToggle(
                    "Combine Wi‑Fi + Mobile Data",
                    "Binds different segments to validated Wi‑Fi and mobile-data routes. Turning this on disables Wi‑Fi-only protection.",
                    combineNetworks,
                    onCombineNetworksChange
                )
                HorizontalDivider(color = Border)
                SettingToggle(
                    "Wi‑Fi only downloads",
                    "Protect mobile data. Queued downloads wait in the foreground until validated Wi‑Fi is available, then resume automatically. Turning this on disables Combine mode.",
                    wifiOnlyDownloads,
                    onWifiOnlyChange
                )
                HorizontalDivider(color = Border)
                SettingToggle(
                    "Auto retry",
                    "Automatically retries temporary network/server failures up to 2 times while preserving downloaded chunks.",
                    autoRetryFailedDownloads,
                    onAutoRetryChange
                )
                HorizontalDivider(color = Border)
                SettingToggle(
                    "Resume queue after restart",
                    "After a phone reboot or MultiFetch update, interrupted items are returned to the queue, future schedules are re-armed, and due work is handed back to the downloader. Android/OEM battery rules can delay the wake-up.",
                    autoResumeAfterRestart,
                    onAutoResumeAfterRestartChange
                )
                HorizontalDivider(color = Border)
                SettingToggle(
                    "Smart storage folders",
                    "Automatically save completed files into Downloads/MultiFetch/Video, Audio, Apps, Archives, Documents or Other. Turn off to keep everything directly in Downloads/MultiFetch.",
                    autoOrganizeDownloads,
                    onAutoOrganizeChange
                )
                HorizontalDivider(color = Border)
                SettingToggle(
                    "Duplicate-safe filenames",
                    "Protect existing files. If a name already exists in the target folder, MultiFetch saves the new file as name (1), name (2), and so on instead of reusing the same display name.",
                    duplicateSafeFileNames,
                    onDuplicateSafeNamesChange
                )
            }
        }
        item {
            PremiumCard {
                Text("Browser integration", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Share links from other apps or open HTTP/HTTPS links directly in MultiFetch. Browser Shield blocks known third-party ad/tracker hosts, supports per-site exceptions, and the address bar can use Google, DuckDuckGo, Bing, or Brave Search.", color = Muted, fontSize = 12.sp)
            }
        }
        item {
            PremiumCard {
                Text("Storage", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    (if (autoOrganizeDownloads) "Smart folders are ON: files are organized under Downloads/MultiFetch by category. " else "Smart folders are OFF: completed files are saved directly to Downloads/MultiFetch. ") +
                        "Known-size downloads use a free-space preflight, and a single HTTP/HLS link can optionally be verified with SHA-256 before publishing.",
                    color = Muted,
                    fontSize = 12.sp
                )
            }
        }
        item {
            Text("MultiFetch ${BuildConfig.VERSION_NAME} • Final Core", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(4.dp))
        }
    }
}

private fun shortSha256(value: String): String =
    if (value.length <= 24) value else value.take(12) + "…" + value.takeLast(12)

private fun priorityLabel(priority: Int): String = when (priority.coerceIn(0, 2)) {
    2 -> "High"
    1 -> "Normal"
    else -> "Low"
}

private fun priorityColor(priority: Int): Color = when (priority.coerceIn(0, 2)) {
    2 -> AppBlue
    1 -> DeepNavy
    else -> Muted
}

@Composable
private fun SettingToggle(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun BrandSubHeader(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(R.drawable.multifetch_logo),
                contentDescription = null,
                modifier = Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = DeepNavy)
                Text(subtitle, fontSize = 11.sp, color = Muted)
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, action: String?, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, color = DeepNavy)
        if (action != null) {
            Text(
                action,
                color = AppBlue,
                fontSize = 12.sp,
                modifier = if (onAction != null) Modifier.clickable(onClick = onAction) else Modifier
            )
        }
    }
}

@Composable
private fun PremiumCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), content = content)
    }
}

@Composable
private fun FileBadge(category: String, size: Int = 44) {
    val background = if (AppDarkModeState) {
        when (category) {
            "VIDEO" -> Color(0xFF2A2340)
            "AUDIO" -> Color(0xFF3A222A)
            "APK" -> Color(0xFF1D3524)
            "ARCHIVE" -> Color(0xFF172D43)
            "DOC" -> Color(0xFF3A3020)
            else -> Color(0xFF202A39)
        }
    } else {
        when (category) {
            "VIDEO" -> Color(0xFFECE5FF)
            "AUDIO" -> Color(0xFFFFE9EE)
            "APK" -> Color(0xFFE8F8E5)
            "ARCHIVE" -> Color(0xFFEAF4FF)
            "DOC" -> Color(0xFFFFF3DD)
            else -> Color(0xFFF0F2F7)
        }
    }
    Surface(color = background, shape = RoundedCornerShape(12.dp), modifier = Modifier.size(size.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Text(category.take(3), fontWeight = FontWeight.ExtraBold, fontSize = 9.sp, color = DeepNavy)
        }
    }
}

private data class NetworkSnapshot(
    val wifi: Boolean,
    val cellular: Boolean,
    val ethernet: Boolean,
    val activeTransport: String
)

private fun networkSnapshot(context: Context): NetworkSnapshot {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    var wifi = false
    var cellular = false
    var ethernet = false

    cm.allNetworks.forEach { network ->
        val caps = cm.getNetworkCapabilities(network) ?: return@forEach
        val validatedInternet =
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        if (!validatedInternet) return@forEach

        wifi = wifi || caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
        cellular = cellular || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
        ethernet = ethernet || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    val activeCaps = cm.activeNetwork?.let(cm::getNetworkCapabilities)
    val activeTransport = when {
        activeCaps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi‑Fi"
        activeCaps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Mobile"
        activeCaps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"
        else -> "None"
    }

    return NetworkSnapshot(wifi, cellular, ethernet, activeTransport)
}

private fun measuredNetworkShares(
    message: String,
    network: NetworkSnapshot,
    totalSpeed: Long,
    combinedActive: Boolean
): Pair<Int, Int> {
    val wifi = Regex("WiFi\\s+(\\d+)%", RegexOption.IGNORE_CASE)
        .find(message)?.groupValues?.getOrNull(1)?.toIntOrNull()
    val mobile = Regex("Mobile\\s+(\\d+)%", RegexOption.IGNORE_CASE)
        .find(message)?.groupValues?.getOrNull(1)?.toIntOrNull()

    if (wifi != null && mobile != null) {
        return wifi.coerceIn(0, 100) to mobile.coerceIn(0, 100)
    }
    if (totalSpeed <= 0L) return 0 to 0
    if (combinedActive) return 0 to 0

    return when (network.activeTransport) {
        "Wi‑Fi" -> 100 to 0
        "Mobile" -> 0 to 100
        else -> 0 to 0
    }
}


private fun aggregateNetworkShares(
    activeDownloads: List<DownloadTask>,
    network: NetworkSnapshot
): Pair<Int, Int> {
    if (activeDownloads.isEmpty()) return 0 to 0
    var totalSpeed = 0L
    var wifiWeighted = 0.0
    var mobileWeighted = 0.0
    activeDownloads.forEach { task ->
        val speed = parseSpeedBytesPerSecond(task.message)
        if (speed <= 0L) return@forEach
        val combined = task.message.contains("Wi‑Fi + Mobile", ignoreCase = true)
        val shares = measuredNetworkShares(task.message, network, speed, combined)
        totalSpeed += speed
        wifiWeighted += speed.toDouble() * shares.first / 100.0
        mobileWeighted += speed.toDouble() * shares.second / 100.0
    }
    if (totalSpeed <= 0L) return 0 to 0
    val wifi = ((wifiWeighted / totalSpeed.toDouble()) * 100.0).toInt().coerceIn(0, 100)
    val mobile = ((mobileWeighted / totalSpeed.toDouble()) * 100.0).toInt().coerceIn(0, 100)
    return wifi to mobile
}

private fun progressOf(task: DownloadTask): Float = if (task.totalBytes > 0) {
    (task.downloadedBytes.toFloat() / task.totalBytes.toFloat()).coerceIn(0f, 1f)
} else 0f


private fun parseConnectionCount(message: String): Int {
    val patterns = listOf(
        Regex("Stable Turbo\\s+(\\d+)\\s+conn", RegexOption.IGNORE_CASE),
        Regex("Peak-tuning\\s+(\\d+)\\s+conn", RegexOption.IGNORE_CASE),
        Regex("Peak Turbo\\s+(\\d+)\\s+conn", RegexOption.IGNORE_CASE),
        Regex("Auto-tuning\\s+(\\d+)\\s+conn", RegexOption.IGNORE_CASE),
        Regex("Auto-selected\\s+(\\d+)\\s+conn", RegexOption.IGNORE_CASE),
        Regex("Auto Turbo\\s+(\\d+)\\s+conn", RegexOption.IGNORE_CASE)
    )
    for (pattern in patterns) {
        val value = pattern.find(message)?.groupValues?.getOrNull(1)?.toIntOrNull()
        if (value != null) return value
    }
    return 0
}

private fun parseSpeedBytesPerSecond(message: String): Long {
    val match = Regex("(\\d+(?:\\.\\d+)?)\\s*(KB|MB|GB)/s", RegexOption.IGNORE_CASE).find(message) ?: return 0L
    val value = match.groupValues[1].toDoubleOrNull() ?: return 0L
    val multiplier = when (match.groupValues[2].uppercase(Locale.US)) {
        "GB" -> 1024.0 * 1024.0 * 1024.0
        "MB" -> 1024.0 * 1024.0
        else -> 1024.0
    }
    return (value * multiplier).toLong()
}

private fun speedShare(total: Long, share: Double): Long = (total * share).toLong().coerceAtLeast(0L)

private fun shortSpeed(bytes: Long): String = when {
    bytes >= 1024L * 1024L * 1024L -> String.format(Locale.US, "%.1fG", bytes / 1024.0 / 1024.0 / 1024.0)
    bytes >= 1024L * 1024L -> String.format(Locale.US, "%.1fM", bytes / 1024.0 / 1024.0)
    bytes >= 1024L -> String.format(Locale.US, "%.0fK", bytes / 1024.0)
    else -> "0"
}

private fun formatSpeed(bytes: Long): String = when {
    bytes >= 1024L * 1024L * 1024L -> String.format(Locale.US, "%.2f GB/s", bytes / 1024.0 / 1024.0 / 1024.0)
    bytes >= 1024L * 1024L -> String.format(Locale.US, "%.1f MB/s", bytes / 1024.0 / 1024.0)
    bytes >= 1024L -> String.format(Locale.US, "%.0f KB/s", bytes / 1024.0)
    else -> "0 B/s"
}

private fun etaFor(task: DownloadTask, speedBytesPerSecond: Long): String? {
    if (task.status != DownloadStatus.DOWNLOADING || task.totalBytes <= 0L || speedBytesPerSecond <= 0L) return null
    val remaining = (task.totalBytes - task.downloadedBytes).coerceAtLeast(0L)
    if (remaining <= 0L) return "0s"
    return formatDurationSeconds((remaining / speedBytesPerSecond).coerceAtLeast(1L))
}

private fun formatDurationSeconds(totalSeconds: Long): String {
    val seconds = totalSeconds.coerceAtLeast(0L)
    val hours = seconds / 3600
    val minutes = (seconds % 3600) / 60
    val secs = seconds % 60
    return when {
        hours > 0 -> String.format(Locale.US, "%dh %02dm", hours, minutes)
        minutes > 0 -> String.format(Locale.US, "%dm %02ds", minutes, secs)
        else -> "${secs}s"
    }
}

private fun serverHost(url: String): String = when {
    TorrentDownloadEngine.isTorrentSource(url) -> "BitTorrent"
    else -> runCatching { Uri.parse(url).host.orEmpty().ifBlank { "Unknown" } }.getOrDefault("Unknown")
}

private fun displayDownloadSource(url: String): String = when {
    url.startsWith(TorrentDownloadEngine.TORRENT_FILE_PREFIX, ignoreCase = true) -> "Local .torrent file"
    else -> url
}

private fun categoryFor(task: DownloadTask): String {
    val name = (task.fileName ?: task.url).substringBefore('?').lowercase(Locale.US)
    return when {
        name.endsWith(".mp4") || name.endsWith(".mkv") || name.endsWith(".webm") || name.endsWith(".mov") -> "VIDEO"
        name.endsWith(".mp3") || name.endsWith(".m4a") || name.endsWith(".wav") || name.endsWith(".flac") -> "AUDIO"
        name.endsWith(".apk") || name.endsWith(".xapk") -> "APK"
        name.endsWith(".zip") || name.endsWith(".rar") || name.endsWith(".7z") || name.endsWith(".tar") || name.endsWith(".gz") -> "ARCHIVE"
        name.endsWith(".pdf") || name.endsWith(".doc") || name.endsWith(".docx") || name.endsWith(".txt") -> "DOC"
        else -> "FILE"
    }
}

private fun statusLabel(status: DownloadStatus): String = when (status) {
    DownloadStatus.QUEUED -> "Queued"
    DownloadStatus.DOWNLOADING -> "Downloading"
    DownloadStatus.PAUSED -> "Paused"
    DownloadStatus.COMPLETED -> "Completed"
    DownloadStatus.FAILED -> "Failed"
    DownloadStatus.CANCELLED -> "Cancelled"
}

private fun shortUrl(url: String): String = when {
    url.startsWith("magnet:", ignoreCase = true) -> "Magnet download"
    url.startsWith(TorrentDownloadEngine.TORRENT_FILE_PREFIX, ignoreCase = true) -> ".torrent download"
    else -> url.removePrefix("https://").removePrefix("http://").take(70)
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 0 -> "Unknown"
    bytes >= 1024L * 1024L * 1024L -> String.format(Locale.US, "%.2f GB", bytes / 1024.0 / 1024.0 / 1024.0)
    bytes >= 1024L * 1024L -> String.format(Locale.US, "%.1f MB", bytes / 1024.0 / 1024.0)
    bytes >= 1024L -> String.format(Locale.US, "%.0f KB", bytes / 1024.0)
    else -> "$bytes B"
}
