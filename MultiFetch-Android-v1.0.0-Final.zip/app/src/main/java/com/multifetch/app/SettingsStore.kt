package com.multifetch.app

import android.content.Context

class SettingsStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    var turboMode: Boolean
        get() = prefs.getBoolean(KEY_TURBO, true)
        set(value) = prefs.edit().putBoolean(KEY_TURBO, value).apply()

    var combineWifiAndCellular: Boolean
        get() = prefs.getBoolean(KEY_COMBINE, false)
        set(value) = prefs.edit().putBoolean(KEY_COMBINE, value).apply()

    var turboConnections: Int
        get() = prefs.getInt(KEY_TURBO_CONNECTIONS, 12).let { if (it in setOf(8, 12, 16)) it else 12 }
        set(value) = prefs.edit().putInt(KEY_TURBO_CONNECTIONS, value.coerceIn(8, 16)).apply()

    /** Number of separate files MultiFetch may download at the same time. */
    var maxConcurrentDownloads: Int
        get() = prefs.getInt(KEY_MAX_CONCURRENT_DOWNLOADS, 2).coerceIn(1, 3)
        set(value) = prefs.edit().putInt(KEY_MAX_CONCURRENT_DOWNLOADS, value.coerceIn(1, 3)).apply()

    var autoRetryFailedDownloads: Boolean
        get() = prefs.getBoolean(KEY_AUTO_RETRY, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_RETRY, value).apply()

    /** Re-arm queued/scheduled work after a device reboot or app update. */
    var autoResumeAfterRestart: Boolean
        get() = prefs.getBoolean(KEY_AUTO_RESUME_AFTER_RESTART, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_RESUME_AFTER_RESTART, value).apply()

    var wifiOnlyDownloads: Boolean
        get() = prefs.getBoolean(KEY_WIFI_ONLY, false)
        set(value) = prefs.edit().putBoolean(KEY_WIFI_ONLY, value).apply()

    var autoOrganizeDownloads: Boolean
        get() = prefs.getBoolean(KEY_AUTO_ORGANIZE, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_ORGANIZE, value).apply()

    var duplicateSafeFileNames: Boolean
        get() = prefs.getBoolean(KEY_DUPLICATE_SAFE_NAMES, true)
        set(value) = prefs.edit().putBoolean(KEY_DUPLICATE_SAFE_NAMES, value).apply()

    /** Per-active-download cap. 0 means unlimited. */
    var speedLimitBytesPerSecond: Long
        get() = prefs.getLong(KEY_SPEED_LIMIT_BPS, 0L).coerceAtLeast(0L)
        set(value) = prefs.edit().putLong(KEY_SPEED_LIMIT_BPS, value.coerceAtLeast(0L)).apply()

    var darkMode: Boolean
        get() = prefs.getBoolean(KEY_DARK_MODE, false)
        set(value) = prefs.edit().putBoolean(KEY_DARK_MODE, value).apply()

    companion object {
        private const val PREFS = "multifetch_settings"
        private const val KEY_TURBO = "turbo_mode"
        private const val KEY_COMBINE = "combine_wifi_cellular"
        private const val KEY_TURBO_CONNECTIONS = "turbo_connections"
        private const val KEY_MAX_CONCURRENT_DOWNLOADS = "max_concurrent_downloads"
        private const val KEY_AUTO_RETRY = "auto_retry_failed_downloads"
        private const val KEY_AUTO_RESUME_AFTER_RESTART = "auto_resume_after_restart"
        private const val KEY_WIFI_ONLY = "wifi_only_downloads"
        private const val KEY_AUTO_ORGANIZE = "auto_organize_downloads"
        private const val KEY_DUPLICATE_SAFE_NAMES = "duplicate_safe_file_names"
        private const val KEY_SPEED_LIMIT_BPS = "speed_limit_bytes_per_second"
        private const val KEY_DARK_MODE = "dark_mode"
    }
}
