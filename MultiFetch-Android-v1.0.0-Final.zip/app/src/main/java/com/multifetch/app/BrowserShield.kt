package com.multifetch.app

import android.content.SharedPreferences
import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.util.Locale

enum class BrowserSearchEngine(
    val label: String,
    val homeUrl: String,
    val searchPrefix: String
) {
    GOOGLE("Google", "https://www.google.com", "https://www.google.com/search?q="),
    DUCKDUCKGO("DuckDuckGo", "https://duckduckgo.com", "https://duckduckgo.com/?q="),
    BING("Bing", "https://www.bing.com", "https://www.bing.com/search?q="),
    BRAVE("Brave Search", "https://search.brave.com", "https://search.brave.com/search?q=");

    companion object {
        fun fromStored(value: String?): BrowserSearchEngine = entries.firstOrNull { it.name == value } ?: GOOGLE
    }
}

enum class BrowserBlockReason { AD, TRACKER }

object BrowserShield {
    const val KEY_AD_BLOCK = "browser_ad_block_enabled"
    const val KEY_TRACKER_BLOCK = "browser_tracker_block_enabled"
    const val KEY_ALLOWLIST = "browser_shield_allowlist"
    const val KEY_SEARCH_ENGINE = "browser_search_engine"

    // Deliberately host-based and conservative. Main-frame requests are never blocked.
    private val adHosts = setOf(
        "2mdn.net",
        "33across.com",
        "adcolony.com",
        "adform.net",
        "adition.com",
        "adnxs.com",
        "adroll.com",
        "adsafeprotected.com",
        "adservice.google.com",
        "adsrvr.org",
        "advertising.com",
        "amazon-adsystem.com",
        "applovin.com",
        "bidswitch.net",
        "casalemedia.com",
        "chartboost.com",
        "contextweb.com",
        "criteo.com",
        "criteo.net",
        "doubleclick.net",
        "exoclick.com",
        "googleadservices.com",
        "googlesyndication.com",
        "googletagservices.com",
        "gumgum.com",
        "indexww.com",
        "inmobi.com",
        "ironsrc.com",
        "lijit.com",
        "media.net",
        "mgid.com",
        "moatads.com",
        "openx.net",
        "outbrain.com",
        "pagead2.googlesyndication.com",
        "pubmatic.com",
        "revcontent.com",
        "rubiconproject.com",
        "securepubads.g.doubleclick.net",
        "sharethrough.com",
        "smaato.net",
        "smartadserver.com",
        "sonobi.com",
        "spotx.tv",
        "spotxchange.com",
        "taboola.com",
        "tapjoy.com",
        "teads.tv",
        "themoneytizer.com",
        "trafficjunky.net",
        "triplelift.com",
        "undertone.com",
        "unityads.unity3d.com",
        "vungle.com",
        "yieldlab.net",
        "yieldmo.com",
        "zedo.com"
    )

    private val trackerHosts = setOf(
        "amplitude.com",
        "analytics.google.com",
        "app-measurement.com",
        "bat.bing.com",
        "branch.io",
        "chartbeat.com",
        "chartbeat.net",
        "clarity.ms",
        "clicky.com",
        "connect.facebook.net",
        "crazyegg.com",
        "facebook.net",
        "fullstory.com",
        "google-analytics.com",
        "googletagmanager.com",
        "heap.io",
        "heapanalytics.com",
        "hotjar.com",
        "intercom.io",
        "intercomcdn.com",
        "kissmetrics.com",
        "kissmetrics.io",
        "logrocket.com",
        "logrocket.io",
        "luckyorange.com",
        "matomo.cloud",
        "mixpanel.com",
        "mouseflow.com",
        "newrelic.com",
        "nr-data.net",
        "onesignal.com",
        "optimizely.com",
        "optimizelycdn.com",
        "parsely.com",
        "quantserve.com",
        "scorecardresearch.com",
        "segment.com",
        "segment.io",
        "sentry.io",
        "snowplowanalytics.com",
        "statcounter.com",
        "taboola.com"
    )

    private val thirdPartyAdPathTokens = listOf(
        "/pagead/", "/gampad/", "/adserver/", "/adsystem/", "/adserve/",
        "/adserv/", "/advertising/", "/prebid/", "/bidder/", "/header-bid/"
    )

    private val thirdPartyTrackerPathTokens = listOf(
        "/analytics.js", "/gtag/js", "/collect?", "/pixel?", "/tracking/", "/tracker/", "/beacon/"
    )

    fun adBlockEnabled(prefs: SharedPreferences): Boolean = prefs.getBoolean(KEY_AD_BLOCK, true)
    fun trackerBlockEnabled(prefs: SharedPreferences): Boolean = prefs.getBoolean(KEY_TRACKER_BLOCK, true)

    fun allowlistedHosts(prefs: SharedPreferences): Set<String> =
        prefs.getStringSet(KEY_ALLOWLIST, emptySet()).orEmpty().map { normalizeHost(it) }.filter { it.isNotBlank() }.toSet()

    fun isSiteAllowlisted(prefs: SharedPreferences, host: String): Boolean {
        val normalized = normalizeHost(host)
        return normalized.isNotBlank() && allowlistedHosts(prefs).contains(normalized)
    }

    fun setSiteAllowlisted(prefs: SharedPreferences, host: String, allowed: Boolean) {
        val normalized = normalizeHost(host)
        if (normalized.isBlank()) return
        val updated = allowlistedHosts(prefs).toMutableSet().apply {
            if (allowed) add(normalized) else remove(normalized)
        }
        prefs.edit().putStringSet(KEY_ALLOWLIST, updated).apply()
    }

    fun blockReason(
        requestUrl: String,
        topLevelHost: String,
        isMainFrame: Boolean,
        prefs: SharedPreferences
    ): BrowserBlockReason? {
        if (isMainFrame) return null
        if (!requestUrl.startsWith("http://", true) && !requestUrl.startsWith("https://", true)) return null

        val host = browserSiteHost(requestUrl)
        if (host.isBlank()) return null
        val pageHost = normalizeHost(topLevelHost)
        if (pageHost.isNotBlank() && isSiteAllowlisted(prefs, pageHost)) return null

        // Keep first-party resources intact to reduce site breakage.
        if (pageHost.isNotBlank() && sameSite(host, pageHost)) return null

        if (adBlockEnabled(prefs) && adHosts.any { hostMatches(host, it) }) return BrowserBlockReason.AD
        if (trackerBlockEnabled(prefs) && trackerHosts.any { hostMatches(host, it) }) return BrowserBlockReason.TRACKER

        val normalizedUrl = requestUrl.lowercase(Locale.US)
        if (adBlockEnabled(prefs) && thirdPartyAdPathTokens.any(normalizedUrl::contains)) return BrowserBlockReason.AD
        if (trackerBlockEnabled(prefs) && thirdPartyTrackerPathTokens.any(normalizedUrl::contains)) return BrowserBlockReason.TRACKER
        return null
    }

    /**
     * Cosmetic cleanup runs only when ad blocking is enabled and the current site is not allowlisted.
     * It intentionally targets common ad containers/iframes instead of generic words such as "ad".
     */
    fun cosmeticScript(prefs: SharedPreferences, topLevelHost: String): String? {
        val host = normalizeHost(topLevelHost)
        if (!adBlockEnabled(prefs) || host.isBlank() || isSiteAllowlisted(prefs, host)) return null
        return """
            (function(){
              if (window.__multifetchShieldInstalled) { if (window.__multifetchShieldSweep) window.__multifetchShieldSweep(); return; }
              window.__multifetchShieldInstalled = true;
              const selectors = [
                '.adsbygoogle','[data-ad-slot]','[data-ad-client]','[id^="google_ads_"]','[id^="div-gpt-ad"]',
                'iframe[src*="doubleclick.net"]','iframe[src*="googlesyndication.com"]','iframe[src*="amazon-adsystem.com"]',
                '[aria-label="Advertisement"]','[aria-label="advertisement"]','.ad-container','.ad-banner','.advertisement',
                '.sponsored-ad','[data-testid="ad"]','.ytp-ad-overlay-container','.ytp-ad-player-overlay','.ytp-ad-text-overlay'
              ];
              const sweep = function(){
                try {
                  document.querySelectorAll(selectors.join(',')).forEach(function(el){ el.style.setProperty('display','none','important'); });
                  document.querySelectorAll('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button').forEach(function(el){ try { el.click(); } catch(e) {} });
                } catch(e) {}
              };
              window.__multifetchShieldSweep = sweep;
              sweep();
              try { new MutationObserver(sweep).observe(document.documentElement || document.body,{childList:true,subtree:true}); } catch(e) {}
            })();
        """.trimIndent()
    }

    private fun sameSite(a: String, b: String): Boolean {
        val left = normalizeHost(a)
        val right = normalizeHost(b)
        return left == right || left.endsWith(".$right") || right.endsWith(".$left")
    }

    private fun hostMatches(host: String, suffix: String): Boolean {
        val normalizedHost = normalizeHost(host)
        val normalizedSuffix = normalizeHost(suffix)
        return normalizedHost == normalizedSuffix || normalizedHost.endsWith(".$normalizedSuffix")
    }

    private fun normalizeHost(value: String): String = value.lowercase(Locale.US).removePrefix("www.").trim('.')
}

fun browserSiteHost(url: String): String = runCatching {
    Uri.parse(url).host.orEmpty().lowercase(Locale.US).removePrefix("www.")
}.getOrDefault("")

fun blockedBrowserResponse(): WebResourceResponse =
    WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
