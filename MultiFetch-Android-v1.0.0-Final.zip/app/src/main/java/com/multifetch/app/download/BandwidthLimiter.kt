package com.multifetch.app.download

/**
 * Simple aggregate rate limiter shared by all workers of one active download.
 * A limit of 0 disables throttling completely.
 */
internal class BandwidthLimiter(private val bytesPerSecond: Long) {
    private val lock = Any()
    private var startedAtNanos = System.nanoTime()
    private var bytesInWindow = 0L

    fun throttle(bytes: Int) {
        if (bytesPerSecond <= 0L || bytes <= 0) return
        synchronized(lock) {
            bytesInWindow += bytes.toLong()
            var elapsed = System.nanoTime() - startedAtNanos
            val target = (bytesInWindow.toDouble() * 1_000_000_000.0 / bytesPerSecond.toDouble()).toLong()
            if (target > elapsed) {
                val waitNanos = target - elapsed
                val millis = waitNanos / 1_000_000L
                val nanos = (waitNanos % 1_000_000L).toInt()
                try {
                    Thread.sleep(millis, nanos)
                } catch (e: InterruptedException) {
                    Thread.currentThread().interrupt()
                    throw e
                }
                elapsed = System.nanoTime() - startedAtNanos
            }
            // Keep arithmetic bounded without creating a visible burst after reset.
            if (elapsed >= 2_000_000_000L) {
                startedAtNanos = System.nanoTime()
                bytesInWindow = 0L
            }
        }
    }
}
