# MultiFetch Android — Alpha 0.2

MultiFetch is an Android segmented download manager prototype.

## Alpha 0.2

- Persistent SQLite-backed download queue
- Queue survives app/process restart
- Range-supported segmented downloads resume from saved byte positions
- Pause preserves partial files and releases the queue slot
- Resume continues from partial segment files
- Failed downloads retain partial data and can retry
- Completed/cancelled/failed history in the app
- Automatic 1/2/4/8 segment selection
- Foreground-service download notifications
- Direct URL and Android share-sheet input
- Final files saved to `Downloads/MultiFetch`

## Current limitation

If a server does not support HTTP Range requests, a process restart cannot byte-resume that server's single-stream download; it restarts that file from zero. Range-capable servers get true byte resume.

## Next milestone

Alpha 0.3: Wi-Fi/cellular network discovery, per-network routing, connection controls, and multi-network segmented transfers where Android/device/carrier behavior permits it.
