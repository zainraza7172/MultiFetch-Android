package com.multifetch.app.download

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.UUID

class DownloadStore(context: Context) : SQLiteOpenHelper(
    context.applicationContext,
    DB_NAME,
    null,
    DB_VERSION
) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE downloads (
                id TEXT PRIMARY KEY,
                url TEXT NOT NULL,
                file_name TEXT,
                mime_type TEXT,
                total_bytes INTEGER NOT NULL DEFAULT -1,
                downloaded_bytes INTEGER NOT NULL DEFAULT 0,
                segment_count INTEGER NOT NULL DEFAULT 1,
                status TEXT NOT NULL,
                message TEXT NOT NULL DEFAULT '',
                output_uri TEXT,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_downloads_status_created ON downloads(status, created_at)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion != newVersion) {
            db.execSQL("DROP TABLE IF EXISTS downloads")
            onCreate(db)
        }
    }

    @Synchronized
    fun enqueue(url: String): DownloadTask {
        val now = System.currentTimeMillis()
        val id = UUID.randomUUID().toString()
        val values = ContentValues().apply {
            put("id", id)
            put("url", url)
            put("total_bytes", -1L)
            put("downloaded_bytes", 0L)
            put("segment_count", 1)
            put("status", DownloadStatus.QUEUED.name)
            put("message", "Queued")
            put("created_at", now)
            put("updated_at", now)
        }
        writableDatabase.insertOrThrow("downloads", null, values)
        return get(id)!!
    }

    @Synchronized
    fun get(id: String): DownloadTask? = readableDatabase.query(
        "downloads",
        null,
        "id = ?",
        arrayOf(id),
        null,
        null,
        null,
        "1"
    ).use { cursor -> if (cursor.moveToFirst()) cursor.toTask() else null }

    @Synchronized
    fun getAll(limit: Int = 100): List<DownloadTask> = readableDatabase.query(
        "downloads",
        null,
        null,
        null,
        null,
        null,
        "created_at DESC",
        limit.toString()
    ).use { cursor ->
        buildList {
            while (cursor.moveToNext()) add(cursor.toTask())
        }
    }

    @Synchronized
    fun nextQueued(): DownloadTask? = readableDatabase.query(
        "downloads",
        null,
        "status = ?",
        arrayOf(DownloadStatus.QUEUED.name),
        null,
        null,
        "created_at ASC",
        "1"
    ).use { cursor -> if (cursor.moveToFirst()) cursor.toTask() else null }

    @Synchronized
    fun recoverInterrupted() {
        val values = ContentValues().apply {
            put("status", DownloadStatus.QUEUED.name)
            put("message", "Recovered after restart")
            put("updated_at", System.currentTimeMillis())
        }
        writableDatabase.update(
            "downloads",
            values,
            "status = ?",
            arrayOf(DownloadStatus.DOWNLOADING.name)
        )
    }

    @Synchronized
    fun updateProbe(
        id: String,
        fileName: String,
        mimeType: String,
        totalBytes: Long,
        segmentCount: Int
    ) {
        update(id, ContentValues().apply {
            put("file_name", fileName)
            put("mime_type", mimeType)
            put("total_bytes", totalBytes)
            put("segment_count", segmentCount)
            put("updated_at", System.currentTimeMillis())
        })
    }

    @Synchronized
    fun updateProgress(id: String, downloadedBytes: Long, totalBytes: Long, message: String) {
        update(id, ContentValues().apply {
            put("downloaded_bytes", downloadedBytes.coerceAtLeast(0L))
            if (totalBytes > 0) put("total_bytes", totalBytes)
            put("message", message)
            put("updated_at", System.currentTimeMillis())
        })
    }

    @Synchronized
    fun setStatus(id: String, status: DownloadStatus, message: String) {
        update(id, ContentValues().apply {
            put("status", status.name)
            put("message", message)
            put("updated_at", System.currentTimeMillis())
        })
    }

    @Synchronized
    fun markCompleted(id: String, fileName: String, totalBytes: Long, outputUri: String) {
        update(id, ContentValues().apply {
            put("file_name", fileName)
            put("downloaded_bytes", totalBytes)
            put("total_bytes", totalBytes)
            put("status", DownloadStatus.COMPLETED.name)
            put("message", "Saved: $fileName")
            put("output_uri", outputUri)
            put("updated_at", System.currentTimeMillis())
        })
    }

    @Synchronized
    fun resetForRetry(id: String) {
        update(id, ContentValues().apply {
            put("status", DownloadStatus.QUEUED.name)
            put("message", "Queued for retry")
            put("updated_at", System.currentTimeMillis())
        })
    }

    private fun update(id: String, values: ContentValues) {
        writableDatabase.update("downloads", values, "id = ?", arrayOf(id))
    }

    private fun Cursor.toTask(): DownloadTask = DownloadTask(
        id = getString(getColumnIndexOrThrow("id")),
        url = getString(getColumnIndexOrThrow("url")),
        fileName = getNullableString("file_name"),
        mimeType = getNullableString("mime_type"),
        totalBytes = getLong(getColumnIndexOrThrow("total_bytes")),
        downloadedBytes = getLong(getColumnIndexOrThrow("downloaded_bytes")),
        segmentCount = getInt(getColumnIndexOrThrow("segment_count")),
        status = runCatching {
            DownloadStatus.valueOf(getString(getColumnIndexOrThrow("status")))
        }.getOrDefault(DownloadStatus.FAILED),
        message = getString(getColumnIndexOrThrow("message")),
        outputUri = getNullableString("output_uri"),
        createdAt = getLong(getColumnIndexOrThrow("created_at")),
        updatedAt = getLong(getColumnIndexOrThrow("updated_at"))
    )

    private fun Cursor.getNullableString(column: String): String? {
        val index = getColumnIndexOrThrow(column)
        return if (isNull(index)) null else getString(index)
    }

    companion object {
        private const val DB_NAME = "multifetch.db"
        private const val DB_VERSION = 1
    }
}
