package com.multifetch.app.download

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class DownloadEngine(private val context: Context) {

    data class Progress(
        val downloadedBytes: Long,
        val totalBytes: Long,
        val message: String
    )

    data class ProbeInfo(
        val totalBytes: Long,
        val supportsRanges: Boolean,
        val fileName: String,
        val mimeType: String,
        val segmentCount: Int
    )

    data class Result(
        val uri: Uri,
        val fileName: String,
        val totalBytes: Long,
        val usedSegments: Int
    )

    class DownloadPausedException : RuntimeException("Download paused")
    class DownloadCancelledException : RuntimeException("Download cancelled")

    fun download(
        taskId: String,
        rawUrl: String,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean,
        onProbe: (ProbeInfo) -> Unit,
        onProgress: (Progress) -> Unit
    ): Result {
        val url = validateUrl(rawUrl)
        onProgress(Progress(0, -1, "Checking server…"))
        val probe = probe(url)
        val segments = chooseSegmentCount(probe.totalBytes, probe.supportsRanges)
        val info = ProbeInfo(
            totalBytes = probe.totalBytes,
            supportsRanges = probe.supportsRanges,
            fileName = probe.fileName,
            mimeType = probe.mimeType,
            segmentCount = segments
        )
        onProbe(info)

        val workDir = File(context.filesDir, "multifetch/$taskId").apply { mkdirs() }
        val downloaded = AtomicLong(existingBytes(workDir, probe.totalBytes, segments))
        onProgress(Progress(downloaded.get(), probe.totalBytes, resumeMessage(downloaded.get())))

        try {
            if (segments > 1) {
                downloadSegmented(
                    url = url,
                    totalBytes = probe.totalBytes,
                    segmentCount = segments,
                    workDir = workDir,
                    pauseRequested = pauseRequested,
                    cancelled = cancelled,
                    downloaded = downloaded,
                    onProgress = onProgress
                )
            } else {
                downloadSingle(
                    url = url,
                    supportsRanges = probe.supportsRanges,
                    output = File(workDir, "part_0.tmp"),
                    pauseRequested = pauseRequested,
                    cancelled = cancelled,
                    downloaded = downloaded,
                    totalBytes = probe.totalBytes,
                    onProgress = onProgress
                )
            }

            ensureRunning(pauseRequested, cancelled)
            val finalTotal = if (probe.totalBytes > 0) probe.totalBytes else {
                (0 until segments).sumOf { index -> File(workDir, "part_$index.tmp").length() }
            }
            onProgress(Progress(finalTotal, finalTotal, "Saving to Downloads…"))
            val uri = publishToDownloads(
                workDir = workDir,
                partCount = segments,
                fileName = probe.fileName,
                mimeType = probe.mimeType,
                cancelled = cancelled
            )
            workDir.deleteRecursively()
            onProgress(Progress(finalTotal, finalTotal, "Complete"))
            return Result(uri, probe.fileName, finalTotal, segments)
        } catch (t: Throwable) {
            if (t is DownloadCancelledException) {
                workDir.deleteRecursively()
            }
            throw t
        }
    }

    fun deleteWorkspace(taskId: String) {
        File(context.filesDir, "multifetch/$taskId").deleteRecursively()
    }

    private data class Probe(
        val totalBytes: Long,
        val supportsRanges: Boolean,
        val fileName: String,
        val mimeType: String
    )

    private fun validateUrl(raw: String): URL {
        val trimmed = raw.trim()
        require(trimmed.startsWith("https://") || trimmed.startsWith("http://")) {
            "Only http:// and https:// links are supported."
        }
        return URL(trimmed)
    }

    private fun probe(url: URL): Probe {
        val connection = open(url).apply {
            setRequestProperty("Range", "bytes=0-0")
        }
        try {
            val code = connection.responseCode
            val contentRange = connection.getHeaderField("Content-Range")
            val totalFromRange = parseTotalFromContentRange(contentRange)
            val supportsRanges = code == HttpURLConnection.HTTP_PARTIAL && totalFromRange > 0
            val total = when {
                totalFromRange > 0 -> totalFromRange
                connection.contentLengthLong > 0 -> connection.contentLengthLong
                else -> -1L
            }
            val fileName = extractFileName(connection, url)
            val mime = connection.contentType?.substringBefore(';')?.trim()
                ?.takeIf { it.isNotBlank() }
                ?: "application/octet-stream"

            runCatching { connection.inputStream.close() }
            return Probe(total, supportsRanges, fileName, mime)
        } finally {
            connection.disconnect()
        }
    }

    private fun chooseSegmentCount(totalBytes: Long, supportsRanges: Boolean): Int {
        if (!supportsRanges || totalBytes <= 0) return 1
        return when {
            totalBytes < 4L * MIB -> 1
            totalBytes < 16L * MIB -> 2
            totalBytes < 64L * MIB -> 4
            else -> 8
        }
    }

    private fun existingBytes(workDir: File, totalBytes: Long, segmentCount: Int): Long {
        if (totalBytes <= 0) return File(workDir, "part_0.tmp").takeIf { it.exists() }?.length() ?: 0L
        val chunk = totalBytes / segmentCount
        var sum = 0L
        for (index in 0 until segmentCount) {
            val start = index * chunk
            val end = if (index == segmentCount - 1) totalBytes - 1 else start + chunk - 1
            val expected = end - start + 1
            val file = File(workDir, "part_$index.tmp")
            if (file.exists() && file.length() > expected) file.delete()
            sum += file.takeIf { it.exists() }?.length()?.coerceAtMost(expected) ?: 0L
        }
        return sum.coerceAtMost(totalBytes)
    }

    private fun resumeMessage(downloaded: Long): String =
        if (downloaded > 0) "Resuming saved download…" else "Downloading"

    private fun downloadSegmented(
        url: URL,
        totalBytes: Long,
        segmentCount: Int,
        workDir: File,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean,
        downloaded: AtomicLong,
        onProgress: (Progress) -> Unit
    ) {
        val executor = Executors.newFixedThreadPool(segmentCount)
        try {
            val chunk = totalBytes / segmentCount
            val tasks = (0 until segmentCount).map { index ->
                Callable {
                    val start = index * chunk
                    val end = if (index == segmentCount - 1) totalBytes - 1 else start + chunk - 1
                    val output = File(workDir, "part_$index.tmp")
                    downloadRangeWithRetry(
                        url = url,
                        rangeStart = start,
                        rangeEnd = end,
                        output = output,
                        pauseRequested = pauseRequested,
                        cancelled = cancelled,
                        downloaded = downloaded,
                        totalBytes = totalBytes,
                        onProgress = onProgress
                    )
                }
            }
            executor.invokeAll(tasks).forEach { it.get() }
        } catch (t: Throwable) {
            val root = unwrap(t)
            when (root) {
                is DownloadPausedException -> throw root
                is DownloadCancelledException -> throw root
                else -> throw root
            }
        } finally {
            executor.shutdownNow()
        }
    }

    private fun downloadRangeWithRetry(
        url: URL,
        rangeStart: Long,
        rangeEnd: Long,
        output: File,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean,
        downloaded: AtomicLong,
        totalBytes: Long,
        onProgress: (Progress) -> Unit
    ) {
        val expectedSize = rangeEnd - rangeStart + 1
        if (output.exists() && output.length() > expectedSize) output.delete()
        if (output.exists() && output.length() == expectedSize) return

        var lastError: Throwable? = null
        repeat(4) { attempt ->
            ensureRunning(pauseRequested, cancelled)
            val already = output.takeIf { it.exists() }?.length() ?: 0L
            if (already >= expectedSize) return
            val requestStart = rangeStart + already
            try {
                val connection = open(url).apply {
                    setRequestProperty("Range", "bytes=$requestStart-$rangeEnd")
                }
                try {
                    if (connection.responseCode != HttpURLConnection.HTTP_PARTIAL) {
                        error("Server stopped supporting range requests (HTTP ${connection.responseCode}).")
                    }
                    BufferedInputStream(connection.inputStream, BUFFER_SIZE).use { input ->
                        BufferedOutputStream(FileOutputStream(output, true), BUFFER_SIZE).use { out ->
                            copyWithState(input, out, pauseRequested, cancelled) { count ->
                                val current = downloaded.addAndGet(count.toLong())
                                onProgress(Progress(current, totalBytes, "Downloading"))
                            }
                        }
                    }
                    if (output.length() == expectedSize) return
                    error("Segment ended early (${output.length()} / $expectedSize bytes).")
                } finally {
                    connection.disconnect()
                }
            } catch (t: Throwable) {
                when (t) {
                    is DownloadPausedException -> throw t
                    is DownloadCancelledException -> throw t
                }
                lastError = t
                if (attempt < 3) Thread.sleep(650L * (attempt + 1))
            }
        }
        throw IllegalStateException("A download segment failed after retries.", lastError)
    }

    private fun downloadSingle(
        url: URL,
        supportsRanges: Boolean,
        output: File,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean,
        downloaded: AtomicLong,
        totalBytes: Long,
        onProgress: (Progress) -> Unit
    ) {
        ensureRunning(pauseRequested, cancelled)
        var existing = output.takeIf { it.exists() }?.length() ?: 0L
        if (!supportsRanges && existing > 0) {
            output.delete()
            downloaded.set(0L)
            existing = 0L
        }
        if (totalBytes > 0 && existing >= totalBytes) return

        val connection = open(url).apply {
            if (supportsRanges && existing > 0) {
                setRequestProperty("Range", "bytes=$existing-")
            }
        }
        try {
            val code = connection.responseCode
            val appending = supportsRanges && existing > 0 && code == HttpURLConnection.HTTP_PARTIAL
            if (existing > 0 && supportsRanges && !appending) {
                connection.disconnect()
                output.delete()
                downloaded.set(0L)
                return downloadSingle(
                    url, false, output, pauseRequested, cancelled, downloaded, totalBytes, onProgress
                )
            }
            if (code !in 200..299) error("Download failed with HTTP $code")
            val resolvedTotal = if (totalBytes > 0) totalBytes else {
                if (appending) existing + connection.contentLengthLong else connection.contentLengthLong
            }
            BufferedInputStream(connection.inputStream, BUFFER_SIZE).use { input ->
                BufferedOutputStream(FileOutputStream(output, appending), BUFFER_SIZE).use { out ->
                    copyWithState(input, out, pauseRequested, cancelled) { count ->
                        val current = downloaded.addAndGet(count.toLong())
                        onProgress(Progress(current, resolvedTotal, "Downloading"))
                    }
                }
            }
        } finally {
            runCatching { connection.disconnect() }
        }
    }

    private fun copyWithState(
        input: BufferedInputStream,
        output: BufferedOutputStream,
        pauseRequested: AtomicBoolean,
        cancelled: AtomicBoolean,
        onBytes: (Int) -> Unit
    ) {
        val buffer = ByteArray(BUFFER_SIZE)
        while (true) {
            ensureRunning(pauseRequested, cancelled)
            val read = input.read(buffer)
            if (read == -1) break
            output.write(buffer, 0, read)
            onBytes(read)
        }
    }

    private fun publishToDownloads(
        workDir: File,
        partCount: Int,
        fileName: String,
        mimeType: String,
        cancelled: AtomicBoolean
    ): Uri {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName)
            put(MediaStore.Downloads.MIME_TYPE, mimeType)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MultiFetch")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }

        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Android could not create the output file.")
        try {
            resolver.openOutputStream(uri, "w")?.use { rawOut ->
                BufferedOutputStream(rawOut, BUFFER_SIZE).use { out ->
                    for (index in 0 until partCount) {
                        if (cancelled.get()) throw DownloadCancelledException()
                        val part = File(workDir, "part_$index.tmp")
                        require(part.exists()) { "Missing segment $index" }
                        part.inputStream().buffered(BUFFER_SIZE).use { input ->
                            input.copyTo(out, BUFFER_SIZE)
                        }
                    }
                }
            } ?: error("Unable to open output stream.")

            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return uri
        } catch (t: Throwable) {
            resolver.delete(uri, null, null)
            throw t
        }
    }

    private fun open(url: URL): HttpURLConnection =
        (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 30_000
            instanceFollowRedirects = true
            useCaches = false
            setRequestProperty("Accept-Encoding", "identity")
            setRequestProperty("User-Agent", "MultiFetch/0.2 Android")
        }

    private fun parseTotalFromContentRange(value: String?): Long {
        if (value.isNullOrBlank()) return -1L
        return value.substringAfter('/', "").toLongOrNull() ?: -1L
    }

    private fun extractFileName(connection: HttpURLConnection, url: URL): String {
        val disposition = connection.getHeaderField("Content-Disposition").orEmpty()
        val encoded = Regex("filename\\*=UTF-8''([^;]+)", RegexOption.IGNORE_CASE)
            .find(disposition)?.groupValues?.getOrNull(1)
        val plain = Regex("filename=\"?([^\";]+)", RegexOption.IGNORE_CASE)
            .find(disposition)?.groupValues?.getOrNull(1)

        val candidate = encoded?.let {
            runCatching { URLDecoder.decode(it, StandardCharsets.UTF_8.name()) }.getOrNull()
        } ?: plain ?: url.path.substringAfterLast('/').substringBefore('?')

        return sanitizeFileName(candidate.ifBlank { "download_${System.currentTimeMillis()}" })
    }

    private fun sanitizeFileName(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .take(180)
            .ifBlank { "download_${System.currentTimeMillis()}" }

    private fun ensureRunning(pauseRequested: AtomicBoolean, cancelled: AtomicBoolean) {
        if (cancelled.get()) throw DownloadCancelledException()
        if (pauseRequested.get()) throw DownloadPausedException()
        if (Thread.currentThread().isInterrupted) {
            if (pauseRequested.get()) throw DownloadPausedException()
            if (cancelled.get()) throw DownloadCancelledException()
        }
    }

    private fun unwrap(t: Throwable): Throwable {
        var current = t
        while (current.cause != null && current !is DownloadPausedException && current !is DownloadCancelledException) {
            current = current.cause!!
        }
        return current
    }

    companion object {
        private const val BUFFER_SIZE = 64 * 1024
        private const val MIB = 1024 * 1024
    }
}
